package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NUMIDIA Ancient Oasis & Terracotta Color Palette
val TerracottaPrimary = Color(0xFFC86828)
val TerracottaDark = Color(0xFF8A3C12)
val TerracottaLight = Color(0xFFE89052)

val SandParchment = Color(0xFFF7EED6)
val SandParchmentDark = Color(0xFFDFCEAA)
val SandSurface = Color(0xFF2C1F16)
val SandSurfaceVariant = Color(0xFF3D2C20)

val OasisGreen = Color(0xFF4E8236)
val OasisGreenDark = Color(0xFF2D551E)
val OasisGreenLight = Color(0xFF7BAA5A)

val NumidiaGold = Color(0xFFE0A838)
val NumidiaGoldLight = Color(0xFFFFD466)

val NightBackground = Color(0xFF16100B)
val NightOnBackground = Color(0xFFF5EBD7)
val NightBorder = Color(0xFF5A4432)
