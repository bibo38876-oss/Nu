package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NumidiaDarkColorScheme = darkColorScheme(
    primary = TerracottaPrimary,
    onPrimary = SandParchment,
    primaryContainer = TerracottaDark,
    onPrimaryContainer = SandParchment,
    secondary = OasisGreen,
    onSecondary = SandParchment,
    secondaryContainer = OasisGreenDark,
    onSecondaryContainer = SandParchment,
    tertiary = NumidiaGold,
    onTertiary = NightBackground,
    background = NightBackground,
    onBackground = NightOnBackground,
    surface = SandSurface,
    onSurface = SandParchment,
    surfaceVariant = SandSurfaceVariant,
    onSurfaceVariant = SandParchmentDark,
    outline = NightBorder
)

private val NumidiaLightColorScheme = lightColorScheme(
    primary = TerracottaPrimary,
    onPrimary = Color.White,
    primaryContainer = TerracottaLight,
    onPrimaryContainer = NightBackground,
    secondary = OasisGreen,
    onSecondary = Color.White,
    secondaryContainer = OasisGreenLight,
    onSecondaryContainer = NightBackground,
    tertiary = NumidiaGold,
    onTertiary = NightBackground,
    background = SandParchment,
    onBackground = NightBackground,
    surface = Color(0xFFFBF6EC),
    onSurface = NightBackground,
    surfaceVariant = SandParchmentDark,
    onSurfaceVariant = NightBackground,
    outline = TerracottaDark
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Numidia game prefers ambient dark/warm mode for pixel art focus
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) NumidiaDarkColorScheme else NumidiaLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
