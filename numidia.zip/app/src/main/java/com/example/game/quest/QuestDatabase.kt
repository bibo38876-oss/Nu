package com.example.game.quest

import com.example.game.npc.NPCId

object QuestDatabase {

    val QUEST_FIRST_HARVEST = QuestDefinition(
        id = "quest_first_harvest",
        titleArabic = "أول حصاد",
        summaryArabic = "احصد محصولاً واحداً من مزرعتك.",
        giverNpcId = NPCId.MAZEN,
        giverDialogueArabic = "إذا أردت أن تنجح هنا، عليك أن تبدأ من الأرض. احصد محصولاً واحداً وعد إليّ.",
        completionDialogueArabic = "عمل رائع! الأرض تجود دائماً على من يعتني بها بصدق. ها هي مكافأتك.",
        objectives = listOf(
            QuestObjective(
                id = "harvest_1_crop",
                type = ObjectiveType.HARVEST_CROP,
                descriptionArabic = "احصد محصولاً واحداً من المزرعة",
                targetCount = 1
            )
        ),
        reward = QuestReward(
            money = 10,
            affinityBonus = 5,
            descriptionArabic = "+10 مال، +5 علاقة مع مازن"
        ),
        prerequisiteQuestIds = emptyList()
    )

    val QUEST_MARKET_DAY = QuestDefinition(
        id = "quest_market_day",
        titleArabic = "أول صفقة",
        summaryArabic = "بع محصولاً واحداً في سوق نوميديا.",
        giverNpcId = NPCId.SAMIRA,
        giverDialogueArabic = "التجارة هي شريان الحياة في نوميديا! اذهب للسوق وبع محصولاً لتتعلم أصول التجارة.",
        completionDialogueArabic = "أحسنت! السوق يرحب دائماً بالمزارعين والتجار النشيطين. خذ نصيبك من الأرباح.",
        objectives = listOf(
            QuestObjective(
                id = "sell_1_item",
                type = ObjectiveType.SELL_ITEM,
                descriptionArabic = "بع محصولاً واحداً في السوق",
                targetCount = 1
            )
        ),
        reward = QuestReward(
            money = 15,
            affinityBonus = 5,
            descriptionArabic = "+15 مال، +5 علاقة مع سميرة"
        ),
        prerequisiteQuestIds = emptyList()
    )

    val QUEST_INTO_FOREST = QuestDefinition(
        id = "quest_into_forest",
        titleArabic = "إلى الغابة",
        summaryArabic = "توجه إلى الغابة واجمع 5 قطع خشب.",
        giverNpcId = NPCId.AMIN,
        giverDialogueArabic = "أحتاج إلى أخشاب طازجة في الورشة. توجه إلى الغابة واقطع 5 قطع خشب باستخدام فأسك.",
        completionDialogueArabic = "خشب ممتاز ومتين! سيفيدنا كثيراً في ورشة النجارة وصيانة الأدوات. تفضل مكافأتك.",
        objectives = listOf(
            QuestObjective(
                id = "gather_5_wood",
                type = ObjectiveType.GATHER_WOOD,
                descriptionArabic = "اجمع 5 قطع خشب من الغابة",
                targetCount = 5
            )
        ),
        reward = QuestReward(
            money = 20,
            affinityBonus = 5,
            descriptionArabic = "+20 مال، +5 علاقة مع أمين"
        ),
        prerequisiteQuestIds = emptyList()
    )

    val QUEST_SEEDS_TOMORROW = QuestDefinition(
        id = "quest_seeds_tomorrow",
        titleArabic = "بذور جديدة",
        summaryArabic = "اشترِ 3 بذور من متجر البذور.",
        giverNpcId = NPCId.YASSIN,
        giverDialogueArabic = "المزارع الذكي يستثمر دائماً في مستقبله. اشترِ 3 بذور من متجري لنرى همتك واستعدادك.",
        completionDialogueArabic = "اختيار حكيم! البذور الجيدة هي أساس كل حصاد وفير في نوميديا. خذ هذه المكافأة تشجيعاً لك.",
        objectives = listOf(
            QuestObjective(
                id = "buy_3_seeds",
                type = ObjectiveType.BUY_ITEM,
                descriptionArabic = "اشترِ 3 بذور من متجر ياسين",
                targetCount = 3
            )
        ),
        reward = QuestReward(
            money = 20,
            affinityBonus = 5,
            descriptionArabic = "+20 مال، +5 علاقة مع ياسين"
        ),
        prerequisiteQuestIds = listOf("quest_first_harvest")
    )

    val QUEST_BUSY_FARM = QuestDefinition(
        id = "quest_busy_farm",
        titleArabic = "مزرعة مزدحمة",
        summaryArabic = "احصد 3 محاصيل متنوعة لتوسيع إنتاجك.",
        giverNpcId = NPCId.MAZEN,
        giverDialogueArabic = "حقل واحد لا يكفي لتغذية قريتنا. احصد 3 محاصيل لتثبت أن مزرعتك تنبض بالحياة.",
        completionDialogueArabic = "ما شاء الله! خيرات أرضك تملأ السلال وسكان القرية مسرورون. أنت مزارع حقيقي يعتمد عليه.",
        objectives = listOf(
            QuestObjective(
                id = "harvest_3_crops",
                type = ObjectiveType.HARVEST_CROP,
                descriptionArabic = "احصد 3 محاصيل من مزرعتك",
                targetCount = 3
            )
        ),
        reward = QuestReward(
            money = 30,
            affinityBonus = 5,
            descriptionArabic = "+30 مال، +5 علاقة مع مازن"
        ),
        prerequisiteQuestIds = listOf("quest_first_harvest")
    )

    val QUEST_WOOD_WORKSHOP = QuestDefinition(
        id = "quest_wood_workshop",
        titleArabic = "خشب للورشة",
        summaryArabic = "اجمع 15 قطعة خشب من غابة نوميديا.",
        giverNpcId = NPCId.AMIN,
        giverDialogueArabic = "طلبات أدوات القرية تتزايد باستمرار! اجمع 15 قطعة خشب من الغابة لنصنع مزيداً من الأدوات.",
        completionDialogueArabic = "جهد جبار! هذه الكمية من الخشب ستكفينا لأيام عديدة في الورشة. تفضل مكافأتك المستحقة.",
        objectives = listOf(
            QuestObjective(
                id = "gather_15_wood",
                type = ObjectiveType.GATHER_WOOD,
                descriptionArabic = "اجمع 15 قطعة خشب من الغابة",
                targetCount = 15
            )
        ),
        reward = QuestReward(
            money = 40,
            affinityBonus = 5,
            descriptionArabic = "+40 مال، +5 علاقة مع أمين"
        ),
        prerequisiteQuestIds = listOf("quest_into_forest")
    )

    val QUEST_VILLAGE_TRADER = QuestDefinition(
        id = "quest_village_trader",
        titleArabic = "تاجرة القرية",
        summaryArabic = "بع محاصيل بقيمة لا تقل عن 50 مال.",
        giverNpcId = NPCId.SAMIRA,
        giverDialogueArabic = "السوق يحتاج إلى وفرة وتنوع دائم! بع محاصيل بقيمة 50 مال على الأقل لتعزز حركة البيع.",
        completionDialogueArabic = "صفقات رابحة للجميع! السوق ينتعش بتجارتك الواعدة. ها هي أرباحك الإضافية.",
        objectives = listOf(
            QuestObjective(
                id = "sell_50_value",
                type = ObjectiveType.SELL_VALUE,
                descriptionArabic = "بع محاصيل بقيمة 50 مال إجمالاً",
                targetCount = 50
            )
        ),
        reward = QuestReward(
            money = 50,
            affinityBonus = 5,
            descriptionArabic = "+50 مال، +5 علاقة مع سميرة"
        ),
        prerequisiteQuestIds = listOf("quest_market_day")
    )

    val QUEST_GROWING_VILLAGE = QuestDefinition(
        id = "quest_growing_village",
        titleArabic = "قرية تنمو وتزدهر",
        summaryArabic = "ساهم في دورة الحياة: اشترِ بذرتين، واحصد محصولين، وبع محصولين.",
        giverNpcId = NPCId.YASSIN,
        giverDialogueArabic = "نوميديا تكبر بجهودنا معاً في كل المجالات. اشترِ بذرتين، واحصد محصولين، وبع محصولين في السوق!",
        completionDialogueArabic = "نوميديا تفخر بك! لقد ساهمت في دورة الإنتاج والتجارة الكاملة لقريتنا المباركة.",
        objectives = listOf(
            QuestObjective(
                id = "buy_2_seeds",
                type = ObjectiveType.BUY_ITEM,
                descriptionArabic = "شراء بذرتين من المتجر",
                targetCount = 2
            ),
            QuestObjective(
                id = "harvest_2_crops",
                type = ObjectiveType.HARVEST_CROP,
                descriptionArabic = "حصاد محصولين من المزرعة",
                targetCount = 2
            ),
            QuestObjective(
                id = "sell_2_crops",
                type = ObjectiveType.SELL_ITEM,
                descriptionArabic = "بيع محصولين في السوق",
                targetCount = 2
            )
        ),
        reward = QuestReward(
            money = 75,
            affinityBonus = 10,
            descriptionArabic = "+75 مال، +10 علاقة مع ياسين"
        ),
        prerequisiteQuestIds = listOf("quest_seeds_tomorrow", "quest_busy_farm", "quest_village_trader")
    )

    val ALL_QUESTS: List<QuestDefinition> = listOf(
        QUEST_FIRST_HARVEST,
        QUEST_MARKET_DAY,
        QUEST_INTO_FOREST,
        QUEST_SEEDS_TOMORROW,
        QUEST_BUSY_FARM,
        QUEST_WOOD_WORKSHOP,
        QUEST_VILLAGE_TRADER,
        QUEST_GROWING_VILLAGE
    )

    fun findById(id: String): QuestDefinition? = ALL_QUESTS.find { it.id == id }
}
