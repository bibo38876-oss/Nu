package com.example.game.progression

data class FarmExpansionTier(
    val level: Int,
    val nameArabic: String,
    val cost: Int,
    val totalPlots: Int,
    val addedPlots: Int,
    val descriptionArabic: String
)

object FarmExpansionCatalog {

    val TIERS = listOf(
        FarmExpansionTier(
            level = 1,
            nameArabic = "المزرعة البسيطة",
            cost = 0,
            totalPlots = 6,
            addedPlots = 0,
            descriptionArabic = "الحقل الأولي بمساحة تتسع لـ 6 قطع زراعية."
        ),
        FarmExpansionTier(
            level = 2,
            nameArabic = "توسعة المزرعة (المستوى 2)",
            cost = 100,
            totalPlots = 10,
            addedPlots = 4,
            descriptionArabic = "استصلاح أرض زراعية جديدة (+4 قطع) ليصبح المجموع 10 قطع."
        ),
        FarmExpansionTier(
            level = 3,
            nameArabic = "توسعة المزرعة (المستوى 3)",
            cost = 300,
            totalPlots = 15,
            addedPlots = 5,
            descriptionArabic = "حقل واسع خصب (+5 قطع) ليصبح المجموع 15 قطعة زراعية."
        ),
        FarmExpansionTier(
            level = 4,
            nameArabic = "المزرعة الكبرى (المستوى 4)",
            cost = 750,
            totalPlots = 20,
            addedPlots = 5,
            descriptionArabic = "الاستصلاح الأقصى لحقل القرية (+5 قطع) بإجمالي 20 قطعة زراعية."
        )
    )

    fun getTier(level: Int): FarmExpansionTier? = TIERS.find { it.level == level }

    fun getNextTier(currentLevel: Int): FarmExpansionTier? = TIERS.find { it.level == currentLevel + 1 }

    fun getMaxLevel(): Int = TIERS.maxOf { it.level }
}
