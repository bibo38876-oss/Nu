package com.example.game.ui.game

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import com.example.game.art.PixelFarmingSprites
import com.example.game.art.PixelNPCSprites
import com.example.game.art.PixelPalette
import com.example.game.art.PixelResourceSprites
import com.example.game.art.PixelSprites
import com.example.game.engine.GameCamera
import com.example.game.engine.GameEngine
import com.example.game.farming.FarmingPlot
import com.example.game.farming.FarmingPlotState
import com.example.game.npc.NPCState
import com.example.game.quest.QuestMarkerType
import com.example.game.resources.ResourceNode
import com.example.game.resources.ResourceNodeState
import com.example.game.resources.TreeVariant
import com.example.game.state.PlayerActionAnimation
import com.example.game.world.ObjectType
import com.example.game.world.TileType
import com.example.game.world.WorldObject
import com.example.game.world.ZoneId
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput

private sealed class RenderEntity(val sortY: Float) {
    class ObjectEntity(val obj: WorldObject) : RenderEntity(obj.sortY)
    class CropEntity(val plot: FarmingPlot) : RenderEntity(plot.worldY + 4f)
    class ResourceEntity(val node: ResourceNode) : RenderEntity(node.sortY)
    class PlayerEntity(val x: Float, val y: Float) : RenderEntity(y)
    class NpcEntity(val npc: NPCState) : RenderEntity(npc.sortY)
}

@Composable
fun GameCanvas(
    engine: GameEngine,
    modifier: Modifier = Modifier
) {
    val zone = engine.currentZone
    val player = engine.playerState
    val camera = engine.camera
    val fadeAlpha = engine.transitionFadeAlpha
    val activePlot = engine.activeFarmingPlot
    val activeResource = engine.activeResourceNode

    val pixelPaint = Paint().apply {
        isFilterBitmap = false // Retro crisp pixel art rendering
        isAntiAlias = false
    }

    val shadowPaint = Paint().apply {
        isFilterBitmap = false
        alpha = 180
    }

    val highlightPaint = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
        color = android.graphics.Color.argb(220, 245, 197, 56) // Warm gold
        isAntiAlias = false
    }

    val beaconRingPaint = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.0f
        color = android.graphics.Color.argb(200, 255, 212, 102)
        isAntiAlias = true
    }

    val beaconDotPaint = Paint().apply {
        style = Paint.Style.FILL
        color = android.graphics.Color.argb(230, 255, 212, 102)
        isAntiAlias = true
    }

    val woodChipPaint = Paint().apply {
        style = Paint.Style.FILL
        color = android.graphics.Color.rgb(218, 155, 85)
        isAntiAlias = false
    }

    val waterGlintPaint = Paint().apply {
        style = Paint.Style.FILL
        color = android.graphics.Color.argb(200, 220, 245, 255)
        isAntiAlias = false
    }

    val leafPaint = Paint().apply {
        style = Paint.Style.FILL
        color = android.graphics.Color.argb(190, 110, 155, 60)
        isAntiAlias = false
    }

    val ambientLightingPaint = Paint().apply {
        style = Paint.Style.FILL
        isAntiAlias = false
    }

    val lanternGlowPaintOuter = Paint().apply {
        style = Paint.Style.FILL
        color = android.graphics.Color.argb(38, 255, 195, 75)
        isAntiAlias = true
    }

    val lanternGlowPaintMid = Paint().apply {
        style = Paint.Style.FILL
        color = android.graphics.Color.argb(75, 255, 215, 110)
        isAntiAlias = true
    }

    val lanternCorePaint = Paint().apply {
        style = Paint.Style.FILL
        color = android.graphics.Color.argb(220, 255, 245, 180)
        isAntiAlias = true
    }

    val srcRect = Rect()
    val dstRectF = RectF()

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(engine) {
                detectTapGestures { tapOffset ->
                    val worldX = camera.screenToWorldX(tapOffset.x)
                    val worldY = camera.screenToWorldY(tapOffset.y)

                    // Check if player tapped directly on a living Village NPC
                    if (zone.zoneId == ZoneId.VILLAGE) {
                        val tappedNpc = engine.npcController.npcs.find { npc ->
                            val dx = worldX - npc.x
                            val dy = worldY - (npc.y - 12f)
                            (dx * dx + dy * dy) <= (28f * 28f)
                        }
                        if (tappedNpc != null) {
                            if (tappedNpc.isPlayerInRange(engine.playerState.x, engine.playerState.y)) {
                                engine.startNpcDialogue(tappedNpc)
                                return@detectTapGestures
                            }
                        }
                    }

                    engine.setMoveTarget(worldX, worldY)
                }
            }
    ) {
        // Read render clock to trigger smooth 60 FPS frame invalidation
        val renderTick = engine.renderTick
        val gameTime = engine.gameTimeSec

        camera.updateViewport(size.width, size.height)

        drawIntoCanvas { composeCanvas ->
            val canvas = composeCanvas.nativeCanvas

            // 1. Draw Background
            canvas.drawColor(android.graphics.Color.rgb(22, 16, 11))

            val scale = camera.worldScale
            val tileSize = TileType.TILE_SIZE

            // 2. Visible Tile Range Culling
            val halfW = (camera.viewportWidth / scale) / 2f + tileSize
            val halfH = (camera.viewportHeight / scale) / 2f + tileSize

            val minCol = max(0, ((camera.offsetX - halfW) / tileSize).toInt())
            val maxCol = min(zone.cols - 1, ((camera.offsetX + halfW) / tileSize).toInt())
            val minRow = max(0, ((camera.offsetY - halfH) / tileSize).toInt())
            val maxRow = min(zone.rows - 1, ((camera.offsetY + halfH) / tileSize).toInt())

            // 3. Render Ground Tiles
            for (r in minRow..maxRow) {
                for (c in minCol..maxCol) {
                    val tileType = zone.tiles[r][c]
                    val tileBmp = PixelSprites.tileBitmaps[tileType] ?: continue

                    val worldX = c * tileSize
                    val worldY = r * tileSize
                    val screenX = camera.worldToScreenX(worldX)
                    val screenY = camera.worldToScreenY(worldY)
                    val screenTileW = tileSize * scale
                    val screenTileH = tileSize * scale

                    srcRect.set(0, 0, tileBmp.width, tileBmp.height)
                    dstRectF.set(screenX, screenY, screenX + screenTileW, screenY + screenTileH)
                    canvas.drawBitmap(tileBmp, srcRect, dstRectF, pixelPaint)
                }
            }

            // 4. Render Decorative Forest Floor Details (Fallen branches, wild mushrooms)
            if (zone.zoneId == ZoneId.FOREST) {
                val forestFloorSpots = listOf(
                    Triple(220f, 490f, PixelResourceSprites.fallenBranchBmp),
                    Triple(490f, 390f, PixelResourceSprites.fallenBranchBmp),
                    Triple(580f, 720f, PixelResourceSprites.fallenBranchBmp),
                    Triple(310f, 220f, PixelResourceSprites.forestMushroomBmp),
                    Triple(450f, 620f, PixelResourceSprites.forestMushroomBmp),
                    Triple(160f, 600f, PixelResourceSprites.forestMushroomBmp)
                )

                for ((fx, fy, bmp) in forestFloorSpots) {
                    val sx = camera.worldToScreenX(fx)
                    val sy = camera.worldToScreenY(fy)
                    val bw = bmp.width * scale * 0.9f
                    val bh = bmp.height * scale * 0.9f
                    srcRect.set(0, 0, bmp.width, bmp.height)
                    dstRectF.set(sx - bw / 2f, sy - bh, sx + bw / 2f, sy)
                    canvas.drawBitmap(bmp, srcRect, dstRectF, pixelPaint)
                }
            }

            // 5. Render Farming Plot Soil Beds (In Village)
            if (zone.zoneId == ZoneId.VILLAGE) {
                for (plot in engine.farming.getAllPlots()) {
                    val plotBmp = when (plot.state) {
                        FarmingPlotState.EMPTY -> PixelFarmingSprites.plotEmptyBmp
                        FarmingPlotState.CREATED -> PixelFarmingSprites.plotCreatedBmp
                        else -> PixelFarmingSprites.plotPreparedBmp
                    }

                    val px = camera.worldToScreenX(plot.worldX)
                    val py = camera.worldToScreenY(plot.worldY)
                    val pw = 30f * scale
                    val ph = 22f * scale

                    srcRect.set(0, 0, plotBmp.width, plotBmp.height)
                    dstRectF.set(px - pw / 2f, py - ph / 2f, px + pw / 2f, py + ph / 2f)
                    canvas.drawBitmap(plotBmp, srcRect, dstRectF, pixelPaint)

                    // Highlight targeted plot if player is close
                    if (activePlot != null && activePlot.id == plot.id) {
                        canvas.drawRoundRect(dstRectF, 6f, 6f, highlightPaint)
                    }
                }
            }

            // 6. Render Soft Ground Shadows
            // Shadows for static world objects
            for (obj in zone.objects) {
                val objScreenX = camera.worldToScreenX(obj.x)
                val objScreenY = camera.worldToScreenY(obj.y)

                when (obj.type) {
                    ObjectType.SEED_SHOP, ObjectType.MARKET_STALL -> {
                        val shBmp = PixelSprites.largeShadow
                        val sw = obj.visualWidth * scale * 0.95f
                        val sh = 28f * scale
                        srcRect.set(0, 0, shBmp.width, shBmp.height)
                        dstRectF.set(objScreenX - sw / 2f, objScreenY - sh / 2f - 4f, objScreenX + sw / 2f, objScreenY + sh / 2f - 4f)
                        canvas.drawBitmap(shBmp, srcRect, dstRectF, shadowPaint)
                    }
                    ObjectType.TREE_CEDAR -> {
                        val shBmp = PixelSprites.largeShadow
                        val sw = 56f * scale
                        val sh = 22f * scale
                        srcRect.set(0, 0, shBmp.width, shBmp.height)
                        dstRectF.set(objScreenX - sw / 2f, objScreenY - sh / 2f - 2f, objScreenX + sw / 2f, objScreenY + sh / 2f - 2f)
                        canvas.drawBitmap(shBmp, srcRect, dstRectF, shadowPaint)
                    }
                    ObjectType.TREE_OLIVE -> {
                        val shBmp = PixelSprites.mediumShadow
                        val sw = 44f * scale
                        val sh = 18f * scale
                        srcRect.set(0, 0, shBmp.width, shBmp.height)
                        dstRectF.set(objScreenX - sw / 2f, objScreenY - sh / 2f - 2f, objScreenX + sw / 2f, objScreenY + sh / 2f - 2f)
                        canvas.drawBitmap(shBmp, srcRect, dstRectF, shadowPaint)
                    }
                    ObjectType.TREE_CYPRESS -> {
                        val shBmp = PixelSprites.mediumShadow
                        val sw = 26f * scale
                        val sh = 14f * scale
                        srcRect.set(0, 0, shBmp.width, shBmp.height)
                        dstRectF.set(objScreenX - sw / 2f, objScreenY - sh / 2f - 2f, objScreenX + sw / 2f, objScreenY + sh / 2f - 2f)
                        canvas.drawBitmap(shBmp, srcRect, dstRectF, shadowPaint)
                    }
                    ObjectType.STONE_WELL -> {
                        val shBmp = PixelSprites.mediumShadow
                        val sw = 48f * scale
                        val sh = 20f * scale
                        srcRect.set(0, 0, shBmp.width, shBmp.height)
                        dstRectF.set(objScreenX - sw / 2f, objScreenY - sh / 2f - 2f, objScreenX + sw / 2f, objScreenY + sh / 2f - 2f)
                        canvas.drawBitmap(shBmp, srcRect, dstRectF, shadowPaint)
                    }
                    ObjectType.BOULDER -> {
                        val shBmp = PixelSprites.mediumShadow
                        val sw = 32f * scale
                        val sh = 14f * scale
                        srcRect.set(0, 0, shBmp.width, shBmp.height)
                        dstRectF.set(objScreenX - sw / 2f, objScreenY - sh / 2f, objScreenX + sw / 2f, objScreenY + sh / 2f)
                        canvas.drawBitmap(shBmp, srcRect, dstRectF, shadowPaint)
                    }
                    ObjectType.BERRY_BUSH -> {
                        val shBmp = PixelSprites.mediumShadow
                        val sw = 28f * scale
                        val sh = 12f * scale
                        srcRect.set(0, 0, shBmp.width, shBmp.height)
                        dstRectF.set(objScreenX - sw / 2f, objScreenY - sh / 2f, objScreenX + sw / 2f, objScreenY + sh / 2f)
                        canvas.drawBitmap(shBmp, srcRect, dstRectF, shadowPaint)
                    }
                    else -> {}
                }
            }

            // Shadows for Resource Nodes (Trees & Stumps in Forest)
            if (zone.zoneId == ZoneId.FOREST) {
                for (treeNode in engine.resourceManager.getAllNodes()) {
                    val tx = camera.worldToScreenX(treeNode.worldX)
                    val ty = camera.worldToScreenY(treeNode.worldY)

                    if (treeNode.state == ResourceNodeState.DEPLETED || treeNode.state == ResourceNodeState.RESPAWNING) {
                        // Small shadow around stump
                        val shBmp = PixelSprites.playerShadow
                        val sw = 20f * scale
                        val sh = 10f * scale
                        srcRect.set(0, 0, shBmp.width, shBmp.height)
                        dstRectF.set(tx - sw / 2f, ty - sh / 2f + (2f * scale), tx + sw / 2f, ty + sh / 2f + (2f * scale))
                        canvas.drawBitmap(shBmp, srcRect, dstRectF, shadowPaint)
                    } else {
                        // Full tree shadow
                        val (shBmp, sw, sh) = when (treeNode.treeVariant) {
                            TreeVariant.LARGE -> Triple(PixelSprites.largeShadow, 56f * scale, 22f * scale)
                            TreeVariant.MEDIUM -> Triple(PixelSprites.mediumShadow, 44f * scale, 18f * scale)
                            TreeVariant.SMALL -> Triple(PixelSprites.mediumShadow, 26f * scale, 14f * scale)
                        }
                        srcRect.set(0, 0, shBmp.width, shBmp.height)
                        dstRectF.set(tx - sw / 2f, ty - sh / 2f - 2f, tx + sw / 2f, ty + sh / 2f - 2f)
                        canvas.drawBitmap(shBmp, srcRect, dstRectF, shadowPaint)
                    }
                }
            }

            // Player Shadow
            val playerScreenX = camera.worldToScreenX(player.x)
            val playerScreenY = camera.worldToScreenY(player.y)
            val pShadowBmp = PixelSprites.playerShadow
            val pShadowW = 22f * scale
            val pShadowH = 10f * scale
            srcRect.set(0, 0, pShadowBmp.width, pShadowBmp.height)
            dstRectF.set(
                playerScreenX - pShadowW / 2f,
                playerScreenY + (8f * scale) - pShadowH / 2f,
                playerScreenX + pShadowW / 2f,
                playerScreenY + (8f * scale) + pShadowH / 2f
            )
            canvas.drawBitmap(pShadowBmp, srcRect, dstRectF, shadowPaint)

            // Render Tap-To-Move Destination Beacon
            val targetX = engine.targetMoveX
            val targetY = engine.targetMoveY
            if (targetX != null && targetY != null) {
                val bx = camera.worldToScreenX(targetX)
                val by = camera.worldToScreenY(targetY)
                val pulse = (sin(gameTime.toDouble() * 8.0).toFloat() + 1f) * 0.5f
                val ringRadius = (7f + pulse * 4f) * scale
                canvas.drawCircle(bx, by, ringRadius, beaconRingPaint)
                canvas.drawCircle(bx, by, 3f * scale, beaconDotPaint)
            }

            // 7. Y-Sorted Entities Rendering (3/4 Perspective depth sorting)
            val entities = mutableListOf<RenderEntity>()
            for (obj in zone.objects) {
                entities.add(RenderEntity.ObjectEntity(obj))
            }

            // Add active crops in the village
            if (zone.zoneId == ZoneId.VILLAGE) {
                for (plot in engine.farming.getAllPlots()) {
                    if (plot.plantedCrop != null) {
                        entities.add(RenderEntity.CropEntity(plot))
                    }
                }
                // Add living village NPCs
                for (npc in engine.npcController.npcs) {
                    entities.add(RenderEntity.NpcEntity(npc))
                }
            }

            // Add interactive resource trees in the forest
            if (zone.zoneId == ZoneId.FOREST) {
                for (treeNode in engine.resourceManager.getAllNodes()) {
                    entities.add(RenderEntity.ResourceEntity(treeNode))
                }
            }

            entities.add(RenderEntity.PlayerEntity(player.x, player.y))
            entities.sortBy { it.sortY }

            for (entity in entities) {
                when (entity) {
                    is RenderEntity.PlayerEntity -> {
                        // Chopping animation with visible Bronze Axe in hand takes precedence
                        val chopBmp = if (player.actionAnimation == PlayerActionAnimation.CHOPPING) {
                            val chopFrame = ((engine.gatheringTimer * 8f).toInt() % 2)
                            PixelResourceSprites.getChopBitmap(player.direction, chopFrame, 1)
                        } else null

                        val actionBmp = chopBmp ?: if (player.actionAnimation != PlayerActionAnimation.NONE) {
                            PixelFarmingSprites.playerActionBitmaps[player.direction]
                        } else null

                        val sprite = actionBmp ?: PixelSprites.playerSprites[Pair(player.direction, player.animFrame)]
                        if (sprite != null) {
                            val px = camera.worldToScreenX(entity.x)
                            val py = camera.worldToScreenY(entity.y)
                            val pw = (if (chopBmp != null) 24f else player.width) * scale * 1.15f
                            val ph = (if (chopBmp != null) 26f else player.height) * scale * 1.15f

                            // Organic idle breathing bounce when standing still
                            val idleBounce = if (!player.isMoving && player.actionAnimation == PlayerActionAnimation.NONE) {
                                (sin(gameTime.toDouble() * 3.5).toFloat() * 1.0f * scale)
                            } else 0f

                            srcRect.set(0, 0, sprite.width, sprite.height)
                            dstRectF.set(
                                px - pw / 2f,
                                py - ph + (12f * scale) + idleBounce, // Anchor at feet with subtle idle breathing
                                px + pw / 2f,
                                py + (12f * scale)
                            )
                            canvas.drawBitmap(sprite, srcRect, dstRectF, pixelPaint)
                        }
                    }

                    is RenderEntity.CropEntity -> {
                        val plot = entity.plot
                        val crop = plot.plantedCrop ?: continue
                        val stage = plot.getGrowthStage()

                        val cropBmp = when (stage) {
                            1 -> PixelFarmingSprites.cropStage1Bmp
                            2 -> PixelFarmingSprites.cropStage2Bmp
                            3 -> PixelFarmingSprites.cropStage3Bmp
                            else -> PixelFarmingSprites.matureCropBitmaps[crop] ?: PixelFarmingSprites.cropStage3Bmp
                        }

                        val cx = camera.worldToScreenX(plot.worldX)
                        val cy = camera.worldToScreenY(plot.worldY)
                        val cw = 24f * scale
                        val ch = 24f * scale

                        // Gentle wind sway for growing and mature crops
                        val swayX = if (stage >= 2) {
                            (sin(gameTime.toDouble() * 3.0 + plot.worldX * 0.1).toFloat() * 1.2f * scale)
                        } else 0f

                        srcRect.set(0, 0, cropBmp.width, cropBmp.height)
                        dstRectF.set(
                            (cx + swayX) - cw / 2f,
                            cy - ch + (2f * scale),
                            (cx + swayX) + cw / 2f,
                            cy + (2f * scale)
                        )
                        canvas.drawBitmap(cropBmp, srcRect, dstRectF, pixelPaint)
                    }

                    is RenderEntity.ObjectEntity -> {
                        val obj = entity.obj
                        val sprite = PixelSprites.objectBitmaps[obj.type]
                        if (sprite != null) {
                            val ox = camera.worldToScreenX(obj.x)
                            val oy = camera.worldToScreenY(obj.y)
                            val ow = obj.visualWidth * scale
                            val oh = obj.visualHeight * scale

                            srcRect.set(0, 0, sprite.width, sprite.height)
                            dstRectF.set(
                                ox - ow / 2f,
                                oy - oh, // Anchor at base
                                ox + ow / 2f,
                                oy
                            )
                            canvas.drawBitmap(sprite, srcRect, dstRectF, pixelPaint)

                            // Shimmering spring water glint inside stone well
                            if (obj.type == ObjectType.STONE_WELL) {
                                val wellSurfaceY = oy - (24f * scale)
                                val glintAlpha = ((sin(gameTime.toDouble() * 4.5).toFloat() + 1f) * 0.5f)
                                waterGlintPaint.alpha = (glintAlpha * 180).toInt() + 50
                                canvas.drawCircle(ox - (4f * scale), wellSurfaceY, 1.8f * scale, waterGlintPaint)
                                canvas.drawCircle(ox + (5f * scale), wellSurfaceY + (2f * scale), 1.4f * scale, waterGlintPaint)
                            }
                        }
                    }

                    is RenderEntity.ResourceEntity -> {
                        val node = entity.node
                        val tx = camera.worldToScreenX(node.worldX)
                        val ty = camera.worldToScreenY(node.worldY)

                        when (node.state) {
                            ResourceNodeState.DEPLETED, ResourceNodeState.RESPAWNING -> {
                                // Render Stump
                                val stumpBmp = PixelResourceSprites.stumpBitmaps[node.treeVariant]
                                if (stumpBmp != null) {
                                    val sw = stumpBmp.width * scale * 1.1f
                                    val sh = stumpBmp.height * scale * 1.1f

                                    srcRect.set(0, 0, stumpBmp.width, stumpBmp.height)
                                    dstRectF.set(tx - sw / 2f, ty - sh, tx + sw / 2f, ty)
                                    canvas.drawBitmap(stumpBmp, srcRect, dstRectF, pixelPaint)

                                    // If RESPAWNING: draw subtle green sprout atop the stump
                                    if (node.state == ResourceNodeState.RESPAWNING) {
                                        val sproutBmp = PixelFarmingSprites.cropStage1Bmp
                                        val spw = 14f * scale
                                        val sph = 10f * scale
                                        srcRect.set(0, 0, sproutBmp.width, sproutBmp.height)
                                        dstRectF.set(tx - spw / 2f, ty - sh - sph + (4f * scale), tx + spw / 2f, ty - sh + (4f * scale))
                                        canvas.drawBitmap(sproutBmp, srcRect, dstRectF, pixelPaint)
                                    }
                                }
                            }

                            ResourceNodeState.AVAILABLE, ResourceNodeState.GATHERING -> {
                                // Full Tree
                                val treeBmp = PixelSprites.objectBitmaps[node.treeVariant.objectType]
                                if (treeBmp != null) {
                                    val tw = node.treeVariant.visualWidth * scale
                                    val th = node.treeVariant.visualHeight * scale

                                    // Subtle horizontal wobble/shake during chopping
                                    val shakeX = if (node.state == ResourceNodeState.GATHERING) {
                                        sin((node.shakeTimer * 38f).toDouble()).toFloat() * 3f * scale
                                    } else 0f

                                    srcRect.set(0, 0, treeBmp.width, treeBmp.height)
                                    dstRectF.set(
                                        (tx + shakeX) - tw / 2f,
                                        ty - th,
                                        (tx + shakeX) + tw / 2f,
                                        ty
                                    )
                                    canvas.drawBitmap(treeBmp, srcRect, dstRectF, pixelPaint)

                                    // Flying wood chips particles when actively gathering
                                    if (node.state == ResourceNodeState.GATHERING) {
                                        val t = node.shakeTimer.toDouble()
                                        for (i in 0..3) {
                                            val pOffsetX = (sin(t * 15.0 + i * 1.8).toFloat()) * 14f * scale
                                            val pOffsetY = -10f * scale + (sin(t * 22.0 + i).toFloat() * 8f * scale)
                                            val chipSize = 2.5f * scale
                                            canvas.drawRect(
                                                tx + pOffsetX,
                                                ty + pOffsetY,
                                                tx + pOffsetX + chipSize,
                                                ty + pOffsetY + chipSize,
                                                woodChipPaint
                                            )
                                        }
                                    }

                                    // Subtle gold highlight ring around tree foot when in chopping range
                                    if (activeResource?.id == node.id && node.canGather()) {
                                        val hw = node.treeVariant.collisionWidth * scale * 1.2f
                                        val hh = node.treeVariant.collisionHeight * scale * 1.1f
                                        dstRectF.set(tx - hw / 2f, ty - hh / 2f, tx + hw / 2f, ty + hh / 2f)
                                        canvas.drawOval(dstRectF, highlightPaint)
                                    }
                                }
                            }
                        }
                    }

                    is RenderEntity.NpcEntity -> {
                        val npc = entity.npc
                        val nx = camera.worldToScreenX(npc.x)
                        val ny = camera.worldToScreenY(npc.y)

                        // 1. NPC Shadow
                        val shadowBmp = PixelSprites.playerShadow
                        val sw = 20f * scale
                        val sh = 9f * scale
                        srcRect.set(0, 0, shadowBmp.width, shadowBmp.height)
                        dstRectF.set(
                            nx - sw / 2f,
                            ny + (7f * scale) - sh / 2f,
                            nx + sw / 2f,
                            ny + (7f * scale) + sh / 2f
                        )
                        canvas.drawBitmap(shadowBmp, srcRect, dstRectF, shadowPaint)

                        // 2. NPC Sprite
                        val frame = if (npc.isMoving) (npc.animFrame % 3) else 0
                        val npcBmp = PixelNPCSprites.npcSprites[Pair(npc.definition.id, Pair(npc.direction, frame))]
                        if (npcBmp != null) {
                            val nw = 16f * scale * 1.15f
                            val nh = 24f * scale * 1.15f
                            val idleBounce = if (!npc.isMoving) {
                                (sin(gameTime.toDouble() * 3.2 + npc.x * 0.2).toFloat() * 0.9f * scale)
                            } else 0f

                            srcRect.set(0, 0, npcBmp.width, npcBmp.height)
                            dstRectF.set(
                                nx - nw / 2f,
                                ny - nh + (12f * scale) + idleBounce,
                                nx + nw / 2f,
                                ny + (12f * scale)
                            )
                            canvas.drawBitmap(npcBmp, srcRect, dstRectF, pixelPaint)

                            // 3. Floating quest marker (! or ?) or talk balloon prompt
                            val questMarker = engine.questManager.getNpcQuestMarker(npc.definition.id)
                            val inRange = npc.isPlayerInRange(player.x, player.y)

                            val markerBmp = when (questMarker) {
                                QuestMarkerType.TURN_IN -> PixelNPCSprites.questTurnInIcon
                                QuestMarkerType.AVAILABLE -> PixelNPCSprites.questAvailableIcon
                                QuestMarkerType.NONE -> if (inRange) PixelNPCSprites.talkPromptIcon else null
                            }

                            if (markerBmp != null) {
                                val floatBob = (sin(gameTime.toDouble() * 5.0 + npc.x).toFloat() * 2.5f * scale)
                                val pw = 16f * scale
                                val ph = 16f * scale
                                val promptY = ny - nh - (4f * scale) + floatBob

                                srcRect.set(0, 0, markerBmp.width, markerBmp.height)
                                dstRectF.set(
                                    nx - pw / 2f,
                                    promptY - ph,
                                    nx + pw / 2f,
                                    promptY
                                )
                                canvas.drawBitmap(markerBmp, srcRect, dstRectF, pixelPaint)
                            }
                        }
                    }
                }
            }

            // 8. Ambient Drifting Forest Leaves
            if (zone.zoneId == ZoneId.FOREST) {
                for (i in 0 until 8) {
                    val seed = i * 83.19f
                    val lx = ((gameTime * 28f + seed * 45f) % (size.width + 80f)) - 40f
                    val ly = ((gameTime * 36f + seed * 77f) % (size.height + 80f)) - 40f
                    val sway = sin(gameTime.toDouble() * 2.8 + i).toFloat() * 10f
                    canvas.drawCircle(lx + sway, ly, 2.2f * scale, leafPaint)
                }
            }

            // 8.5 STAGE 8: WORLD DAY/NIGHT LIGHTING & LANTERNS
            val lighting = engine.lighting
            val worldTime = engine.worldTime
            val ambientDarknessAlpha = lighting.getAmbientDarknessAlpha(worldTime)

            if (ambientDarknessAlpha > 0.015f) {
                val ambientColor = lighting.getAmbientOverlayColor(worldTime)
                ambientLightingPaint.color = ambientColor
                canvas.drawRect(0f, 0f, size.width, size.height, ambientLightingPaint)

                // Render warm glowing lanterns and player torch at night
                if (lighting.areLanternsLit(worldTime)) {
                    val flicker = lighting.getFlickerScale(gameTime)

                    // Fixed Village Lanterns (Seed Shop, Market, Well, Workshop, Farm, Portal)
                    if (zone.zoneId == ZoneId.VILLAGE) {
                        for (lantern in lighting.villageLanterns) {
                            val lx = camera.worldToScreenX(lantern.x)
                            val ly = camera.worldToScreenY(lantern.y)
                            val baseRadius = lantern.radius * scale * flicker
                            canvas.drawCircle(lx, ly, baseRadius * 1.35f, lanternGlowPaintOuter)
                            canvas.drawCircle(lx, ly, baseRadius * 0.75f, lanternGlowPaintMid)
                            canvas.drawCircle(lx, ly, 3.8f * scale, lanternCorePaint)
                        }
                    }

                    // Player's Personal Traveling Lantern (Illuminates in both Village & Forest)
                    val pScreenX = camera.worldToScreenX(player.x)
                    val pScreenY = camera.worldToScreenY(player.y)
                    val pLanternRadius = 68f * scale * flicker
                    canvas.drawCircle(pScreenX, pScreenY, pLanternRadius * 1.25f, lanternGlowPaintOuter)
                    canvas.drawCircle(pScreenX, pScreenY, pLanternRadius * 0.65f, lanternGlowPaintMid)
                    canvas.drawCircle(pScreenX, pScreenY, 3.2f * scale, lanternCorePaint)
                }
            }

            // 9. Zone Transition Fade to Black
            if (fadeAlpha > 0f) {
                val overlayPaint = Paint().apply {
                    color = android.graphics.Color.BLACK
                    alpha = (fadeAlpha.coerceIn(0f, 1f) * 255).toInt()
                }
                canvas.drawRect(0f, 0f, size.width, size.height, overlayPaint)
            }
        }
    }
}
