package com.example.game.art

import android.graphics.Bitmap
import com.example.game.resources.TreeVariant
import com.example.game.state.Direction

object PixelResourceSprites {

    val stumpBitmaps = mutableMapOf<TreeVariant, Bitmap>()
    val playerChopBitmaps = mutableMapOf<Triple<Direction, Int, Int>, Bitmap>() // (direction, frame, axeLevel)

    fun getChopBitmap(dir: Direction, frame: Int, axeLevel: Int = 1): Bitmap? {
        val lvl = axeLevel.coerceIn(1, 3)
        return playerChopBitmaps[Triple(dir, frame, lvl)]
            ?: playerChopBitmaps[Triple(dir, frame, 1)]
    }

    lateinit var fallenBranchBmp: Bitmap
    lateinit var forestMushroomBmp: Bitmap

    private var isInitialized = false

    fun initialize() {
        if (isInitialized) return

        generateStumpSprites()
        generatePlayerChopSprites()
        generateForestFloorDetails()

        isInitialized = true
    }

    private fun createPixelBitmap(width: Int, height: Int, drawer: (Bitmap) -> Unit): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        drawer(bitmap)
        return bitmap
    }

    private fun setPixel(bitmap: Bitmap, x: Int, y: Int, color: Int) {
        if (x in 0 until bitmap.width && y in 0 until bitmap.height) {
            bitmap.setPixel(x, y, color)
        }
    }

    private fun fillRect(bitmap: Bitmap, x1: Int, y1: Int, x2: Int, y2: Int, color: Int) {
        for (y in y1..y2) {
            for (x in x1..x2) {
                setPixel(bitmap, x, y, color)
            }
        }
    }

    // --- 1. TREE STUMP SPRITES (Rendered when trees are DEPLETED) ---
    private fun generateStumpSprites() {
        // SMALL STUMP (Cypress): 16x20 pixels
        stumpBitmaps[TreeVariant.SMALL] = createPixelBitmap(16, 20) { bmp ->
            // Disturbed ground & sawdust
            fillRect(bmp, 2, 17, 13, 19, PixelPalette.FARM_SOIL_DARK)
            setPixel(bmp, 3, 18, PixelPalette.DIRT_LIGHT)
            setPixel(bmp, 12, 18, PixelPalette.DIRT_LIGHT)

            // Small stump trunk
            fillRect(bmp, 5, 8, 10, 17, PixelPalette.TRUNK_DARK)
            fillRect(bmp, 6, 8, 9, 16, PixelPalette.TRUNK_MID)

            // Cut wood surface with concentric ring
            fillRect(bmp, 5, 6, 10, 8, PixelPalette.WOOD_BEAM_LIGHT)
            fillRect(bmp, 6, 6, 9, 7, PixelPalette.DIRT_LIGHT)
            setPixel(bmp, 7, 7, PixelPalette.WOOD_BEAM_MID) // growth center
            setPixel(bmp, 8, 7, PixelPalette.WOOD_BEAM_MID)

            // Bark rim
            setPixel(bmp, 4, 7, PixelPalette.TRUNK_DARK)
            setPixel(bmp, 11, 7, PixelPalette.TRUNK_DARK)
        }

        // MEDIUM STUMP (Olive): 26x24 pixels
        stumpBitmaps[TreeVariant.MEDIUM] = createPixelBitmap(26, 24) { bmp ->
            // Ground earth & scattered wood chips
            fillRect(bmp, 3, 20, 22, 23, PixelPalette.FARM_SOIL_DARK)
            setPixel(bmp, 4, 21, PixelPalette.DIRT_LIGHT)
            setPixel(bmp, 7, 22, PixelPalette.WOOD_BEAM_LIGHT)
            setPixel(bmp, 19, 21, PixelPalette.DIRT_LIGHT)
            setPixel(bmp, 21, 22, PixelPalette.WOOD_BEAM_LIGHT)

            // Gnarled roots flare
            fillRect(bmp, 6, 12, 19, 21, PixelPalette.TRUNK_DARK)
            fillRect(bmp, 8, 12, 17, 20, PixelPalette.TRUNK_MID)
            setPixel(bmp, 5, 19, PixelPalette.TRUNK_DARK)
            setPixel(bmp, 20, 19, PixelPalette.TRUNK_DARK)

            // Flat axe-hewn wood surface
            fillRect(bmp, 7, 8, 18, 12, PixelPalette.WOOD_BEAM_LIGHT)
            fillRect(bmp, 8, 9, 17, 11, PixelPalette.DIRT_LIGHT)

            // Concentric rings & axe chop cut
            for (x in 10..15) setPixel(bmp, x, 10, PixelPalette.WOOD_BEAM_MID)
            setPixel(bmp, 12, 10, PixelPalette.WOOD_BEAM_DARK)
            // Chop mark notch
            setPixel(bmp, 10, 8, PixelPalette.TRUNK_DARK)
        }

        // LARGE STUMP (Ancient Cedar): 36x28 pixels
        stumpBitmaps[TreeVariant.LARGE] = createPixelBitmap(36, 28) { bmp ->
            // Disturbed earth & massive root flare
            fillRect(bmp, 4, 22, 31, 27, PixelPalette.FARM_SOIL_DARK)
            setPixel(bmp, 5, 24, PixelPalette.DIRT_LIGHT)
            setPixel(bmp, 9, 25, PixelPalette.WOOD_BEAM_LIGHT)
            setPixel(bmp, 26, 25, PixelPalette.WOOD_BEAM_LIGHT)
            setPixel(bmp, 30, 24, PixelPalette.DIRT_LIGHT)

            // Massive buttress roots
            fillRect(bmp, 8, 12, 27, 24, PixelPalette.TRUNK_DARK)
            fillRect(bmp, 10, 12, 25, 23, PixelPalette.TRUNK_MID)
            fillRect(bmp, 6, 18, 9, 24, PixelPalette.TRUNK_DARK)
            fillRect(bmp, 26, 18, 29, 24, PixelPalette.TRUNK_DARK)

            // Flat hewn ancient cedar ring surface
            fillRect(bmp, 10, 7, 25, 12, PixelPalette.WOOD_BEAM_LIGHT)
            fillRect(bmp, 11, 8, 24, 11, PixelPalette.DIRT_LIGHT)

            // Outer ring
            for (x in 12..23) setPixel(bmp, x, 9, PixelPalette.WOOD_BEAM_MID)
            for (x in 13..22) setPixel(bmp, x, 10, PixelPalette.WOOD_BEAM_MID)
            // Inner heartwood
            fillRect(bmp, 16, 9, 19, 10, PixelPalette.TRUNK_MID)
            setPixel(bmp, 17, 9, PixelPalette.WOOD_BEAM_DARK)
            // Axe notch wedge cut
            fillRect(bmp, 13, 7, 15, 8, PixelPalette.TRUNK_DARK)
        }
    }

    // --- 2. PLAYER CHOPPING ANIMATION SPRITES (Visible Axe in hand, 2 frames per direction x 3 axe levels) ---
    private fun generatePlayerChopSprites() {
        for (dir in Direction.entries) {
            for (frame in 0..1) {
                for (lvl in 1..3) {
                    playerChopBitmaps[Triple(dir, frame, lvl)] = createPlayerChopBitmap(dir, frame, lvl)
                }
            }
        }
    }

    private fun createPlayerChopBitmap(dir: Direction, frame: Int, axeLevel: Int = 1): Bitmap {
        val w = 24 // wider canvas to accommodate the swinging axe
        val h = 26
        return createPixelBitmap(w, h) { bmp ->
            val (axeHead, axeShine, woodHandle) = when (axeLevel) {
                2 -> Triple(0xFF627584.toInt(), 0xFFAEC0CC.toInt(), PixelPalette.WOOD_BEAM_MID) // Level 2: Tempered Steel
                3 -> Triple(0xFF334F69.toInt(), PixelPalette.GOLD_BRIGHT, 0xFF452718.toInt()) // Level 3: Numidian Damascus Steel with Gold inlays
                else -> Triple(0xFFC2723A.toInt(), 0xFFEAA668.toInt(), PixelPalette.WOOD_BEAM_LIGHT) // Level 1: Bronze
            }

            when (dir) {
                Direction.DOWN -> {
                    // Body
                    fillRect(bmp, 8, 4, 15, 6, PixelPalette.HAIR_DARK)
                    fillRect(bmp, 7, 6, 16, 9, PixelPalette.SKIN_LIGHT)
                    fillRect(bmp, 7, 6, 16, 6, PixelPalette.VEST_TERRACOTTA) // headband

                    fillRect(bmp, 7, 10, 16, 15, PixelPalette.TUNIC_CREAM)
                    fillRect(bmp, 7, 10, 9, 14, PixelPalette.VEST_TERRACOTTA)
                    fillRect(bmp, 14, 10, 16, 14, PixelPalette.VEST_TERRACOTTA)
                    fillRect(bmp, 7, 15, 16, 15, PixelPalette.SASH_BLUE)

                    fillRect(bmp, 7, 16, 10, 23, PixelPalette.BOOTS_LEATHER)
                    fillRect(bmp, 13, 16, 16, 23, PixelPalette.BOOTS_LEATHER)

                    if (frame == 0) {
                        // Frame 0: Windup - Axe held high above shoulder
                        fillRect(bmp, 14, 7, 17, 11, PixelPalette.SKIN_MID) // raised arm
                        // Handle tilted up
                        setPixel(bmp, 17, 6, woodHandle)
                        setPixel(bmp, 18, 5, woodHandle)
                        setPixel(bmp, 19, 4, woodHandle)
                        setPixel(bmp, 20, 3, woodHandle)
                        // Axe head
                        fillRect(bmp, 20, 1, 23, 4, axeHead)
                        setPixel(bmp, 21, 2, axeShine)
                    } else {
                        // Frame 1: Impact Strike - Axe brought down hard in front
                        fillRect(bmp, 9, 12, 14, 15, PixelPalette.SKIN_MID) // hands thrust forward
                        // Handle pointing down
                        fillRect(bmp, 11, 15, 12, 21, woodHandle)
                        // Axe head at bottom striking tree/log
                        fillRect(bmp, 10, 21, 14, 24, axeHead)
                        setPixel(bmp, 11, 22, axeShine)
                        // Tiny impact sparks
                        setPixel(bmp, 8, 22, PixelPalette.GOLD_BRIGHT)
                        setPixel(bmp, 15, 22, PixelPalette.GOLD_BRIGHT)
                    }
                }

                Direction.UP -> {
                    // Back view
                    fillRect(bmp, 8, 4, 15, 9, PixelPalette.HAIR_DARK)
                    fillRect(bmp, 7, 10, 16, 15, PixelPalette.VEST_TERRACOTTA)
                    fillRect(bmp, 7, 15, 16, 15, PixelPalette.SASH_BLUE)
                    fillRect(bmp, 8, 16, 10, 23, PixelPalette.BOOTS_LEATHER)
                    fillRect(bmp, 13, 16, 15, 23, PixelPalette.BOOTS_LEATHER)

                    if (frame == 0) {
                        // Windup: Arms up
                        fillRect(bmp, 6, 8, 8, 11, PixelPalette.TUNIC_CREAM)
                        fillRect(bmp, 15, 8, 17, 11, PixelPalette.TUNIC_CREAM)
                        // Handle
                        fillRect(bmp, 11, 4, 12, 10, woodHandle)
                        fillRect(bmp, 10, 1, 13, 4, axeHead)
                        setPixel(bmp, 11, 2, axeShine)
                    } else {
                        // Strike upward into tree trunk
                        fillRect(bmp, 9, 6, 14, 9, PixelPalette.SKIN_MID)
                        fillRect(bmp, 11, 1, 12, 7, woodHandle)
                        fillRect(bmp, 9, 0, 14, 3, axeHead)
                        setPixel(bmp, 10, 1, axeShine)
                        setPixel(bmp, 8, 1, PixelPalette.GOLD_BRIGHT)
                        setPixel(bmp, 15, 1, PixelPalette.GOLD_BRIGHT)
                    }
                }

                Direction.LEFT -> {
                    // Facing left
                    fillRect(bmp, 9, 4, 15, 6, PixelPalette.HAIR_DARK)
                    fillRect(bmp, 8, 6, 14, 9, PixelPalette.SKIN_LIGHT)
                    fillRect(bmp, 8, 6, 14, 6, PixelPalette.VEST_TERRACOTTA)

                    fillRect(bmp, 8, 10, 14, 15, PixelPalette.TUNIC_CREAM)
                    fillRect(bmp, 9, 10, 12, 14, PixelPalette.VEST_TERRACOTTA)
                    fillRect(bmp, 8, 15, 14, 15, PixelPalette.SASH_BLUE)

                    fillRect(bmp, 7, 16, 10, 23, PixelPalette.BOOTS_LEATHER)
                    fillRect(bmp, 11, 16, 14, 21, PixelPalette.BOOTS_LEATHER)

                    if (frame == 0) {
                        // Windup to the right
                        fillRect(bmp, 13, 10, 16, 13, PixelPalette.SKIN_MID)
                        fillRect(bmp, 16, 6, 18, 12, woodHandle)
                        fillRect(bmp, 17, 3, 21, 6, axeHead)
                        setPixel(bmp, 18, 4, axeShine)
                    } else {
                        // Chopping forward to the left
                        fillRect(bmp, 5, 11, 8, 14, PixelPalette.SKIN_MID)
                        fillRect(bmp, 1, 12, 7, 13, woodHandle)
                        fillRect(bmp, 0, 10, 3, 15, axeHead)
                        setPixel(bmp, 1, 11, axeShine)
                        setPixel(bmp, 3, 9, PixelPalette.GOLD_BRIGHT)
                    }
                }

                Direction.RIGHT -> {
                    // Facing right
                    fillRect(bmp, 9, 4, 15, 6, PixelPalette.HAIR_DARK)
                    fillRect(bmp, 10, 6, 16, 9, PixelPalette.SKIN_LIGHT)
                    fillRect(bmp, 10, 6, 16, 6, PixelPalette.VEST_TERRACOTTA)

                    fillRect(bmp, 10, 10, 16, 15, PixelPalette.TUNIC_CREAM)
                    fillRect(bmp, 12, 10, 15, 14, PixelPalette.VEST_TERRACOTTA)
                    fillRect(bmp, 10, 15, 16, 15, PixelPalette.SASH_BLUE)

                    fillRect(bmp, 14, 16, 17, 23, PixelPalette.BOOTS_LEATHER)
                    fillRect(bmp, 10, 16, 13, 21, PixelPalette.BOOTS_LEATHER)

                    if (frame == 0) {
                        // Windup to the left
                        fillRect(bmp, 8, 10, 11, 13, PixelPalette.SKIN_MID)
                        fillRect(bmp, 6, 6, 8, 12, woodHandle)
                        fillRect(bmp, 3, 3, 7, 6, axeHead)
                        setPixel(bmp, 5, 4, axeShine)
                    } else {
                        // Chopping forward to the right
                        fillRect(bmp, 16, 11, 19, 14, PixelPalette.SKIN_MID)
                        fillRect(bmp, 17, 12, 23, 13, woodHandle)
                        fillRect(bmp, 21, 10, 24, 15, axeHead)
                        setPixel(bmp, 22, 11, axeShine)
                        setPixel(bmp, 20, 9, PixelPalette.GOLD_BRIGHT)
                    }
                }
            }
        }
    }

    // --- 3. FOREST FLOOR DECORATIVE DETAILS ---
    private fun generateForestFloorDetails() {
        // Fallen tree branch / log (20x10 pixels)
        fallenBranchBmp = createPixelBitmap(20, 10) { bmp ->
            // Main branch
            fillRect(bmp, 2, 4, 17, 6, PixelPalette.TRUNK_MID)
            fillRect(bmp, 3, 5, 16, 6, PixelPalette.TRUNK_DARK)
            setPixel(bmp, 4, 4, PixelPalette.TRUNK_LIGHT)
            setPixel(bmp, 11, 4, PixelPalette.TRUNK_LIGHT)

            // Side twig
            setPixel(bmp, 7, 3, PixelPalette.TRUNK_MID)
            setPixel(bmp, 8, 2, PixelPalette.TRUNK_MID)
            setPixel(bmp, 8, 1, PixelPalette.CEDAR_LEAF_LIGHT) // green pine needle

            // Cut tip
            setPixel(bmp, 2, 5, PixelPalette.WOOD_BEAM_LIGHT)
            setPixel(bmp, 18, 5, PixelPalette.WOOD_BEAM_MID)
        }

        // Wild forest mushrooms (14x12 pixels)
        forestMushroomBmp = createPixelBitmap(14, 12) { bmp ->
            // Stems
            fillRect(bmp, 4, 6, 5, 10, PixelPalette.WALL_STUCCO_LIGHT)
            fillRect(bmp, 9, 7, 10, 10, PixelPalette.WALL_STUCCO_LIGHT)

            // Red mushroom cap with white spots
            fillRect(bmp, 2, 3, 7, 5, PixelPalette.TOMATO_RED)
            setPixel(bmp, 3, 2, PixelPalette.TOMATO_RED)
            setPixel(bmp, 4, 2, PixelPalette.TOMATO_RED)
            setPixel(bmp, 5, 2, PixelPalette.TOMATO_RED)
            setPixel(bmp, 6, 2, PixelPalette.TOMATO_RED)
            setPixel(bmp, 4, 3, 0xFFFFFFFF.toInt())
            setPixel(bmp, 6, 4, 0xFFFFFFFF.toInt())

            // Brown mushroom cap
            fillRect(bmp, 8, 5, 12, 6, PixelPalette.VEST_TERRACOTTA)
            setPixel(bmp, 9, 4, PixelPalette.VEST_TERRACOTTA)
            setPixel(bmp, 10, 4, PixelPalette.VEST_TERRACOTTA)
            setPixel(bmp, 11, 4, PixelPalette.VEST_TERRACOTTA)
        }
    }
}
