package com.example.game.quest

import com.example.game.economy.EconomyManager
import com.example.game.farming.CropType
import com.example.game.items.Inventory
import com.example.game.items.Item
import com.example.game.items.ItemCatalog
import com.example.game.npc.NPCId
import com.example.game.relationship.RelationshipLevel
import com.example.game.relationship.RelationshipManager
import com.example.game.world.ZoneId

sealed class AcceptQuestResult {
    data class Success(val quest: QuestInstance, val messageArabic: String) : AcceptQuestResult()
    data class LimitReached(val messageArabic: String) : AcceptQuestResult()
    data class Error(val reasonArabic: String) : AcceptQuestResult()
}

data class QuestRewardClaimResult(
    val quest: QuestInstance,
    val moneyEarned: Int,
    val itemsEarned: List<Pair<String, Int>>,
    val affinityEarned: Int,
    val newRelationshipLevel: RelationshipLevel?,
    val messageArabic: String
)

enum class QuestMarkerType {
    NONE,
    AVAILABLE, // "!"
    TURN_IN    // "?"
}

class QuestManager {

    companion object {
        const val MAX_ACTIVE_QUESTS = 3
    }

    val instances: MutableMap<String, QuestInstance> = mutableMapOf()

    init {
        initializeDatabase()
    }

    private fun initializeDatabase() {
        instances.clear()
        for (def in QuestDatabase.ALL_QUESTS) {
            instances[def.id] = QuestInstance(definition = def, state = QuestState.AVAILABLE)
        }
        refreshAvailableQuests()
    }

    /**
     * Updates states of AVAILABLE quests based on whether prerequisites are completed.
     */
    fun refreshAvailableQuests() {
        val completedIds = getCompletedQuests().map { it.definition.id }.toSet()

        for (instance in instances.values) {
            if (instance.state == QuestState.ACTIVE ||
                instance.state == QuestState.COMPLETED ||
                instance.state == QuestState.COMPLETED_PENDING_REWARD
            ) {
                continue
            }

            val prereqsMet = instance.definition.prerequisiteQuestIds.all { it in completedIds }
            instance.state = if (prereqsMet) QuestState.AVAILABLE else QuestState.AVAILABLE
        }
    }

    fun getActiveQuests(): List<QuestInstance> {
        return instances.values.filter {
            it.state == QuestState.ACTIVE || it.state == QuestState.COMPLETED_PENDING_REWARD
        }
    }

    fun getAvailableQuests(): List<QuestInstance> {
        val completedIds = getCompletedQuests().map { it.definition.id }.toSet()
        return instances.values.filter { instance ->
            instance.state == QuestState.AVAILABLE &&
                !instance.rewardClaimed &&
                instance.definition.prerequisiteQuestIds.all { it in completedIds }
        }
    }

    fun getCompletedQuests(): List<QuestInstance> {
        return instances.values.filter { it.state == QuestState.COMPLETED && it.rewardClaimed }
    }

    fun canAcceptMoreQuests(): Boolean = getActiveQuests().size < MAX_ACTIVE_QUESTS

    fun getAvailableQuestsForNpc(npcId: NPCId): List<QuestInstance> {
        return getAvailableQuests().filter { it.definition.giverNpcId == npcId }
    }

    fun getTurnInQuestForNpc(npcId: NPCId): QuestInstance? {
        return instances.values.find {
            it.definition.giverNpcId == npcId &&
                it.state == QuestState.COMPLETED_PENDING_REWARD &&
                !it.rewardClaimed
        }
    }

    fun getActiveQuestForNpc(npcId: NPCId): QuestInstance? {
        return instances.values.find {
            it.definition.giverNpcId == npcId &&
                it.state == QuestState.ACTIVE
        }
    }

    /**
     * Determines marker to render above an NPC's head.
     * Priority: TURN_IN ("?") > AVAILABLE ("!") > NONE
     */
    fun getNpcQuestMarker(npcId: NPCId): QuestMarkerType {
        if (getTurnInQuestForNpc(npcId) != null) {
            return QuestMarkerType.TURN_IN
        }
        if (getAvailableQuestsForNpc(npcId).isNotEmpty()) {
            return QuestMarkerType.AVAILABLE
        }
        return QuestMarkerType.NONE
    }

    fun acceptQuest(questId: String): AcceptQuestResult {
        val instance = instances[questId] ?: return AcceptQuestResult.Error("المهمة غير موجودة.")

        if (instance.state == QuestState.ACTIVE || instance.state == QuestState.COMPLETED_PENDING_REWARD) {
            return AcceptQuestResult.Error("هذه المهمة نشطة بالفعل.")
        }

        if (instance.state == QuestState.COMPLETED && instance.rewardClaimed) {
            return AcceptQuestResult.Error("تم إكمال هذه المهمة مسبقاً.")
        }

        if (!canAcceptMoreQuests()) {
            return AcceptQuestResult.LimitReached("المهام النشطة ممتلئة. أكمل إحدى مهامك أولاً.")
        }

        // Verify prerequisites
        val completedIds = getCompletedQuests().map { it.definition.id }.toSet()
        val prereqsMet = instance.definition.prerequisiteQuestIds.all { it in completedIds }
        if (!prereqsMet) {
            return AcceptQuestResult.Error("لم تستوفِ متطلبات هذه المهمة بعد.")
        }

        instance.state = QuestState.ACTIVE
        // Reset progress counters
        for (i in instance.progress.indices) {
            instance.progress[i] = 0
        }
        instance.rewardClaimed = false

        return AcceptQuestResult.Success(
            quest = instance,
            messageArabic = "تم قبول مهمة: ${instance.definition.titleArabic}"
        )
    }

    // --- EVENT TRACKING HANDLERS ---

    fun onCropHarvested(crop: CropType): Boolean {
        var anyObjectiveUpdated = false
        for (instance in instances.values) {
            if (instance.state != QuestState.ACTIVE) continue

            for (i in instance.definition.objectives.indices) {
                val obj = instance.definition.objectives[i]
                if (obj.type == ObjectiveType.HARVEST_CROP) {
                    if (obj.targetCropId == null || obj.targetCropId == crop.id) {
                        instance.addProgress(i, 1)
                        anyObjectiveUpdated = true
                    }
                }
            }

            checkAndTransitionCompletion(instance)
        }
        return anyObjectiveUpdated
    }

    fun onItemSold(item: Item, quantity: Int, totalValue: Int): Boolean {
        var anyObjectiveUpdated = false
        for (instance in instances.values) {
            if (instance.state != QuestState.ACTIVE) continue

            for (i in instance.definition.objectives.indices) {
                val obj = instance.definition.objectives[i]
                if (obj.type == ObjectiveType.SELL_ITEM) {
                    if (obj.targetItemId == null || obj.targetItemId == item.id) {
                        instance.addProgress(i, quantity)
                        anyObjectiveUpdated = true
                    }
                } else if (obj.type == ObjectiveType.SELL_VALUE) {
                    instance.addProgress(i, totalValue)
                    anyObjectiveUpdated = true
                }
            }

            checkAndTransitionCompletion(instance)
        }
        return anyObjectiveUpdated
    }

    fun onItemPurchased(item: Item, quantity: Int, totalCost: Int): Boolean {
        var anyObjectiveUpdated = false
        for (instance in instances.values) {
            if (instance.state != QuestState.ACTIVE) continue

            for (i in instance.definition.objectives.indices) {
                val obj = instance.definition.objectives[i]
                if (obj.type == ObjectiveType.BUY_ITEM) {
                    if (obj.targetItemId == null || obj.targetItemId == item.id) {
                        instance.addProgress(i, quantity)
                        anyObjectiveUpdated = true
                    }
                }
            }

            checkAndTransitionCompletion(instance)
        }
        return anyObjectiveUpdated
    }

    fun onWoodCollected(quantity: Int): Boolean {
        var anyObjectiveUpdated = false
        for (instance in instances.values) {
            if (instance.state != QuestState.ACTIVE) continue

            for (i in instance.definition.objectives.indices) {
                val obj = instance.definition.objectives[i]
                if (obj.type == ObjectiveType.GATHER_WOOD || obj.type == ObjectiveType.COLLECT_ITEM) {
                    instance.addProgress(i, quantity)
                    anyObjectiveUpdated = true
                }
            }

            checkAndTransitionCompletion(instance)
        }
        return anyObjectiveUpdated
    }

    fun onNpcTalkedTo(npcId: NPCId): Boolean {
        var anyObjectiveUpdated = false
        for (instance in instances.values) {
            if (instance.state != QuestState.ACTIVE) continue

            for (i in instance.definition.objectives.indices) {
                val obj = instance.definition.objectives[i]
                if (obj.type == ObjectiveType.TALK_TO_NPC) {
                    if (obj.targetNpcId == null || obj.targetNpcId == npcId.idString) {
                        instance.addProgress(i, 1)
                        anyObjectiveUpdated = true
                    }
                }
            }

            checkAndTransitionCompletion(instance)
        }
        return anyObjectiveUpdated
    }

    fun onLocationVisited(zoneId: ZoneId): Boolean {
        var anyObjectiveUpdated = false
        for (instance in instances.values) {
            if (instance.state != QuestState.ACTIVE) continue

            for (i in instance.definition.objectives.indices) {
                val obj = instance.definition.objectives[i]
                if (obj.type == ObjectiveType.VISIT_LOCATION) {
                    if (obj.targetLocation == null || obj.targetLocation == zoneId.name) {
                        instance.addProgress(i, 1)
                        anyObjectiveUpdated = true
                    }
                }
            }

            checkAndTransitionCompletion(instance)
        }
        return anyObjectiveUpdated
    }

    private fun checkAndTransitionCompletion(instance: QuestInstance) {
        if (instance.state == QuestState.ACTIVE && instance.isAllObjectivesCompleted()) {
            instance.state = QuestState.COMPLETED_PENDING_REWARD
        }
    }

    /**
     * Atomically turns in quest, grants rewards, updates relationship, and marks completed.
     */
    fun completeQuestAndClaimReward(
        questId: String,
        economy: EconomyManager,
        inventory: Inventory,
        relationshipManager: RelationshipManager
    ): QuestRewardClaimResult? {
        val instance = instances[questId] ?: return null

        if (instance.state != QuestState.COMPLETED_PENDING_REWARD || instance.rewardClaimed) {
            return null
        }

        // 1. Grant Money
        val reward = instance.definition.reward
        if (reward.money > 0) {
            economy.addMoney(reward.money)
        }

        // 2. Grant Items
        val itemsGiven = mutableListOf<Pair<String, Int>>()
        for ((itemId, qty) in reward.items) {
            val item = ItemCatalog.findById(itemId)
            if (item != null) {
                inventory.addItem(item, qty)
                itemsGiven.add(itemId to qty)
            }
        }

        // 3. Grant Relationship Affinity
        val (affinityChanged, newLevel) = relationshipManager.onQuestCompleted(
            npcId = instance.definition.giverNpcId,
            affinityBonus = reward.affinityBonus
        )

        // 4. Atomic finalize
        instance.rewardClaimed = true
        instance.state = QuestState.COMPLETED

        // 5. Unlock subsequent quests
        refreshAvailableQuests()

        return QuestRewardClaimResult(
            quest = instance,
            moneyEarned = reward.money,
            itemsEarned = itemsGiven,
            affinityEarned = reward.affinityBonus,
            newRelationshipLevel = newLevel,
            messageArabic = "تم إكمال المهمة: ${instance.definition.titleArabic} بنجاح!"
        )
    }

    // --- SAVE & RESTORE SERIALIZATION ---

    /**
     * Serialized format: questId:stateName:rewardClaimed:p0,p1,p2|questId:...
     */
    fun toSerialized(): String {
        return instances.values.joinToString("|") { q ->
            val progressStr = q.progress.joinToString(",")
            "${q.definition.id}:${q.state.name}:${q.rewardClaimed}:$progressStr"
        }
    }

    fun loadFromSerialized(raw: String) {
        if (raw.isBlank()) {
            initializeDatabase()
            return
        }

        val entries = raw.split("|")
        for (entry in entries) {
            val parts = entry.split(":")
            if (parts.size >= 4) {
                val qId = parts[0]
                val stateStr = parts[1]
                val claimed = parts[2].toBooleanStrictOrNull() ?: false
                val progRaw = parts[3]

                val instance = instances[qId]
                if (instance != null) {
                    val loadedState = try {
                        QuestState.valueOf(stateStr)
                    } catch (e: Exception) {
                        QuestState.AVAILABLE
                    }
                    instance.state = loadedState
                    instance.rewardClaimed = claimed

                    val progTokens = progRaw.split(",").mapNotNull { it.toIntOrNull() }
                    for (i in progTokens.indices) {
                        if (i in instance.progress.indices) {
                            instance.progress[i] = progTokens[i]
                        }
                    }
                }
            }
        }

        refreshAvailableQuests()
    }
}
