package com.example.game.time

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

class WorldTimeManager(
    initialDay: Int = DEFAULT_START_DAY,
    initialHour: Int = DEFAULT_START_HOUR,
    initialMinute: Int = DEFAULT_START_MINUTE
) {
    companion object {
        const val DEFAULT_START_DAY = 1
        const val DEFAULT_START_HOUR = 8
        const val DEFAULT_START_MINUTE = 0
        const val WORLD_TIME_VERSION = 1

        // Accelerated game clock: 1 real second = 1 game minute
        // 60 real seconds = 1 game hour, 24 real minutes = 1 complete 24h game day
        var GAME_MINUTES_PER_REAL_SECOND = 1.0f

        // Offline catch-up limit: maximum 6 game hours can advance while game is closed
        const val MAX_OFFLINE_WORLD_TIME_MINUTES = 6 * 60 // 360 game minutes
    }

    var currentDay: Int by mutableIntStateOf(initialDay.coerceAtLeast(1))
        private set

    var currentHour: Int by mutableIntStateOf(initialHour.coerceIn(0, 23))
        private set

    var currentMinute: Int by mutableIntStateOf(initialMinute.coerceIn(0, 59))
        private set

    var totalGameMinutes: Long by mutableLongStateOf(
        calculateTotalMinutes(currentDay, currentHour, currentMinute)
    )
        private set

    var timeOfDay: TimeOfDay by mutableStateOf(TimeOfDay.fromHour(currentHour))
        private set

    val isNight: Boolean
        get() = timeOfDay.isNighttime

    val formattedTime: String
        get() = String.format(Locale.ROOT, "%02d:%02d", currentHour, currentMinute)

    val formattedDay: String
        get() = "اليوم $currentDay"

    val formattedFullStatus: String
        get() = "اليوم $currentDay • ${timeOfDay.nameArabic} • $formattedTime"

    // Progress within current 24-hour cycle: 0.0f (00:00) to 1.0f (23:59)
    val dayProgress: Float
        get() = (currentHour * 60 + currentMinute) / 1440.0f

    // Event hooks
    var onMinuteChanged: ((hour: Int, minute: Int) -> Unit)? = null
    var onHourChanged: ((hour: Int) -> Unit)? = null
    var onTimeOfDayChanged: ((newTimeOfDay: TimeOfDay) -> Unit)? = null
    var onDayChanged: ((newDay: Int) -> Unit)? = null
    var onNightStarted: (() -> Unit)? = null
    var onMorningStarted: (() -> Unit)? = null

    private var secondAccumulator = 0f

    fun update(deltaTimeSec: Float) {
        if (deltaTimeSec <= 0f) return

        secondAccumulator += deltaTimeSec
        val secondsPerGameMinute = 1.0f / GAME_MINUTES_PER_REAL_SECOND

        if (secondAccumulator >= secondsPerGameMinute) {
            val minutesToAdvance = (secondAccumulator / secondsPerGameMinute).toInt()
            secondAccumulator %= secondsPerGameMinute
            if (minutesToAdvance > 0) {
                advanceMinutes(minutesToAdvance.toLong())
            }
        }
    }

    fun advanceMinutes(minutes: Long) {
        if (minutes <= 0L) return

        val prevMinute = currentMinute
        val prevHour = currentHour
        val prevDay = currentDay
        val prevTimeOfDay = timeOfDay

        totalGameMinutes += minutes

        val totalMinsInCurrentDay = (currentHour * 60 + currentMinute + minutes)
        val daysAdded = (totalMinsInCurrentDay / 1440).toInt()
        val remainingDayMinutes = (totalMinsInCurrentDay % 1440).toInt()

        currentDay += daysAdded
        currentHour = remainingDayMinutes / 60
        currentMinute = remainingDayMinutes % 60
        timeOfDay = TimeOfDay.fromHour(currentHour)

        // Trigger Event Hooks
        if (currentMinute != prevMinute) {
            onMinuteChanged?.invoke(currentHour, currentMinute)
        }
        if (currentHour != prevHour) {
            onHourChanged?.invoke(currentHour)
        }
        if (timeOfDay != prevTimeOfDay) {
            onTimeOfDayChanged?.invoke(timeOfDay)
            if (timeOfDay == TimeOfDay.DUSK || timeOfDay == TimeOfDay.NIGHT) {
                onNightStarted?.invoke()
            }
            if (timeOfDay == TimeOfDay.DAWN || timeOfDay == TimeOfDay.MORNING) {
                onMorningStarted?.invoke()
            }
        }
        if (currentDay != prevDay) {
            onDayChanged?.invoke(currentDay)
        }
    }

    /**
     * Advances time while application was closed/paused, respecting the 6 game hour cap.
     */
    fun catchUpOfflineTime(lastRealTimestampMs: Long, currentRealTimestampMs: Long) {
        if (lastRealTimestampMs <= 0L || currentRealTimestampMs <= lastRealTimestampMs) return

        val elapsedRealSeconds = (currentRealTimestampMs - lastRealTimestampMs) / 1000f
        val offlineGameMinutes = (elapsedRealSeconds * GAME_MINUTES_PER_REAL_SECOND).toLong()
            .coerceIn(0L, MAX_OFFLINE_WORLD_TIME_MINUTES.toLong())

        if (offlineGameMinutes > 0L) {
            advanceMinutes(offlineGameMinutes)
        }
    }

    fun setTime(day: Int, hour: Int, minute: Int, totalMinutes: Long? = null) {
        val safeDay = day.coerceAtLeast(1)
        val safeHour = hour.coerceIn(0, 23)
        val safeMinute = minute.coerceIn(0, 59)

        currentDay = safeDay
        currentHour = safeHour
        currentMinute = safeMinute
        totalGameMinutes = totalMinutes ?: calculateTotalMinutes(safeDay, safeHour, safeMinute)
        timeOfDay = TimeOfDay.fromHour(currentHour)
        secondAccumulator = 0f
    }

    private fun calculateTotalMinutes(day: Int, hour: Int, minute: Int): Long {
        return (day.toLong() - 1L) * 1440L + (hour.toLong() * 60L) + minute.toLong()
    }
}
