package com.example.game.save

import android.content.Context
import android.content.SharedPreferences
import com.example.game.state.Direction
import com.example.game.world.ZoneId

class SaveSystem(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "numidia_game_save_v1"
        private const val KEY_HAS_SAVE = "has_save"
        private const val KEY_ZONE = "current_zone"
        private const val KEY_PLAYER_X = "player_x"
        private const val KEY_PLAYER_Y = "player_y"
        private const val KEY_PLAYER_DIR = "player_dir"
        private const val KEY_MONEY = "money"
        private const val KEY_INVENTORY = "inventory_items"
        private const val KEY_FARMING = "farming_data"
        private const val KEY_TREES = "trees_data"
        private const val KEY_MET_NPCS = "met_npcs"
        private const val KEY_WORLD_DAY = "world_day"
        private const val KEY_WORLD_HOUR = "world_hour"
        private const val KEY_WORLD_MINUTE = "world_minute"
        private const val KEY_TOTAL_GAME_MINUTES = "total_game_minutes"
        private const val KEY_TIME_VERSION = "time_version"
        private const val KEY_QUEST_DATA = "quest_data"
        private const val KEY_RELATIONSHIP_DATA = "relationship_data"
        private const val KEY_QUEST_VERSION = "quest_version"
        private const val KEY_TIMESTAMP = "timestamp"
    }

    fun hasSaveData(): Boolean = prefs.getBoolean(KEY_HAS_SAVE, false)

    fun saveGame(saveData: GameSaveData) {
        val serializedInventory = saveData.inventoryItems.joinToString(";") { "${it.first},${it.second}" }
        val serializedNpcs = saveData.metNpcIds.joinToString(",")

        prefs.edit()
            .putBoolean(KEY_HAS_SAVE, true)
            .putString(KEY_ZONE, saveData.currentZone.name)
            .putFloat(KEY_PLAYER_X, saveData.playerX)
            .putFloat(KEY_PLAYER_Y, saveData.playerY)
            .putString(KEY_PLAYER_DIR, saveData.playerDirection.name)
            .putInt(KEY_MONEY, saveData.money)
            .putString(KEY_INVENTORY, serializedInventory)
            .putString(KEY_FARMING, saveData.farmingPlotData)
            .putString(KEY_TREES, saveData.treeResourceData)
            .putString(KEY_MET_NPCS, serializedNpcs)
            .putInt(KEY_WORLD_DAY, saveData.worldDay)
            .putInt(KEY_WORLD_HOUR, saveData.worldHour)
            .putInt(KEY_WORLD_MINUTE, saveData.worldMinute)
            .putLong(KEY_TOTAL_GAME_MINUTES, saveData.totalGameMinutes)
            .putInt(KEY_TIME_VERSION, saveData.timeVersion)
            .putString(KEY_QUEST_DATA, saveData.questData)
            .putString(KEY_RELATIONSHIP_DATA, saveData.relationshipData)
            .putInt(KEY_QUEST_VERSION, saveData.questVersion)
            .putLong(KEY_TIMESTAMP, saveData.timestamp)
            .apply()
    }

    fun loadGame(): GameSaveData {
        if (!hasSaveData()) {
            return GameSaveData() // Return default initial state
        }

        val zoneName = prefs.getString(KEY_ZONE, ZoneId.VILLAGE.name)
        val zone = ZoneId.fromString(zoneName)
        val px = prefs.getFloat(KEY_PLAYER_X, 384f)
        val py = prefs.getFloat(KEY_PLAYER_Y, 460f)
        val dirName = prefs.getString(KEY_PLAYER_DIR, Direction.DOWN.name)
        val dir = try { Direction.valueOf(dirName ?: Direction.DOWN.name) } catch (e: Exception) { Direction.DOWN }
        val money = prefs.getInt(KEY_MONEY, 50)
        val invRaw = prefs.getString(KEY_INVENTORY, "") ?: ""
        val inventoryItems = if (invRaw.isNotBlank()) {
            val list = invRaw.split(";").mapNotNull { item ->
                val p = item.split(",")
                if (p.size == 2) {
                    val id = p[0]
                    val qty = p[1].toIntOrNull() ?: 1
                    id to qty
                } else null
            }.toMutableList()

            // Gracefully ensure starter items (axe and seeds) exist even if loaded from older stage save
            val existingIds = list.map { it.first }.toSet()
            val starters = listOf(
                "bronze_axe" to 1,
                "carrot_seeds" to 3,
                "tomato_seeds" to 2,
                "potato_seeds" to 2,
                "onion_seeds" to 1,
                "pepper_seeds" to 1
            )
            for (st in starters) {
                if (!existingIds.contains(st.first)) {
                    list.add(st)
                }
            }
            list
        } else {
            listOf(
                "bronze_axe" to 1,
                "carrot_seeds" to 3,
                "tomato_seeds" to 2,
                "potato_seeds" to 2,
                "onion_seeds" to 1,
                "pepper_seeds" to 1,
                "wheat_seeds" to 5,
                "water_jug" to 1
            )
        }
        val farmData = prefs.getString(KEY_FARMING, "") ?: ""
        val treeData = prefs.getString(KEY_TREES, "") ?: ""
        val metRaw = prefs.getString(KEY_MET_NPCS, "") ?: ""
        val metNpcIds = if (metRaw.isNotBlank()) metRaw.split(",").filter { it.isNotBlank() } else emptyList()

        val worldDay = prefs.getInt(KEY_WORLD_DAY, 1).coerceAtLeast(1)
        val worldHour = prefs.getInt(KEY_WORLD_HOUR, 8).coerceIn(0, 23)
        val worldMinute = prefs.getInt(KEY_WORLD_MINUTE, 0).coerceIn(0, 59)
        val defaultTotalMins = (worldDay - 1L) * 1440L + worldHour * 60L + worldMinute
        val totalGameMinutes = prefs.getLong(KEY_TOTAL_GAME_MINUTES, defaultTotalMins)
        val timeVersion = prefs.getInt(KEY_TIME_VERSION, 1)

        val questData = prefs.getString(KEY_QUEST_DATA, "") ?: ""
        val relationshipData = prefs.getString(KEY_RELATIONSHIP_DATA, "") ?: ""
        val questVersion = prefs.getInt(KEY_QUEST_VERSION, 1)

        val timestamp = prefs.getLong(KEY_TIMESTAMP, System.currentTimeMillis())

        return GameSaveData(
            currentZone = zone,
            playerX = px,
            playerY = py,
            playerDirection = dir,
            money = money,
            inventoryItems = inventoryItems,
            farmingPlotData = farmData,
            treeResourceData = treeData,
            metNpcIds = metNpcIds,
            worldDay = worldDay,
            worldHour = worldHour,
            worldMinute = worldMinute,
            totalGameMinutes = totalGameMinutes,
            timeVersion = timeVersion,
            questData = questData,
            relationshipData = relationshipData,
            questVersion = questVersion,
            timestamp = timestamp
        )
    }

    fun resetSave() {
        prefs.edit().clear().apply()
    }
}
