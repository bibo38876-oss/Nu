package com.example.game.quest

class QuestInstance(
    val definition: QuestDefinition,
    var state: QuestState = QuestState.AVAILABLE,
    val progress: MutableList<Int> = MutableList(definition.objectives.size) { 0 },
    var rewardClaimed: Boolean = false
) {
    fun isAllObjectivesCompleted(): Boolean {
        for (i in definition.objectives.indices) {
            if (progress.getOrElse(i) { 0 } < definition.objectives[i].targetCount) {
                return false
            }
        }
        return true
    }

    fun getObjectiveProgress(index: Int): Int = progress.getOrElse(index) { 0 }

    fun setObjectiveProgress(index: Int, value: Int) {
        if (index in progress.indices) {
            val maxTarget = definition.objectives[index].targetCount
            progress[index] = value.coerceIn(0, maxTarget)
        }
    }

    /**
     * Adds progress to an objective and returns true if this objective reached its target.
     */
    fun addProgress(index: Int, amount: Int): Boolean {
        if (index in progress.indices) {
            val target = definition.objectives[index].targetCount
            val current = progress[index]
            val updated = (current + amount).coerceAtMost(target)
            progress[index] = updated
            return updated >= target
        }
        return false
    }

    fun reset() {
        state = QuestState.AVAILABLE
        for (i in progress.indices) {
            progress[i] = 0
        }
        rewardClaimed = false
    }
}
