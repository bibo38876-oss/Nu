package com.example.game.engine

import android.graphics.RectF
import com.example.game.state.PlayerState

object CollisionSystem {

    /**
     * Checks if a proposed player position collides with any collider in the zone.
     */
    fun checkCollision(
        targetX: Float,
        targetY: Float,
        playerState: PlayerState,
        colliders: List<RectF>
    ): Boolean {
        val halfW = 9f
        val footTop = targetY + 2f
        val footBottom = targetY + 14f
        val pLeft = targetX - halfW
        val pRight = targetX + halfW

        for (box in colliders) {
            if (pLeft < box.right && pRight > box.left &&
                footTop < box.bottom && footBottom > box.top
            ) {
                return true
            }
        }
        return false
    }

    /**
     * Resolves movement with sliding collision:
     * Attempts full move (dx, dy).
     * If blocked, attempts (dx, 0).
     * If blocked, attempts (0, dy).
     */
    fun resolveMovement(
        currentX: Float,
        currentY: Float,
        dx: Float,
        dy: Float,
        playerState: PlayerState,
        colliders: List<RectF>
    ): Pair<Float, Float> {
        if (dx == 0f && dy == 0f) return Pair(currentX, currentY)

        // Safety: If current position is already stuck inside a collider, unstuck first
        val (startX, startY) = if (checkCollision(currentX, currentY, playerState, colliders)) {
            unstuckIfNeeded(currentX, currentY, playerState, colliders)
        } else {
            Pair(currentX, currentY)
        }

        val targetX = startX + dx
        val targetY = startY + dy

        // Try direct diagonal movement
        if (!checkCollision(targetX, targetY, playerState, colliders)) {
            return Pair(targetX, targetY)
        }

        // Try horizontal sliding
        var finalX = startX
        if (dx != 0f && !checkCollision(targetX, startY, playerState, colliders)) {
            finalX = targetX
        }

        // Try vertical sliding
        var finalY = startY
        if (dy != 0f && !checkCollision(finalX, targetY, playerState, colliders)) {
            finalY = targetY
        }

        return Pair(finalX, finalY)
    }

    /**
     * Nudges the player out of an obstacle if they spawned or clipped inside one.
     */
    fun unstuckIfNeeded(
        currentX: Float,
        currentY: Float,
        playerState: PlayerState,
        colliders: List<RectF>
    ): Pair<Float, Float> {
        if (!checkCollision(currentX, currentY, playerState, colliders)) {
            return Pair(currentX, currentY)
        }
        val nudgeDistances = listOf(4f, 8f, 16f, 24f, 36f, 48f)
        val directions = listOf(
            0f to 1f,   // Down
            0f to -1f,  // Up
            1f to 0f,   // Right
            -1f to 0f,  // Left
            1f to 1f,
            -1f to 1f,
            1f to -1f,
            -1f to -1f
        )
        for (dist in nudgeDistances) {
            for ((nx, ny) in directions) {
                val testX = currentX + nx * dist
                val testY = currentY + ny * dist
                if (!checkCollision(testX, testY, playerState, colliders)) {
                    return Pair(testX, testY)
                }
            }
        }
        return Pair(currentX, currentY)
    }
}
