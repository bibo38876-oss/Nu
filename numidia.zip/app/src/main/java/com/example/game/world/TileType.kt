package com.example.game.world

enum class TileType(val isSolid: Boolean) {
    GRASS(false),
    FOREST_GRASS(false),
    DIRT_PATH(false),
    COBBLESTONE(false),
    FARM_SOIL(false),
    WATER_WELL(true),
    STONE_BORDER(true);

    companion object {
        const val TILE_SIZE = 32f // Standard tile size in world units
    }
}
