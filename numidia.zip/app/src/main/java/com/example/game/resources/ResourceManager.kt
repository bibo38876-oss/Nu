package com.example.game.resources

import kotlin.math.sqrt

class ResourceManager {
    private val nodes = mutableMapOf<String, ResourceNode>()

    init {
        initializeDefaultForestNodes()
    }

    /**
     * Initializes the default trees for the Forest zone.
     * Contains varied sizes: Small (2 wood), Medium (4 wood), Large (7 wood).
     */
    fun initializeDefaultForestNodes() {
        nodes.clear()

        val defaultTrees = listOf(
            // --- WEST GROVE ---
            ResourceNode(id = "tree_w1", treeVariant = TreeVariant.LARGE, worldX = 130f, worldY = 230f),
            ResourceNode(id = "tree_w2", treeVariant = TreeVariant.MEDIUM, worldX = 190f, worldY = 350f),
            ResourceNode(id = "tree_w3", treeVariant = TreeVariant.LARGE, worldX = 110f, worldY = 510f),
            ResourceNode(id = "tree_w4", treeVariant = TreeVariant.MEDIUM, worldX = 180f, worldY = 690f),

            // --- EAST GROVE ---
            ResourceNode(id = "tree_e1", treeVariant = TreeVariant.LARGE, worldX = 690f, worldY = 210f),
            ResourceNode(id = "tree_e2", treeVariant = TreeVariant.MEDIUM, worldX = 610f, worldY = 370f),
            ResourceNode(id = "tree_e3", treeVariant = TreeVariant.MEDIUM, worldX = 670f, worldY = 530f),
            ResourceNode(id = "tree_e4", treeVariant = TreeVariant.LARGE, worldX = 630f, worldY = 690f),

            // --- CENTRAL CLEARING & TRAILS ---
            ResourceNode(id = "tree_c1", treeVariant = TreeVariant.MEDIUM, worldX = 270f, worldY = 150f),
            ResourceNode(id = "tree_c2", treeVariant = TreeVariant.SMALL, worldX = 390f, worldY = 210f),
            ResourceNode(id = "tree_c3", treeVariant = TreeVariant.SMALL, worldX = 490f, worldY = 250f),
            ResourceNode(id = "tree_c4", treeVariant = TreeVariant.MEDIUM, worldX = 550f, worldY = 140f),

            // --- MID-FOREST TRAIL DIVIDERS ---
            ResourceNode(id = "tree_m1", treeVariant = TreeVariant.SMALL, worldX = 460f, worldY = 490f),
            ResourceNode(id = "tree_m2", treeVariant = TreeVariant.MEDIUM, worldX = 330f, worldY = 550f),
            ResourceNode(id = "tree_m3", treeVariant = TreeVariant.LARGE, worldX = 260f, worldY = 770f),
            ResourceNode(id = "tree_m4", treeVariant = TreeVariant.SMALL, worldX = 570f, worldY = 780f),

            // --- NORTHERN CANOPY ---
            ResourceNode(id = "tree_n1", treeVariant = TreeVariant.LARGE, worldX = 370f, worldY = 90f),
            ResourceNode(id = "tree_n2", treeVariant = TreeVariant.LARGE, worldX = 530f, worldY = 80f)
        )

        for (node in defaultTrees) {
            nodes[node.id] = node
        }
    }

    fun getAllNodes(): List<ResourceNode> = nodes.values.toList()

    fun getNode(id: String): ResourceNode? = nodes[id]

    /**
     * Updates respawns based on wall-clock timestamp across all nodes.
     */
    fun updateAll(currentTimeMillis: Long) {
        for (node in nodes.values) {
            node.updateRespawn(currentTimeMillis)
        }
    }

    /**
     * Finds the nearest gatherable or interacting resource node within range.
     */
    fun findNearestNode(playerX: Float, playerY: Float, maxDistance: Float = 60f): ResourceNode? {
        var closest: ResourceNode? = null
        var closestDistSq = maxDistance * maxDistance

        for (node in nodes.values) {
            val dx = playerX - node.worldX
            val dy = playerY - node.worldY
            val distSq = dx * dx + dy * dy
            if (distSq <= closestDistSq) {
                closestDistSq = distSq
                closest = node
            }
        }
        return closest
    }

    /**
     * Serializes all nodes for persistent save.
     */
    fun toSerialized(): String {
        return nodes.values.joinToString(";") { it.toSerialized() }
    }

    /**
     * Deserializes nodes from saved string.
     */
    fun loadFromSerialized(data: String) {
        if (data.isBlank()) {
            initializeDefaultForestNodes()
            return
        }

        val entries = data.split(";")
        for (entry in entries) {
            val node = ResourceNode.fromSerialized(entry)
            if (node != null) {
                nodes[node.id] = node
            }
        }

        // Check if any default trees were missing
        val existingIds = nodes.keys.toSet()
        val tempDefault = ResourceManager()
        for (defNode in tempDefault.getAllNodes()) {
            if (!existingIds.contains(defNode.id)) {
                nodes[defNode.id] = defNode
            }
        }
    }
}
