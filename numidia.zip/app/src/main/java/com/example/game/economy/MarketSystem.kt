package com.example.game.economy

import com.example.game.items.Inventory
import com.example.game.items.Item
import com.example.game.items.ItemCategory

object MarketSystem {

    /**
     * Sells any sellable commodity (Harvested Crops or Gathered Resources like Wood).
     */
    fun sellItem(
        economy: EconomyManager,
        inventory: Inventory,
        item: Item,
        quantity: Int
    ): TransactionResult {
        if (item.category != ItemCategory.CROPS && item.category != ItemCategory.RESOURCES) {
            return TransactionResult.Failure("السوق يقبل شراء المحاصيل الزراعية والموارد الطبيعية فقط!")
        }

        if (quantity <= 0) {
            return TransactionResult.Failure("كمية البيع غير صحيحة")
        }

        val ownedQty = inventory.getTotalQuantity(item.id)
        if (ownedQty < quantity) {
            return TransactionResult.Failure("لا تملك كمية كافية من ${item.nameArabic} (المتوفر: $ownedQty)")
        }

        val unitPrice = PriceCatalog.getItemSellPrice(item)
        val totalEarn = unitPrice * quantity

        // Atomic transaction: remove item first, then add money
        val removed = inventory.removeItem(item.id, quantity)
        if (!removed) {
            return TransactionResult.Failure("تعذر إتمام عملية البيع")
        }

        economy.addMoney(totalEarn)

        return TransactionResult.Success(
            messageArabic = "تم بيع $quantity من ${item.nameArabic} (+$totalEarn مال)",
            amountChanged = totalEarn,
            itemQuantity = quantity
        )
    }

    /**
     * Backward-compatible delegation for selling crops.
     */
    fun sellCrop(
        economy: EconomyManager,
        inventory: Inventory,
        cropItem: Item,
        quantity: Int
    ): TransactionResult {
        return sellItem(economy, inventory, cropItem, quantity)
    }
}
