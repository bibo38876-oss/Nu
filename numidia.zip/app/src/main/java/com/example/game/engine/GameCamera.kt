package com.example.game.engine

import kotlin.math.max
import kotlin.math.min

class GameCamera {
    var offsetX: Float = 0f
        private set
    var offsetY: Float = 0f
        private set

    var viewportWidth: Float = 1080f
        private set
    var viewportHeight: Float = 1920f
        private set

    // World scale: pixels per world unit.
    // In portrait phones, approx 2.0 to 2.4 gives a crisp, readable view where player is prominent.
    var worldScale: Float = 2.2f
        private set

    fun updateViewport(width: Float, height: Float) {
        viewportWidth = width
        viewportHeight = height

        // Dynamically compute scale based on portrait width so world scale is consistent across all screen sizes
        // On a 400dp width phone, we show ~180 world units across (comfortable 3/4 view)
        worldScale = max(1.8f, min(3.5f, width / 180f))
    }

    fun centerOn(targetX: Float, targetY: Float, worldWidth: Float, worldHeight: Float, smooth: Boolean = true) {
        val visibleWorldW = viewportWidth / worldScale
        val visibleWorldH = viewportHeight / worldScale

        // Calculate clamped bounds
        val minX = visibleWorldW / 2f
        val maxX = max(minX, worldWidth - visibleWorldW / 2f)
        val minY = visibleWorldH / 2f
        val maxY = max(minY, worldHeight - visibleWorldH / 2f)

        val desiredX = targetX.coerceIn(minX, maxX)
        val desiredY = targetY.coerceIn(minY, maxY)

        if (smooth) {
            // Smooth lerp (15% per frame at ~60fps)
            offsetX += (desiredX - offsetX) * 0.15f
            offsetY += (desiredY - offsetY) * 0.15f
        } else {
            offsetX = desiredX
            offsetY = desiredY
        }
    }

    fun worldToScreenX(worldX: Float): Float {
        return (worldX - offsetX) * worldScale + (viewportWidth / 2f)
    }

    fun worldToScreenY(worldY: Float): Float {
        return (worldY - offsetY) * worldScale + (viewportHeight / 2f)
    }

    fun screenToWorldX(screenX: Float): Float {
        return (screenX - viewportWidth / 2f) / worldScale + offsetX
    }

    fun screenToWorldY(screenY: Float): Float {
        return (screenY - viewportHeight / 2f) / worldScale + offsetY
    }
}
