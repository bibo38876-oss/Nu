package com.example.game.ui.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.game.economy.PriceCatalog
import com.example.game.items.Inventory
import com.example.game.items.Item
import com.example.game.items.ItemCatalog
import kotlin.math.max
import kotlin.math.min

@Composable
fun SeedShopDialog(
    currentMoney: Int,
    inventory: Inventory,
    onBuySeed: (Item, Int) -> Unit,
    onDismiss: () -> Unit
) {
    val shopSeeds = listOf(
        ItemCatalog.CARROT_SEEDS to 30,
        ItemCatalog.TOMATO_SEEDS to 60,
        ItemCatalog.POTATO_SEEDS to 90,
        ItemCatalog.ONION_SEEDS to 120,
        ItemCatalog.PEPPER_SEEDS to 180
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(onDismissRequest = onDismiss) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(elevation = 18.dp, shape = RoundedCornerShape(22.dp))
                    .clip(RoundedCornerShape(22.dp))
                    .testTag("seed_shop_dialog"),
                color = Color(0xFF1E140C)
            ) {
                Column(
                    modifier = Modifier
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFF2C1D12), Color(0xFF180F08))
                            )
                        )
                        .border(
                            width = 2.dp,
                            color = Color(0xFFC87D43),
                            shape = RoundedCornerShape(22.dp)
                        )
                        .padding(18.dp)
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Storefront,
                                contentDescription = null,
                                tint = Color(0xFFE0A838),
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "متجر بذور نوميديا",
                                    color = Color(0xFFF7EED6),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "بذور زراعية أصلية وعالية الجودة",
                                    color = Color(0xFFBFA98A),
                                    fontSize = 12.sp
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = Color(0xFFDFCEAA)
                            )
                        }
                    }

                    // Current Money Banner
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp)
                            .background(Color(0x663D2A1C), RoundedCornerShape(10.dp))
                            .border(1.dp, Color(0xFF5A3D28), RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "رصيدك الحالي:",
                            color = Color(0xFFE8C58D),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = null,
                                tint = Color(0xFFF5C538),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "$currentMoney مال",
                                color = Color(0xFFFFD466),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Seeds List
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(weight = 1f, fill = false)
                    ) {
                        items(shopSeeds) { (seedItem, growthSec) ->
                            val unitPrice = PriceCatalog.getSeedBuyPrice(seedItem.id)
                            val ownedCount = inventory.getTotalQuantity(seedItem.id)

                            ShopSeedCard(
                                seedItem = seedItem,
                                unitPrice = unitPrice,
                                growthSeconds = growthSec,
                                ownedCount = ownedCount,
                                currentMoney = currentMoney,
                                onBuy = { qty -> onBuySeed(seedItem, qty) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Close Button
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF3D2A1C)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "إغلاق",
                            color = Color(0xFFF7EED6),
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ShopSeedCard(
    seedItem: Item,
    unitPrice: Int,
    growthSeconds: Int,
    ownedCount: Int,
    currentMoney: Int,
    onBuy: (Int) -> Unit
) {
    var quantity by remember { mutableIntStateOf(1) }
    val maxAffordable = if (unitPrice > 0) currentMoney / unitPrice else 0
    val totalCost = unitPrice * quantity
    val canAfford = currentMoney >= totalCost && quantity > 0

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x66332114))
            .border(1.dp, Color(0xFF8A552A), RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        // Seed Info Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = seedItem.iconEmoji,
                    fontSize = 24.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = seedItem.nameArabic,
                        color = Color(0xFFFAF2E3),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "النمو: $growthSeconds ثانية • سعر الوحدة: $unitPrice مال",
                        color = Color(0xFFC7B191),
                        fontSize = 12.sp
                    )
                }
            }

            // Owned in inventory badge
            Box(
                modifier = Modifier
                    .background(Color(0x661E140C), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "المخزون: $ownedCount",
                    color = Color(0xFFE8C58D),
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Quantity Stepper and Buy Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Quantity Selector: [-] qty [+]
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .background(Color(0x441F140D), RoundedCornerShape(8.dp))
                    .border(1.dp, Color(0xFF5A3D28), RoundedCornerShape(8.dp))
                    .padding(2.dp)
            ) {
                IconButton(
                    onClick = { if (quantity > 1) quantity-- },
                    modifier = Modifier.size(32.dp),
                    enabled = quantity > 1
                ) {
                    Icon(
                        imageVector = Icons.Default.Remove,
                        contentDescription = "إنقاص",
                        tint = if (quantity > 1) Color(0xFFDFCEAA) else Color(0x44DFCEAA),
                        modifier = Modifier.size(16.dp)
                    )
                }

                Text(
                    text = "$quantity",
                    color = Color(0xFFFAF2E3),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp)
                )

                IconButton(
                    onClick = {
                        val maxAllowed = max(1, maxAffordable)
                        if (quantity < min(99, maxAllowed)) quantity++
                    },
                    modifier = Modifier.size(32.dp),
                    enabled = maxAffordable > quantity
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "زيادة",
                        tint = if (maxAffordable > quantity) Color(0xFFDFCEAA) else Color(0x44DFCEAA),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // Total Cost & Buy Action
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "الإجمالي: $totalCost مال",
                        color = if (canAfford) Color(0xFFFFD466) else Color(0xFFE08D64),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (!canAfford) {
                        Text(
                            text = "لا يوجد مال كافٍ",
                            color = Color(0xFFE85D4E),
                            fontSize = 10.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Button(
                    onClick = { onBuy(quantity) },
                    enabled = canAfford,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFC87D43),
                        disabledContainerColor = Color(0x445A3920)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.height(38.dp)
                ) {
                    Text(
                        text = "شراء",
                        color = if (canAfford) Color.White else Color(0xFF7A6453),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
