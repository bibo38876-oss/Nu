package com.example.game.quest

enum class QuestState {
    AVAILABLE,
    ACTIVE,
    COMPLETED_PENDING_REWARD,
    COMPLETED,
    FAILED,
    EXPIRED
}
