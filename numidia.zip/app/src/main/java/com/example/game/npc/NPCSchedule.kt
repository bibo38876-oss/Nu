package com.example.game.npc

enum class NPCActivity(val displayNameArabic: String) {
    IDLE("واقف"),
    WALKING("يتجول"),
    WORKING("يعمل"),
    TALKING("يتحدث"),
    RESTING("يستريح"),
    SLEEPING("نائم")
}

data class ScheduleEntry(
    val startHour: Int, // 0..23 (inclusive)
    val endHour: Int,   // 0..23 (exclusive)
    val targetX: Float,
    val targetY: Float,
    val activity: NPCActivity,
    val locationNameArabic: String,
    val wanderRadius: Float = 16f
)

/**
 * Data-driven daily schedule for an NPC in NUMIDIA.
 */
data class NPCSchedule(
    val entries: List<ScheduleEntry>,
    val walkSpeed: Float = 26f
) {
    fun getEntryForHour(hour: Int): ScheduleEntry {
        val h = hour.coerceIn(0, 23)
        // Find matching entry where startHour <= h < endHour
        for (entry in entries) {
            if (entry.startHour <= entry.endHour) {
                if (h in entry.startHour until entry.endHour) {
                    return entry
                }
            } else {
                // Wraps across midnight (e.g. 21..7)
                if (h >= entry.startHour || h < entry.endHour) {
                    return entry
                }
            }
        }
        return entries.first()
    }
}

/**
 * Centralized schedule registry for all Village NPCs.
 */
object ScheduleManager {

    // 1. ياسين — تاجر البذور
    val YASSIN_SCHEDULE = NPCSchedule(
        entries = listOf(
            // 07:00–08:00: Prepare shop
            ScheduleEntry(7, 8, 265f, 295f, NPCActivity.WORKING, "متجر البذور", wanderRadius = 10f),
            // 08:00–12:00: Seed Shop open for business
            ScheduleEntry(8, 12, 265f, 295f, NPCActivity.WORKING, "متجر البذور", wanderRadius = 14f),
            // 12:00–13:00: Short lunch break at village square
            ScheduleEntry(12, 13, 345f, 410f, NPCActivity.RESTING, "ساحة القرية", wanderRadius = 18f),
            // 13:00–19:00: Seed Shop afternoon business
            ScheduleEntry(13, 19, 265f, 295f, NPCActivity.WORKING, "متجر البذور", wanderRadius = 14f),
            // 19:00–20:00: Close shop, strolling village area
            ScheduleEntry(19, 20, 310f, 350f, NPCActivity.IDLE, "ساحة القرية", wanderRadius = 20f),
            // 20:00–21:00: Returning home
            ScheduleEntry(20, 21, 200f, 230f, NPCActivity.RESTING, "المنزل", wanderRadius = 8f),
            // 21:00–07:00: Sleep / Resting inside home
            ScheduleEntry(21, 7, 200f, 230f, NPCActivity.SLEEPING, "المنزل", wanderRadius = 4f)
        )
    )

    // 2. سميرة — تاجرة السوق
    val SAMIRA_SCHEDULE = NPCSchedule(
        entries = listOf(
            // 07:00–08:00: Prepare Market
            ScheduleEntry(7, 8, 515f, 295f, NPCActivity.WORKING, "سوق التجارة", wanderRadius = 10f),
            // 08:00–19:00: Working at Market stall
            ScheduleEntry(8, 19, 515f, 295f, NPCActivity.WORKING, "سوق التجارة", wanderRadius = 14f),
            // 19:00–20:00: Close Market, relax at village square
            ScheduleEntry(19, 20, 420f, 410f, NPCActivity.RESTING, "ساحة القرية", wanderRadius = 18f),
            // 20:00–21:00: Returning home
            ScheduleEntry(20, 21, 580f, 230f, NPCActivity.RESTING, "المنزل", wanderRadius = 8f),
            // 21:00–07:00: Sleep / Resting inside home
            ScheduleEntry(21, 7, 580f, 230f, NPCActivity.SLEEPING, "المنزل", wanderRadius = 4f)
        )
    )

    // 3. مازن — مزارع القرية
    val MAZEN_SCHEDULE = NPCSchedule(
        entries = listOf(
            // 07:00–11:00: Working at Farm fields
            ScheduleEntry(7, 11, 240f, 515f, NPCActivity.WORKING, "حقل الزراعة", wanderRadius = 18f),
            // 11:00–13:00: Village square / Well break
            ScheduleEntry(11, 13, 365f, 440f, NPCActivity.RESTING, "بئر القرية", wanderRadius = 16f),
            // 13:00–17:00: Farm field inspecting crops & soil
            ScheduleEntry(13, 17, 180f, 545f, NPCActivity.WORKING, "حقل الزراعة", wanderRadius = 20f),
            // 17:00–19:00: Village square chat
            ScheduleEntry(17, 19, 330f, 430f, NPCActivity.IDLE, "ساحة القرية", wanderRadius = 20f),
            // 19:00–21:00: Farm cottage veranda
            ScheduleEntry(19, 21, 140f, 490f, NPCActivity.RESTING, "المنزل", wanderRadius = 10f),
            // 21:00–07:00: Sleep / Resting at home
            ScheduleEntry(21, 7, 140f, 490f, NPCActivity.SLEEPING, "المنزل", wanderRadius = 4f)
        )
    )

    // 4. أمين — حرفي الأدوات
    val AMIN_SCHEDULE = NPCSchedule(
        entries = listOf(
            // 07:00–08:00: Prepare Workshop
            ScheduleEntry(7, 8, 445f, 370f, NPCActivity.WORKING, "ورشة الأدوات", wanderRadius = 10f),
            // 08:00–12:00: Working at anvil/workbench
            ScheduleEntry(8, 12, 445f, 370f, NPCActivity.WORKING, "ورشة الأدوات", wanderRadius = 12f),
            // 12:00–13:00: Village plaza break
            ScheduleEntry(12, 13, 390f, 430f, NPCActivity.RESTING, "ساحة القرية", wanderRadius = 16f),
            // 13:00–19:00: Working at workshop
            ScheduleEntry(13, 19, 445f, 370f, NPCActivity.WORKING, "ورشة الأدوات", wanderRadius = 12f),
            // 19:00–20:00: Close Workshop, check well
            ScheduleEntry(19, 20, 410f, 420f, NPCActivity.IDLE, "بئر القرية", wanderRadius = 14f),
            // 20:00–21:00: Returning home
            ScheduleEntry(20, 21, 485f, 370f, NPCActivity.RESTING, "المنزل", wanderRadius = 8f),
            // 21:00–07:00: Sleep / Resting at home
            ScheduleEntry(21, 7, 485f, 370f, NPCActivity.SLEEPING, "المنزل", wanderRadius = 4f)
        )
    )

    fun getScheduleForNpc(npcId: NPCId): NPCSchedule {
        return when (npcId) {
            NPCId.YASSIN -> YASSIN_SCHEDULE
            NPCId.SAMIRA -> SAMIRA_SCHEDULE
            NPCId.MAZEN -> MAZEN_SCHEDULE
            NPCId.AMIN -> AMIN_SCHEDULE
        }
    }
}
