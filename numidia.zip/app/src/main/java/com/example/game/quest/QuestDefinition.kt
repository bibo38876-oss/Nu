package com.example.game.quest

import com.example.game.npc.NPCId

data class QuestDefinition(
    val id: String,
    val titleArabic: String,
    val summaryArabic: String,
    val giverNpcId: NPCId,
    val giverDialogueArabic: String,
    val completionDialogueArabic: String,
    val objectives: List<QuestObjective>,
    val reward: QuestReward,
    val prerequisiteQuestIds: List<String> = emptyList()
)
