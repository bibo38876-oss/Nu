package com.example.game.ui.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp

enum class ControlMode {
    JOYSTICK,
    DPAD
}

@Composable
fun MovementControlPad(
    modifier: Modifier = Modifier,
    onValueChange: (Float, Float) -> Unit
) {
    var controlMode by remember { mutableStateOf(ControlMode.JOYSTICK) }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Mode toggle button (Switch between Joystick and D-Pad)
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xD91F140D))
                .border(1.dp, Color(0xFFC87D43), RoundedCornerShape(12.dp))
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = {
                        controlMode = ControlMode.JOYSTICK
                        onValueChange(0f, 0f)
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.RadioButtonChecked,
                        contentDescription = "عصا التحكم",
                        tint = if (controlMode == ControlMode.JOYSTICK) Color(0xFFFFD466) else Color(0x66C87D43),
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(
                    onClick = {
                        controlMode = ControlMode.DPAD
                        onValueChange(0f, 0f)
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Navigation,
                        contentDescription = "أزرار التوجيه",
                        tint = if (controlMode == ControlMode.DPAD) Color(0xFFFFD466) else Color(0x66C87D43),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Active control UI
        when (controlMode) {
            ControlMode.JOYSTICK -> {
                VirtualJoystick(
                    sizeDp = 136,
                    onValueChange = onValueChange
                )
            }
            ControlMode.DPAD -> {
                DirectionalDPad(
                    onDirectionChange = onValueChange
                )
            }
        }
    }
}

@Composable
fun DirectionalDPad(
    modifier: Modifier = Modifier,
    onDirectionChange: (Float, Float) -> Unit
) {
    var activeDx by remember { mutableStateOf(0f) }
    var activeDy by remember { mutableStateOf(0f) }

    fun updateDir(dx: Float, dy: Float) {
        activeDx = dx
        activeDy = dy
        onDirectionChange(dx, dy)
    }

    Box(
        modifier = modifier
            .size(136.dp)
            .shadow(6.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xE62A1B12), Color(0xF216100B))
                )
            )
            .border(2.dp, Color(0xFFC87D43), CircleShape)
            .testTag("dpad_controller"),
        contentAlignment = Alignment.Center
    ) {
        // UP
        DPadButton(
            icon = Icons.Default.KeyboardArrowUp,
            tag = "dpad_up",
            modifier = Modifier.align(Alignment.TopCenter),
            onPressed = { updateDir(0f, -1f) },
            onReleased = { updateDir(0f, 0f) }
        )
        // DOWN
        DPadButton(
            icon = Icons.Default.KeyboardArrowDown,
            tag = "dpad_down",
            modifier = Modifier.align(Alignment.BottomCenter),
            onPressed = { updateDir(0f, 1f) },
            onReleased = { updateDir(0f, 0f) }
        )
        // LEFT
        DPadButton(
            icon = Icons.Default.KeyboardArrowLeft,
            tag = "dpad_left",
            modifier = Modifier.align(Alignment.CenterStart),
            onPressed = { updateDir(-1f, 0f) },
            onReleased = { updateDir(0f, 0f) }
        )
        // RIGHT
        DPadButton(
            icon = Icons.Default.KeyboardArrowRight,
            tag = "dpad_right",
            modifier = Modifier.align(Alignment.CenterEnd),
            onPressed = { updateDir(1f, 0f) },
            onReleased = { updateDir(0f, 0f) }
        )

        // Center hub dot
        Box(
            modifier = Modifier
                .size(16.dp)
                .clip(CircleShape)
                .background(Color(0xFF8A461E))
                .border(1.5.dp, Color(0xFFFFD466), CircleShape)
        )
    }
}

@Composable
private fun DPadButton(
    icon: ImageVector,
    tag: String,
    modifier: Modifier = Modifier,
    onPressed: () -> Unit,
    onReleased: () -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(if (isPressed) Color(0xFFD97724) else Color(0x663D2619))
            .border(1.dp, if (isPressed) Color(0xFFFFD466) else Color(0x55B8783C), CircleShape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    isPressed = true
                    onPressed()

                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) {
                            isPressed = false
                            onReleased()
                            break
                        }
                        change.consume()
                    }
                    if (isPressed) {
                        isPressed = false
                        onReleased()
                    }
                }
            }
            .testTag(tag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = tag,
            tint = if (isPressed) Color(0xFFFFF7E6) else Color(0xFFE8C8A0),
            modifier = Modifier.size(24.dp)
        )
    }
}
