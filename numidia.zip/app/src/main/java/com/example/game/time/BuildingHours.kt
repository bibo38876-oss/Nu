package com.example.game.time

object BuildingHours {
    // Configurable building hours
    const val SEED_SHOP_OPEN_HOUR = 7
    const val SEED_SHOP_CLOSE_HOUR = 20

    const val MARKET_OPEN_HOUR = 7
    const val MARKET_CLOSE_HOUR = 20

    const val WORKSHOP_OPEN_HOUR = 8
    const val WORKSHOP_CLOSE_HOUR = 19

    fun isSeedShopOpen(hour: Int): Boolean {
        return hour in SEED_SHOP_OPEN_HOUR until SEED_SHOP_CLOSE_HOUR
    }

    fun isMarketOpen(hour: Int): Boolean {
        return hour in MARKET_OPEN_HOUR until MARKET_CLOSE_HOUR
    }

    fun isWorkshopOpen(hour: Int): Boolean {
        return hour in WORKSHOP_OPEN_HOUR until WORKSHOP_CLOSE_HOUR
    }

    const val SEED_SHOP_CLOSED_MESSAGE = "المحل مغلق الآن.\nسيُفتح في الصباح."
    const val MARKET_CLOSED_MESSAGE = "السوق مغلق الآن.\nسيُفتح في الصباح."
    const val WORKSHOP_CLOSED_MESSAGE = "الورشة مغلقة الآن.\nعد في الصباح."
}
