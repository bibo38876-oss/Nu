package com.example.game.relationship

import com.example.game.npc.NPCId

data class RelationshipData(
    val npcId: NPCId,
    var affinity: Int = 0,
    var lastTalkDay: Int = -1,
    var completedQuestsCount: Int = 0
) {
    val level: RelationshipLevel
        get() = RelationshipLevel.fromAffinity(affinity)

    val progressInLevelPercent: Float
        get() {
            val lvl = level
            val span = (lvl.maxAffinity - lvl.minAffinity + 1).toFloat()
            val relative = (affinity - lvl.minAffinity).coerceAtLeast(0).toFloat()
            return (relative / span).coerceIn(0f, 1f)
        }
}
