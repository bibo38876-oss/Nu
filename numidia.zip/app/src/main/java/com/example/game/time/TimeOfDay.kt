package com.example.game.time

enum class TimeOfDay(
    val nameArabic: String,
    val iconEmoji: String,
    val startHour: Int,
    val endHour: Int
) {
    DAWN("فجر", "🌅", 5, 6),
    MORNING("صباح", "🌤️", 6, 10),
    DAY("نهار", "☀️", 10, 15),
    AFTERNOON("ظهيرة", "🌤️", 15, 18),
    EVENING("مساء", "🌇", 18, 20),
    DUSK("غسق", "🌆", 20, 21),
    NIGHT("ليل", "🌙", 21, 5);

    val isDaylight: Boolean
        get() = this == MORNING || this == DAY || this == AFTERNOON

    val isNighttime: Boolean
        get() = this == NIGHT || this == DUSK

    companion object {
        fun fromHour(hour: Int): TimeOfDay {
            val h = hour.coerceIn(0, 23)
            return when (h) {
                5 -> DAWN
                in 6..9 -> MORNING
                in 10..14 -> DAY
                in 15..17 -> AFTERNOON
                in 18..19 -> EVENING
                20 -> DUSK
                else -> NIGHT // 21..23 and 0..4
            }
        }
    }
}
