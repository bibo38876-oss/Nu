package com.example.game.ui.game

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.example.game.engine.GameEngine
import com.example.game.ui.hud.GameHud
import kotlinx.coroutines.isActive

import androidx.compose.foundation.focusable
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester

@Composable
fun GameScreen(
    onEngineCreated: (GameEngine) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val engine = remember {
        GameEngine(context).also { onEngineCreated(it) }
    }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    // Real-time 60-120 FPS game tick loop tied directly to Android display vsync
    LaunchedEffect(engine) {
        var lastTimeNanos = 0L
        while (isActive) {
            withFrameNanos { currentNanos ->
                if (lastTimeNanos != 0L) {
                    val deltaSeconds = (currentNanos - lastTimeNanos) / 1_000_000_000f
                    engine.update(deltaSeconds)
                }
                lastTimeNanos = currentNanos
            }
        }
    }

    // Auto-save on lifecycle pause/stop
    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) {
        engine.saveGame()
    }

    DisposableEffect(engine) {
        onDispose {
            engine.saveGame()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF16100B))
            .focusRequester(focusRequester)
            .focusable()
    ) {
        // 1. Pixel Art World Rendering Canvas
        GameCanvas(
            engine = engine,
            modifier = Modifier.fillMaxSize()
        )

        // 2. Arabic-first Game HUD and Touch Controls
        GameHud(
            engine = engine,
            modifier = Modifier.fillMaxSize()
        )
    }
}
