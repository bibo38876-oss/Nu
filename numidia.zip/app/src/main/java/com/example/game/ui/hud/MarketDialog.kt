package com.example.game.ui.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.game.economy.PriceCatalog
import com.example.game.items.Inventory
import com.example.game.items.Item
import com.example.game.items.ItemCategory
import com.example.game.items.ItemStack
import kotlin.math.min

@Composable
fun MarketDialog(
    currentMoney: Int,
    inventory: Inventory,
    onSellItem: (Item, Int) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedFilter by remember { mutableStateOf("ALL") } // "ALL", "CROPS", "RESOURCES"

    // Sellable items: Harvested crops and gathered resources (like Wood)
    val allSellableSlots = inventory.getSlots()
        .filterNotNull()
        .filter { (it.item.category == ItemCategory.CROPS || it.item.category == ItemCategory.RESOURCES) && it.quantity > 0 }

    val filteredSlots = when (selectedFilter) {
        "CROPS" -> allSellableSlots.filter { it.item.category == ItemCategory.CROPS }
        "RESOURCES" -> allSellableSlots.filter { it.item.category == ItemCategory.RESOURCES }
        else -> allSellableSlots
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(onDismissRequest = onDismiss) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(elevation = 18.dp, shape = RoundedCornerShape(22.dp))
                    .clip(RoundedCornerShape(22.dp))
                    .testTag("market_dialog"),
                color = Color(0xFF1E140C)
            ) {
                Column(
                    modifier = Modifier
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFF2C1D12), Color(0xFF180F08))
                            )
                        )
                        .border(
                            width = 2.dp,
                            color = Color(0xFFE0A838),
                            shape = RoundedCornerShape(22.dp)
                        )
                        .padding(18.dp)
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ShoppingBag,
                                contentDescription = null,
                                tint = Color(0xFFE0A838),
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "سوق نوميديا التجاري",
                                    color = Color(0xFFF7EED6),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "بيع المحاصيل الزراعية والموارد الطبيعية (الخشب)",
                                    color = Color(0xFFBFA98A),
                                    fontSize = 12.sp
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = Color(0xFFDFCEAA)
                            )
                        }
                    }

                    // Current Money Banner
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp)
                            .background(Color(0x663D2A1C), RoundedCornerShape(10.dp))
                            .border(1.dp, Color(0xFF5A3D28), RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "رصيدك الحالي:",
                            color = Color(0xFFE8C58D),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = null,
                                tint = Color(0xFFF5C538),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "$currentMoney مال",
                                color = Color(0xFFFFD466),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Category Tabs Filter
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MarketCategoryChip(
                            label = "الكل (${allSellableSlots.size})",
                            isSelected = selectedFilter == "ALL",
                            onClick = { selectedFilter = "ALL" }
                        )
                        MarketCategoryChip(
                            label = "المحاصيل (${allSellableSlots.count { it.item.category == ItemCategory.CROPS }})",
                            isSelected = selectedFilter == "CROPS",
                            onClick = { selectedFilter = "CROPS" }
                        )
                        MarketCategoryChip(
                            label = "الموارد: خشب (${allSellableSlots.count { it.item.category == ItemCategory.RESOURCES }})",
                            isSelected = selectedFilter == "RESOURCES",
                            onClick = { selectedFilter = "RESOURCES" }
                        )
                    }

                    // Sellable Items List or Empty State
                    if (filteredSlots.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .background(Color(0x333D2A1C), RoundedCornerShape(14.dp))
                                .border(1.dp, Color(0x338A552A), RoundedCornerShape(14.dp))
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = if (selectedFilter == "RESOURCES") "🪵" else "🧺",
                                    fontSize = 32.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (selectedFilter == "RESOURCES") {
                                        "لا يوجد خشب في حقيبتك حالياً!"
                                    } else {
                                        "لا توجد بضائع قابلة للبيع في حقيبتك حالياً!"
                                    },
                                    color = Color(0xFFFAF2E3),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "اجمع الأخشاب من الغابة بواسطة الفأس، أو احصد المحاصيل من الحقل ثم عد لبيعها في السوق.",
                                    color = Color(0xFFBFA98A),
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(weight = 1f, fill = false)
                        ) {
                            items(filteredSlots) { stack ->
                                val unitPrice = PriceCatalog.getItemSellPrice(stack.item)
                                MarketItemCard(
                                    item = stack.item,
                                    ownedCount = stack.quantity,
                                    unitPrice = unitPrice,
                                    onSell = { qty -> onSellItem(stack.item, qty) }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Close Button
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF3D2A1C)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "إغلاق",
                            color = Color(0xFFF7EED6),
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MarketCategoryChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) Color(0xFFC87D43) else Color(0x33442E1F))
            .border(
                1.dp,
                if (isSelected) Color(0xFFFFD466) else Color(0x665A3D28),
                RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) Color(0xFFFFF7E6) else Color(0xFFC7B191),
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun MarketItemCard(
    item: Item,
    ownedCount: Int,
    unitPrice: Int,
    onSell: (Int) -> Unit
) {
    var quantity by remember { mutableIntStateOf(1) }
    val clampedQty = min(quantity, ownedCount).coerceAtLeast(1)
    val totalEarnings = unitPrice * clampedQty

    val categoryBadge = when (item.category) {
        ItemCategory.CROPS -> "محصول"
        ItemCategory.RESOURCES -> "مورد طبيعي"
        else -> item.category.labelArabic
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x66332114))
            .border(1.dp, Color(0xFFB88A1A), RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = item.iconEmoji,
                    fontSize = 24.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = item.nameArabic,
                            color = Color(0xFFFAF2E3),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .background(Color(0x445A3D28), RoundedCornerShape(4.dp))
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = categoryBadge,
                                color = Color(0xFFD4B483),
                                fontSize = 10.sp
                            )
                        }
                    }
                    Text(
                        text = "سعر الوحدة: $unitPrice مال • المتوفر: $ownedCount",
                        color = Color(0xFFC7B191),
                        fontSize = 12.sp
                    )
                }
            }

            // Quick "All" Button
            Button(
                onClick = { quantity = ownedCount },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0x665A3D28)
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text(
                    text = "الكل",
                    color = Color(0xFFFFD466),
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Quantity Stepper and Sell Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // [-] qty [+]
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .background(Color(0x441F140D), RoundedCornerShape(8.dp))
                    .border(1.dp, Color(0xFF5A3D28), RoundedCornerShape(8.dp))
                    .padding(2.dp)
            ) {
                IconButton(
                    onClick = { if (quantity > 1) quantity-- },
                    modifier = Modifier.size(32.dp),
                    enabled = quantity > 1
                ) {
                    Icon(
                        imageVector = Icons.Default.Remove,
                        contentDescription = "إنقاص",
                        tint = if (quantity > 1) Color(0xFFDFCEAA) else Color(0x44DFCEAA),
                        modifier = Modifier.size(16.dp)
                    )
                }

                Text(
                    text = "$clampedQty",
                    color = Color(0xFFFAF2E3),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp)
                )

                IconButton(
                    onClick = { if (quantity < ownedCount) quantity++ },
                    modifier = Modifier.size(32.dp),
                    enabled = quantity < ownedCount
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "زيادة",
                        tint = if (quantity < ownedCount) Color(0xFFDFCEAA) else Color(0x44DFCEAA),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // Earnings & Sell Button
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "الإجمالي: +$totalEarnings مال",
                    color = Color(0xFFFFD466),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.width(10.dp))

                Button(
                    onClick = { onSell(clampedQty) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF4E8236)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.height(38.dp)
                ) {
                    Text(
                        text = "بيع",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
