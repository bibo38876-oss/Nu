package com.example.game.state

enum class Direction(val dx: Float, val dy: Float) {
    DOWN(0f, 1f),
    UP(0f, -1f),
    LEFT(-1f, 0f),
    RIGHT(1f, 0f);

    companion object {
        fun fromVector(vx: Float, vy: Float, current: Direction = DOWN): Direction {
            if (kotlin.math.abs(vx) < 0.15f && kotlin.math.abs(vy) < 0.15f) return current
            return if (kotlin.math.abs(vx) > kotlin.math.abs(vy)) {
                if (vx > 0) RIGHT else LEFT
            } else {
                if (vy > 0) DOWN else UP
            }
        }
    }
}
