package com.example.game.farming

class FarmingPlotFoundation {

    private val allPlots = mutableListOf<FarmingPlot>()
    var expansionLevel: Int = 1
        private set

    companion object {
        // Master coordinates for up to 20 plots across the 4 expansion tiers
        private val ALL_PLOT_COORDINATES = listOf(
            // Level 1: Initial 6 plots (2 rows x 3 columns)
            Pair(136f, 588f),
            Pair(184f, 588f),
            Pair(232f, 588f),
            Pair(136f, 632f),
            Pair(184f, 632f),
            Pair(232f, 632f),

            // Level 2: +4 plots (Total 10)
            Pair(136f, 676f),
            Pair(184f, 676f),
            Pair(232f, 676f),
            Pair(280f, 588f),

            // Level 3: +5 plots (Total 15)
            Pair(280f, 632f),
            Pair(280f, 676f),
            Pair(136f, 720f),
            Pair(184f, 720f),
            Pair(232f, 720f),

            // Level 4: +5 plots (Total 20)
            Pair(280f, 720f),
            Pair(136f, 764f),
            Pair(184f, 764f),
            Pair(232f, 764f),
            Pair(280f, 764f)
        )

        fun getPlotCountForLevel(level: Int): Int {
            return when (level) {
                1 -> 6
                2 -> 10
                3 -> 15
                else -> 20
            }
        }
    }

    init {
        initializeAllPlots()
    }

    private fun initializeAllPlots() {
        allPlots.clear()
        ALL_PLOT_COORDINATES.forEachIndexed { index, (x, y) ->
            allPlots.add(
                FarmingPlot(
                    id = "farm_plot_${index + 1}",
                    worldX = x,
                    worldY = y,
                    state = if (index == 0) FarmingPlotState.PREPARED else FarmingPlotState.EMPTY,
                    consecutiveHarvests = 0,
                    soilQuality = 1.0f
                )
            )
        }
    }

    fun setExpansionLevel(level: Int) {
        expansionLevel = level.coerceIn(1, 4)
    }

    /**
     * Returns only the currently unlocked plots based on farm expansion level.
     */
    fun getActivePlots(): List<FarmingPlot> {
        val count = getPlotCountForLevel(expansionLevel)
        return allPlots.take(count)
    }

    fun getAllPlots(): List<FarmingPlot> = getActivePlots()

    fun getAllMasterPlots(): List<FarmingPlot> = allPlots.toList()

    fun getPlotById(id: String): FarmingPlot? = allPlots.find { it.id == id }

    fun findNearestPlot(px: Float, py: Float): FarmingPlot? {
        val active = getActivePlots()
        var closest: FarmingPlot? = null
        var closestDistSq = Float.MAX_VALUE
        for (plot in active) {
            val dx = px - plot.worldX
            val dy = py - plot.worldY
            val dSq = dx * dx + dy * dy
            if (dSq <= (FarmingPlot.INTERACTION_RADIUS * FarmingPlot.INTERACTION_RADIUS) && dSq < closestDistSq) {
                closest = plot
                closestDistSq = dSq
            }
        }
        return closest
    }

    fun updateAll(currentTimeMs: Long = System.currentTimeMillis()) {
        val active = getActivePlots()
        for (plot in active) {
            plot.updateStateWithTime(currentTimeMs)
        }
    }

    fun toSerialized(): String {
        return allPlots.joinToString(";") { it.toSerialized() }
    }

    fun loadFromSerialized(data: String) {
        if (data.isBlank()) return
        val items = data.split(";")
        val loaded = items.mapNotNull { FarmingPlot.fromSerialized(it) }
        if (loaded.isNotEmpty()) {
            // Match and apply saved states to master plot list
            for (savedPlot in loaded) {
                val existing = allPlots.find { it.id == savedPlot.id }
                if (existing != null) {
                    existing.state = savedPlot.state
                    existing.plantedCrop = savedPlot.plantedCrop
                    existing.plantedTimestampMs = savedPlot.plantedTimestampMs
                    existing.consecutiveHarvests = savedPlot.consecutiveHarvests
                    existing.soilQuality = savedPlot.soilQuality
                } else {
                    allPlots.add(savedPlot)
                }
            }
        }
    }
}
