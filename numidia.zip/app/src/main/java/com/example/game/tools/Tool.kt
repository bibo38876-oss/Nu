package com.example.game.tools

enum class ToolType(val nameArabic: String) {
    AXE("فأس"),
    HOE("معزقة"),
    WATERING_CAN("مرشة"),
    PICKAXE("معول")
}

data class Tool(
    val id: String,
    val nameArabic: String,
    val toolType: ToolType,
    val interactionRange: Float = 55f,
    val gatherDurationMultiplier: Float = 1.0f,
    val animationName: String = "CHOPPING",
    // Durability architecture (ready for future durability stages)
    val maxDurability: Int = 100,
    val currentDurability: Int = 100,
    val hasDurability: Boolean = false
) {
    companion object {
        val BASIC_AXE = Tool(
            id = "bronze_axe",
            nameArabic = "فأس برونزي",
            toolType = ToolType.AXE,
            interactionRange = 58f,
            gatherDurationMultiplier = 1.0f,
            animationName = "CHOPPING",
            maxDurability = 100,
            currentDurability = 100,
            hasDurability = false
        )
    }
}
