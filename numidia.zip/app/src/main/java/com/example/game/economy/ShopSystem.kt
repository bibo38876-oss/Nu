package com.example.game.economy

import com.example.game.items.Inventory
import com.example.game.items.Item

object ShopSystem {

    fun buySeed(
        economy: EconomyManager,
        inventory: Inventory,
        seedItem: Item,
        quantity: Int
    ): TransactionResult {
        if (quantity <= 0) {
            return TransactionResult.Failure("كمية الشراء غير صحيحة")
        }

        val unitPrice = PriceCatalog.getSeedBuyPrice(seedItem.id)
        val totalCost = unitPrice * quantity

        if (!economy.canAfford(totalCost)) {
            return TransactionResult.Failure("لا يوجد مال كافٍ لشراء $quantity من ${seedItem.nameArabic}")
        }

        // Atomic transaction: spend money and add to inventory
        val spent = economy.spendMoney(totalCost)
        if (!spent) {
            return TransactionResult.Failure("لا يوجد مال كافٍ")
        }

        val unadded = inventory.addItem(seedItem, quantity)
        if (unadded > 0) {
            // Rollback if inventory was unexpectedly full
            val actualAdded = quantity - unadded
            if (actualAdded == 0) {
                economy.addMoney(totalCost)
                return TransactionResult.Failure("حقيبة الأغراض ممتلئة!")
            } else {
                val refund = unadded * unitPrice
                economy.addMoney(refund)
                return TransactionResult.Success(
                    messageArabic = "تم شراء $actualAdded من ${seedItem.nameArabic} (امتلأت الحقيبة بالباقي)",
                    amountChanged = totalCost - refund,
                    itemQuantity = actualAdded
                )
            }
        }

        return TransactionResult.Success(
            messageArabic = "تم شراء $quantity من ${seedItem.nameArabic} (-$totalCost مال)",
            amountChanged = totalCost,
            itemQuantity = quantity
        )
    }
}
