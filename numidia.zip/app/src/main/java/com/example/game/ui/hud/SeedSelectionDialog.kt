package com.example.game.ui.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Grass
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.game.farming.CropType
import com.example.game.farming.FarmingPlot
import com.example.game.items.Inventory

@Composable
fun SeedSelectionDialog(
    plot: FarmingPlot,
    inventory: Inventory,
    onSelectSeed: (CropType) -> Unit,
    onDismiss: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(onDismissRequest = onDismiss) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(elevation = 16.dp, shape = RoundedCornerShape(20.dp))
                    .clip(RoundedCornerShape(20.dp))
                    .testTag("seed_selection_dialog"),
                color = Color(0xFF1E140C)
            ) {
                Column(
                    modifier = Modifier
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFF2C1D12), Color(0xFF180F08))
                            )
                        )
                        .border(
                            width = 2.dp,
                            color = Color(0xFFC87D43),
                            shape = RoundedCornerShape(20.dp)
                        )
                        .padding(18.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Grass,
                                contentDescription = null,
                                tint = Color(0xFF7BAA5A),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "اختر البذور للغرس",
                                color = Color(0xFFF7EED6),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = Color(0xFFDFCEAA)
                            )
                        }
                    }

                    // Soil Quality & Fatigue Info Banner
                    val qualityPercent = (plot.soilQuality * 100).toInt()
                    val fatiguePenalty = plot.getFatiguePenaltySeconds()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .background(Color(0x553D2A1C), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "جودة التربة: $qualityPercent%",
                            color = Color(0xFFE8C58D),
                            fontSize = 12.sp
                        )
                        if (fatiguePenalty > 0) {
                            Text(
                                text = "تعب التربة: +$fatiguePenalty ث",
                                color = Color(0xFFE08D64),
                                fontSize = 12.sp
                            )
                        } else {
                            Text(
                                text = "تربة منتعشة",
                                color = Color(0xFF90C26E),
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Crop Seed List
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(CropType.entries) { crop ->
                            val seedQty = inventory.getTotalQuantity(crop.seedItemId)
                            val totalTime = crop.baseGrowthSeconds + fatiguePenalty

                            SeedItemCard(
                                crop = crop,
                                availableCount = seedQty,
                                growthSeconds = totalTime,
                                onPlant = { onSelectSeed(crop) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Cancel Button
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF3D2A1C)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "إلغاء",
                            color = Color(0xFFF7EED6),
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SeedItemCard(
    crop: CropType,
    availableCount: Int,
    growthSeconds: Int,
    onPlant: () -> Unit
) {
    val canPlant = availableCount > 0

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(
                if (canPlant) Color(0x66332114) else Color(0x331C130C)
            )
            .border(
                width = 1.dp,
                color = if (canPlant) Color(0xFF8A552A) else Color(0x33593D26),
                shape = RoundedCornerShape(14.dp)
            )
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Crop Info
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = crop.iconEmoji,
                fontSize = 24.sp
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = crop.nameArabic,
                    color = Color(0xFFFAF2E3),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "النمو: $growthSeconds ثانية • متوفر: $availableCount",
                    color = if (canPlant) Color(0xFFC7B191) else Color(0xFF8C7B67),
                    fontSize = 12.sp
                )
            }
        }

        // Action Button
        Button(
            onClick = onPlant,
            enabled = canPlant,
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFC87D43),
                disabledContainerColor = Color(0x445A3920)
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.height(36.dp)
        ) {
            Text(
                text = if (canPlant) "غرس" else "غير متوفر",
                color = if (canPlant) Color.White else Color(0xFF7A6453),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
