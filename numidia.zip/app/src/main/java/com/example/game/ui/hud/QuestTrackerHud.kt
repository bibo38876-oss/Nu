package com.example.game.ui.hud

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.quest.QuestInstance
import com.example.game.quest.QuestState

@Composable
fun QuestTrackerHud(
    activeQuests: List<QuestInstance>,
    onOpenQuestMenu: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (activeQuests.isEmpty()) return

    // Allow minimizing the tracker
    var isExpanded by remember { mutableStateOf(true) }
    val primaryQuest = activeQuests.firstOrNull() ?: return

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = modifier
                .widthIn(max = 240.dp)
                .shadow(elevation = 6.dp, shape = RoundedCornerShape(14.dp))
                .clip(RoundedCornerShape(14.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xE62A1B12), Color(0xF018100A))
                    )
                )
                .border(
                    width = 1.5.dp,
                    color = if (primaryQuest.state == QuestState.COMPLETED_PENDING_REWARD) {
                        Color(0xFF5BA442) // Green for ready to turn in
                    } else {
                        Color(0xFFC87D43) // Terracotta bronze
                    },
                    shape = RoundedCornerShape(14.dp)
                )
                .clickable { onOpenQuestMenu() }
                .padding(horizontal = 10.dp, vertical = 8.dp)
                .testTag("hud_quest_tracker")
        ) {
            Column {
                // Header row: Icon + Title + Expand/Collapse toggle
                Row(
                    modifier = Modifier.widthIn(max = 220.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = if (primaryQuest.state == QuestState.COMPLETED_PENDING_REWARD) {
                                Icons.Default.CheckCircle
                            } else {
                                Icons.Default.Assignment
                            },
                            contentDescription = null,
                            tint = if (primaryQuest.state == QuestState.COMPLETED_PENDING_REWARD) {
                                Color(0xFF6ED84F)
                            } else {
                                Color(0xFFFFCC66)
                            },
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = primaryQuest.definition.titleArabic,
                            color = Color(0xFFF7EED6),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Toggle expand / collapse button
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(Color(0x33FFFFFF))
                            .clickable { isExpanded = !isExpanded },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = if (isExpanded) "تصغير" else "توسيع",
                            tint = Color(0xFFE2B26C),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Collapsible body: Objective details and progress counter
                AnimatedVisibility(
                    visible = isExpanded,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Column(modifier = Modifier.padding(top = 6.dp)) {
                        for (i in primaryQuest.definition.objectives.indices) {
                            val obj = primaryQuest.definition.objectives[i]
                            val cur = primaryQuest.getObjectiveProgress(i)
                            val target = obj.targetCount
                            val isObjDone = cur >= target

                            Row(
                                modifier = Modifier.widthIn(max = 220.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = obj.descriptionArabic,
                                    color = if (isObjDone) Color(0xFF88D468) else Color(0xFFDDD2BA),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "$cur/$target",
                                    color = if (isObjDone) Color(0xFF88D468) else Color(0xFFFFD466),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (i < primaryQuest.definition.objectives.size - 1) {
                                Spacer(modifier = Modifier.height(2.dp))
                            }
                        }

                        if (primaryQuest.state == QuestState.COMPLETED_PENDING_REWARD) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "جاهزة للتسليم — عد للمانح!",
                                color = Color(0xFF6ED84F),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        } else if (activeQuests.size > 1) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "+${activeQuests.size - 1} مهام أخرى (انقر للعرض)",
                                color = Color(0xFFE0AE6A),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}
