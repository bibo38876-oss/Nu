package com.example.game.ui.hud

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.game.art.PixelNPCSprites
import com.example.game.npc.NPCActionType
import com.example.game.npc.NPCId
import com.example.game.npc.NPCState
import com.example.game.quest.QuestInstance

@Composable
fun NpcDialogueDialog(
    npc: NPCState,
    timeOfDay: com.example.game.time.TimeOfDay = com.example.game.time.TimeOfDay.DAY,
    availableQuest: QuestInstance? = null,
    turnInQuest: QuestInstance? = null,
    onAcceptQuest: (String) -> Unit = {},
    onClaimReward: (String) -> Unit = {},
    onNextLine: () -> Unit,
    onActionClicked: (NPCActionType) -> Unit,
    onDismiss: () -> Unit
) {
    val currentLine = npc.getCurrentDialogueLine(timeOfDay)
    val hasMore = npc.hasMoreDialogue(timeOfDay)

    val portraitBitmap = remember(npc.definition.id) {
        PixelNPCSprites.npcPortraits[npc.definition.id]?.asImageBitmap()
    }

    val roleBadgeColor = remember(npc.definition.id) {
        when (npc.definition.id) {
            NPCId.YASSIN -> Color(0xFF386828)
            NPCId.SAMIRA -> Color(0xFF234D70)
            NPCId.MAZEN -> Color(0xFF7A5826)
            NPCId.AMIN -> Color(0xFF8C381E)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = true,
            usePlatformDefaultWidth = false
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 24.dp)
                    .testTag("npc_dialogue_modal"),
                contentAlignment = Alignment.BottomCenter
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Transparent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(elevation = 16.dp, shape = RoundedCornerShape(20.dp))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0xF52A1C12),
                                        Color(0xFA1A110A)
                                    )
                                )
                            )
                            .border(
                                width = 2.dp,
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        Color(0xFFE2B26C),
                                        Color(0xFF8F5826),
                                        Color(0xFFE2B26C)
                                    )
                                ),
                                shape = RoundedCornerShape(20.dp)
                            )
                            .padding(20.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            // --- TOP BAR: PORTRAIT + NAME & ROLE + CLOSE BUTTON ---
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // NPC Pixel Portrait
                                Box(
                                    modifier = Modifier
                                        .size(68.dp)
                                        .shadow(elevation = 6.dp, shape = RoundedCornerShape(12.dp))
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0xFF160E08))
                                        .border(
                                            width = 1.5.dp,
                                            color = Color(0xFFD49A55),
                                            shape = RoundedCornerShape(12.dp)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (portraitBitmap != null) {
                                        Image(
                                            bitmap = portraitBitmap,
                                            contentDescription = npc.definition.nameArabic,
                                            modifier = Modifier.size(60.dp),
                                            filterQuality = FilterQuality.None
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(14.dp))

                                // Character Name & Role badge
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = npc.definition.nameArabic,
                                        fontSize = 21.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFFDE8BA)
                                    )

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(roleBadgeColor)
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = npc.definition.roleTitleArabic,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFFFFF7E6)
                                        )
                                    }
                                }

                                // Close Dialog Button
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0x33FFFFFF))
                                        .clickable { onDismiss() }
                                        .testTag("dialogue_close_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "إغلاق",
                                        tint = Color(0xFFF3DEC4),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // --- MIDDLE: DIALOGUE SPEECH BUBBLE / TEXT BOX ---
                            val displayedText = when {
                                turnInQuest != null -> turnInQuest.definition.completionDialogueArabic
                                availableQuest != null -> availableQuest.definition.giverDialogueArabic
                                else -> currentLine.textArabic
                            }

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 84.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color(0x73140C07))
                                    .border(
                                        width = 1.dp,
                                        color = when {
                                            turnInQuest != null -> Color(0xFF6ED84F)
                                            availableQuest != null -> Color(0xFFFFD466)
                                            else -> Color(0x66B87B42)
                                        },
                                        shape = RoundedCornerShape(14.dp)
                                    )
                                    .padding(16.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Column {
                                    if (turnInQuest != null) {
                                        Text(
                                            text = "★ إنجاز مهمة: ${turnInQuest.definition.titleArabic}",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF7CE45B)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                    } else if (availableQuest != null) {
                                        Text(
                                            text = "! طلب مساعدة: ${availableQuest.definition.titleArabic}",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFFFD466)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                    }

                                    AnimatedContent(
                                        targetState = displayedText,
                                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                                        label = "dialogue_text_anim"
                                    ) { text ->
                                        Text(
                                            text = text,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Medium,
                                            lineHeight = 24.sp,
                                            color = Color(0xFFF7EED6),
                                            textAlign = TextAlign.Start
                                        )
                                    }

                                    if (turnInQuest != null) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = "المكافأة: ${turnInQuest.definition.reward.descriptionArabic}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFFFD466)
                                        )
                                    } else if (availableQuest != null) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = "المطلوب: ${availableQuest.definition.objectives.firstOrNull()?.descriptionArabic ?: ""}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = Color(0xFFC9B89E)
                                        )
                                        Text(
                                            text = "المكافأة: ${availableQuest.definition.reward.descriptionArabic}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFFFD466)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(18.dp))

                            // --- BOTTOM: CONTEXTUAL ACTIONS AND CONTROLS ---
                            when {
                                turnInQuest != null -> {
                                    // Quest Turn-in Action
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Button(
                                            onClick = { onClaimReward(turnInQuest.definition.id) },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = Color(0xFF4C7B38)
                                            ),
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(46.dp)
                                                .testTag("dialogue_claim_reward_btn")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = Color(0xFFFFF7E6),
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "استلام المكافأة (+${turnInQuest.definition.reward.money} مال)",
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFFFF7E6)
                                            )
                                        }

                                        OutlinedButton(
                                            onClick = onDismiss,
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier
                                                .height(46.dp)
                                        ) {
                                            Text(
                                                text = "لاحقاً",
                                                fontSize = 13.sp,
                                                color = Color(0xFFE2B26C)
                                            )
                                        }
                                    }
                                }

                                availableQuest != null -> {
                                    // Quest Offer Acceptance / Decline
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Button(
                                            onClick = { onAcceptQuest(availableQuest.definition.id) },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = Color(0xFFC7782A)
                                            ),
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(46.dp)
                                                .testTag("dialogue_accept_quest_btn")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Assignment,
                                                contentDescription = null,
                                                tint = Color(0xFFFFF7E6),
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "قبول المهمة",
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFFFF7E6)
                                            )
                                        }

                                        OutlinedButton(
                                            onClick = onDismiss,
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier
                                                .height(46.dp)
                                                .testTag("dialogue_reject_quest_btn")
                                        ) {
                                            Text(
                                                text = "رفض",
                                                fontSize = 13.sp,
                                                color = Color(0xFFE2B26C)
                                            )
                                        }
                                    }
                                }

                                else -> {
                                    // Standard Dialogue
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // If this line provides a direct action (e.g. Open Seed Shop or Market)
                                        if (currentLine.actionType != NPCActionType.NONE && currentLine.actionLabelArabic != null) {
                                            Button(
                                                onClick = { onActionClicked(currentLine.actionType) },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = Color(0xFFC7782A)
                                                ),
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(46.dp)
                                                    .testTag("dialogue_action_button")
                                            ) {
                                                val icon = when (currentLine.actionType) {
                                                    NPCActionType.OPEN_SEED_SHOP -> Icons.Default.Storefront
                                                    NPCActionType.OPEN_MARKET -> Icons.Default.MonetizationOn
                                                    else -> Icons.Default.ShoppingBag
                                                }
                                                Icon(
                                                    imageVector = icon,
                                                    contentDescription = null,
                                                    tint = Color(0xFFFFF6E6),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = currentLine.actionLabelArabic,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFFFFF6E6)
                                                )
                                            }
                                        }

                                        // Advance Dialogue or Conclude button
                                        if (hasMore) {
                                            Button(
                                                onClick = onNextLine,
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = Color(0xFF4C7B38)
                                                ),
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier
                                                    .weight(if (currentLine.actionType != NPCActionType.NONE) 0.8f else 1f)
                                                    .height(46.dp)
                                                    .testTag("dialogue_next_button")
                                            ) {
                                                Text(
                                                    text = "التالي",
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFFF7EED6)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Icon(
                                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                                    contentDescription = null,
                                                    tint = Color(0xFFF7EED6),
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        } else {
                                            OutlinedButton(
                                                onClick = onDismiss,
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier
                                                    .weight(if (currentLine.actionType != NPCActionType.NONE) 0.7f else 1f)
                                                    .height(46.dp)
                                                    .testTag("dialogue_dismiss_button")
                                            ) {
                                                Text(
                                                    text = "وداعاً",
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFFE2B26C)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
