package com.example.game.engine

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.game.art.PixelSprites
import com.example.game.audio.AudioFoundation
import com.example.game.audio.SoundEffect
import com.example.game.economy.EconomyManager
import com.example.game.economy.MarketSystem
import com.example.game.economy.ShopSystem
import com.example.game.economy.TransactionResult
import com.example.game.farming.CropType
import com.example.game.farming.FarmingPlot
import com.example.game.farming.FarmingPlotFoundation
import com.example.game.farming.FarmingPlotState
import com.example.game.items.Inventory
import com.example.game.items.Item
import com.example.game.items.ItemCatalog
import com.example.game.npc.NPCActionType
import com.example.game.npc.NPCController
import com.example.game.npc.NPCState
import com.example.game.resources.ResourceManager
import com.example.game.resources.ResourceNode
import com.example.game.resources.ResourceNodeState
import com.example.game.save.GameSaveData
import com.example.game.save.SaveSystem
import com.example.game.state.Direction
import com.example.game.state.PlayerActionAnimation
import com.example.game.state.PlayerState
import com.example.game.time.BuildingHours
import com.example.game.time.TimeOfDay
import com.example.game.time.WorldLightingController
import com.example.game.time.WorldTimeManager
import com.example.game.world.ForestZone
import com.example.game.world.VillageZone
import com.example.game.quest.AcceptQuestResult
import com.example.game.quest.QuestInstance
import com.example.game.quest.QuestManager
import com.example.game.relationship.RelationshipManager
import com.example.game.world.WorldObject
import com.example.game.world.WorldZone
import com.example.game.world.ZoneId
import kotlin.math.sqrt

class GameEngine(context: Context) {

    val saveSystem = SaveSystem(context)
    val audio = AudioFoundation()
    val camera = GameCamera()
    val economy = EconomyManager(initialMoney = 50)
    val inventory = Inventory(maxSlots = 16)
    val farming = FarmingPlotFoundation()
    val resourceManager = ResourceManager()
    val npcController = NPCController()
    val worldTime = WorldTimeManager()
    val lighting = WorldLightingController()
    val questManager = QuestManager()
    val relationshipManager = RelationshipManager()

    // Zones
    val villageZone = VillageZone()
    val forestZone = ForestZone()

    // Observable Game State
    var currentZone: WorldZone by mutableStateOf(villageZone)
        private set

    var playerState by mutableStateOf(PlayerState())
        private set

    var activeInteraction: WorldObject? by mutableStateOf(null)
        private set

    var activeFarmingPlot: FarmingPlot? by mutableStateOf(null)
        private set

    var activeResourceNode: ResourceNode? by mutableStateOf(null)
        private set

    // Resource Gathering (Chopping) State
    var isGatheringWood: Boolean by mutableStateOf(false)
        private set

    var gatheringNode: ResourceNode? by mutableStateOf(null)
        private set

    var gatheringTimer: Float by mutableFloatStateOf(0f)
        private set

    private var chopAudioTimer = 0f

    // Dialog States
    var showSeedSelectionDialog: Boolean by mutableStateOf(false)
    var selectedPlotForPlanting: FarmingPlot? by mutableStateOf(null)

    var showSeedShopDialog: Boolean by mutableStateOf(false)
    var showMarketDialog: Boolean by mutableStateOf(false)

    // Stage 6 & 9: NPC Dialogue & Quest States
    var activeDialogueNpc: NPCState? by mutableStateOf(null)
    var showNpcDialogueDialog: Boolean by mutableStateOf(false)
    var activeQuestPrompt: QuestInstance? by mutableStateOf(null)
    var activeQuestTurnIn: QuestInstance? by mutableStateOf(null)

    // Stage 9: Quest & Community Menu
    var showQuestMenuDialog: Boolean by mutableStateOf(false)

    val isAnyDialogOpen: Boolean
        get() = showSeedSelectionDialog || showSeedShopDialog || showMarketDialog || showNpcDialogueDialog || showQuestMenuDialog

    var notificationBannerText: String? by mutableStateOf(null)
        private set

    var isTransitioning: Boolean by mutableStateOf(false)
        private set

    var transitionFadeAlpha: Float by mutableFloatStateOf(0f)
        private set

    var moneyDisplay: Int by mutableIntStateOf(50)
        private set

    // Active interactable NPC when player is in range
    val activeInteractableNpc: NPCState?
        get() = if (currentZone.zoneId == ZoneId.VILLAGE) {
            npcController.getClosestInteractableNPC(playerState.x, playerState.y)
        } else null

    // Active interaction label computed for HUD button
    val contextualButtonLabel: String?
        get() {
            if (isAnyDialogOpen) return null
            if (isGatheringWood) return "قيد القطع..."

            // Priority 0: Living Village NPC Interaction (with smart Quest indicator)
            val nearbyNpc = activeInteractableNpc
            if (nearbyNpc != null) {
                val turnIn = questManager.getTurnInQuestForNpc(nearbyNpc.definition.id)
                if (turnIn != null) {
                    return "تسليم: ${nearbyNpc.definition.nameArabic}"
                }
                val available = questManager.getAvailableQuestsForNpc(nearbyNpc.definition.id).firstOrNull()
                if (available != null) {
                    return "مهمة من ${nearbyNpc.definition.nameArabic}"
                }
                return "تحدث مع ${nearbyNpc.definition.nameArabic}"
            }

            // Priority 1 in Forest: Tree Gathering Action
            if (currentZone.zoneId == ZoneId.FOREST) {
                val node = activeResourceNode
                if (node != null && node.canGather()) {
                    return "قطع"
                }
            }

            // Priority 1 in Village: Farming Action
            val plot = activeFarmingPlot
            if (plot != null && currentZone.zoneId == ZoneId.VILLAGE) {
                return when (plot.state) {
                    FarmingPlotState.EMPTY -> "إنشاء أرض"
                    FarmingPlotState.CREATED -> "تقليب التربة"
                    FarmingPlotState.PREPARED -> "زراعة"
                    FarmingPlotState.PLANTED, FarmingPlotState.GROWING -> {
                        val rem = plot.getRemainingSeconds()
                        val crop = plot.plantedCrop?.nameArabic ?: ""
                        if (rem > 0) "قيد النمو ($crop - $rem ث)" else "قيد النمو ($crop)"
                    }
                    FarmingPlotState.MATURE -> {
                        val crop = plot.plantedCrop?.nameArabic ?: "المحصول"
                        "حصاد $crop"
                    }
                    FarmingPlotState.HARVESTED -> "إنشاء أرض"
                }
            }

            // Priority 2: World Object Interaction (Portals, Shops, Inspects)
            val obj = activeInteraction
            if (obj != null) {
                return obj.interactionLabelArabic
            }

            return null
        }

    // Internal state
    private var animTimer = 0f
    private var bannerTimer = 0f
    private var transitionTimer = 0f
    private var pendingTargetZoneId: ZoneId? = null
    private var pendingSpawnX: Float = 0f
    private var pendingSpawnY: Float = 0f

    // Joystick input
    var joystickDeltaX: Float = 0f
    var joystickDeltaY: Float = 0f

    // Keyboard input (W/A/S/D or Arrow keys)
    var keyboardDeltaX: Float = 0f
    var keyboardDeltaY: Float = 0f

    // Tap/Click to move in world space
    var targetMoveX: Float? by mutableStateOf(null)
    var targetMoveY: Float? by mutableStateOf(null)

    // Continuous 60 FPS animation tick for living environment (ripples, wind sway, breathing)
    var renderTick: Long by mutableStateOf(0L)
        private set
    var gameTimeSec: Float by mutableFloatStateOf(0f)
        private set

    fun onKeyboardInput(dx: Float, dy: Float) {
        keyboardDeltaX = dx
        keyboardDeltaY = dy
        if (dx != 0f || dy != 0f) {
            targetMoveX = null
            targetMoveY = null
        }
    }

    fun onActionKeyPressed() {
        onInteractButtonClicked()
    }

    fun setMoveTarget(worldX: Float, worldY: Float) {
        if (isAnyDialogOpen || isGatheringWood || isTransitioning) return
        targetMoveX = worldX
        targetMoveY = worldY
    }

    fun clearMoveTarget() {
        targetMoveX = null
        targetMoveY = null
    }

    init {
        // Initialize pixel art cache
        PixelSprites.initialize()

        // Load saved state or default
        loadGame()

        // Initial camera center
        camera.centerOn(
            playerState.x,
            playerState.y,
            currentZone.worldWidth,
            currentZone.worldHeight,
            smooth = false
        )
    }

    fun loadGame() {
        val save = saveSystem.loadGame()
        val zone = if (save.currentZone == ZoneId.FOREST) forestZone else villageZone
        currentZone = zone

        playerState = PlayerState(
            x = save.playerX,
            y = save.playerY,
            direction = save.playerDirection,
            speed = 140f
        )

        economy.setMoney(save.money)
        moneyDisplay = economy.money

        inventory.loadFromList(save.inventoryItems)
        farming.loadFromSerialized(save.farmingPlotData)
        resourceManager.loadFromSerialized(save.treeResourceData)
        npcController.loadMetNpcIdStrings(save.metNpcIds)
        questManager.loadFromSerialized(save.questData)
        relationshipManager.loadFromSerialized(save.relationshipData)

        // Restore World Time and apply offline catch-up (capped at 6 game hours)
        worldTime.setTime(
            day = save.worldDay,
            hour = save.worldHour,
            minute = save.worldMinute,
            totalMinutes = save.totalGameMinutes
        )

        // Immediately update all persistent timers based on real elapsed timestamp
        val now = System.currentTimeMillis()
        worldTime.catchUpOfflineTime(save.timestamp, now)
        farming.updateAll(now)
        resourceManager.updateAll(now)

        showBanner(currentZone.zoneId.displayNameArabic + " — " + currentZone.zoneId.subtitleArabic)
    }

    fun saveGame() {
        val saveData = GameSaveData(
            currentZone = currentZone.zoneId,
            playerX = playerState.x,
            playerY = playerState.y,
            playerDirection = playerState.direction,
            money = economy.money,
            inventoryItems = inventory.toSerializedList(),
            farmingPlotData = farming.toSerialized(),
            treeResourceData = resourceManager.toSerialized(),
            metNpcIds = npcController.getMetNpcIdStrings(),
            worldDay = worldTime.currentDay,
            worldHour = worldTime.currentHour,
            worldMinute = worldTime.currentMinute,
            totalGameMinutes = worldTime.totalGameMinutes,
            timeVersion = WorldTimeManager.WORLD_TIME_VERSION,
            questData = questManager.toSerialized(),
            relationshipData = relationshipManager.toSerialized(),
            questVersion = 1,
            timestamp = System.currentTimeMillis()
        )
        saveSystem.saveGame(saveData)
        moneyDisplay = economy.money
    }

    fun showBanner(text: String, durationSec: Float = 3.5f) {
        notificationBannerText = text
        bannerTimer = durationSec
    }

    fun triggerPlayerAction(action: PlayerActionAnimation, durationSec: Float = 0.35f) {
        playerState = playerState.copy(
            actionAnimation = action,
            actionTimer = durationSec
        )
    }

    fun update(deltaTimeSec: Float) {
        val dt = deltaTimeSec.coerceIn(0.001f, 0.05f)
        val now = System.currentTimeMillis()

        // Continuous game animation clock for living environmental effects
        renderTick++
        gameTimeSec += dt

        // 1. Persistent Timers: Crop Growth, Tree Respawn, and World Time (Runs globally!)
        farming.updateAll(now)
        resourceManager.updateAll(now)
        worldTime.update(dt)

        // Update Living Village NPCs routines and wander behaviors with current world hour
        if (currentZone.zoneId == ZoneId.VILLAGE) {
            npcController.update(
                dt = dt,
                playerX = playerState.x,
                playerY = playerState.y,
                colliders = villageZone.getStaticColliders(),
                worldHour = worldTime.currentHour
            )
        }

        // Banner timer
        if (bannerTimer > 0f) {
            bannerTimer -= dt
            if (bannerTimer <= 0f) {
                notificationBannerText = null
            }
        }

        // Action animation timer for non-chopping actions
        if (!isGatheringWood && playerState.actionTimer > 0f) {
            val nextTimer = playerState.actionTimer - dt
            if (nextTimer <= 0f) {
                playerState = playerState.copy(
                    actionAnimation = PlayerActionAnimation.NONE,
                    actionTimer = 0f
                )
            } else {
                playerState = playerState.copy(actionTimer = nextTimer)
            }
        }

        // 2. Active Wood Gathering (Chopping) Update
        if (isGatheringWood) {
            val node = gatheringNode
            if (node == null || node.state != ResourceNodeState.GATHERING) {
                isGatheringWood = false
                gatheringNode = null
                triggerPlayerAction(PlayerActionAnimation.NONE)
            } else {
                gatheringTimer += dt
                chopAudioTimer += dt

                // Periodic axe impact audio
                if (chopAudioTimer >= 0.45f) {
                    chopAudioTimer = 0f
                    audio.playSound(SoundEffect.AXE_SWING)
                    audio.playSound(SoundEffect.TREE_IMPACT)
                }

                val finished = node.tickGathering(dt)
                if (finished) {
                    val woodYield = node.completeGathering(now)
                    inventory.addItem(ItemCatalog.WOOD, woodYield)
                    questManager.onWoodCollected(woodYield)
                    audio.playSound(SoundEffect.WOOD_COLLECT)

                    isGatheringWood = false
                    gatheringNode = null
                    triggerPlayerAction(PlayerActionAnimation.NONE)

                    saveGame()
                    val totalWood = inventory.getTotalQuantity(ItemCatalog.WOOD.id)
                    showBanner("تم جمع $woodYield من الخشب! (المخزون الحالي: $totalWood خشب).")
                }
            }

            // Movement and interaction are locked during chopping
            joystickDeltaX = 0f
            joystickDeltaY = 0f
            if (playerState.isMoving) {
                playerState = playerState.copy(isMoving = false)
            }
            return
        }

        // Freeze player movement and camera drag while any modal dialog is open
        if (isAnyDialogOpen) {
            joystickDeltaX = 0f
            joystickDeltaY = 0f
            if (playerState.isMoving) {
                playerState = playerState.copy(isMoving = false)
            }
            return
        }

        // Zone transition animation
        if (isTransitioning) {
            transitionTimer += dt
            if (transitionTimer < 0.25f) {
                transitionFadeAlpha = (transitionTimer / 0.25f).coerceIn(0f, 1f)
            } else if (transitionTimer < 0.35f) {
                transitionFadeAlpha = 1f
                pendingTargetZoneId?.let { targetId ->
                    val nextZone = if (targetId == ZoneId.FOREST) forestZone else villageZone
                    currentZone = nextZone
                    playerState = playerState.copy(
                        x = pendingSpawnX,
                        y = pendingSpawnY,
                        isMoving = false
                    )
                    camera.centerOn(
                        pendingSpawnX,
                        pendingSpawnY,
                        nextZone.worldWidth,
                        nextZone.worldHeight,
                        smooth = false
                    )
                    showBanner(nextZone.zoneId.displayNameArabic + " — " + nextZone.zoneId.subtitleArabic)
                    questManager.onLocationVisited(nextZone.zoneId)
                    saveGame()
                    pendingTargetZoneId = null
                }
            } else if (transitionTimer < 0.6f) {
                transitionFadeAlpha = (1f - (transitionTimer - 0.35f) / 0.25f).coerceIn(0f, 1f)
            } else {
                isTransitioning = false
                transitionFadeAlpha = 0f
            }
            return
        }

        // 3. Process Movement Input (Keyboard, Joystick, or Tap-to-move)
        var moveVx = 0f
        var moveVy = 0f
        var moveMagnitude = 0f

        val keyDist = sqrt(keyboardDeltaX * keyboardDeltaX + keyboardDeltaY * keyboardDeltaY)
        val joyDist = sqrt(joystickDeltaX * joystickDeltaX + joystickDeltaY * joystickDeltaY)

        if (keyDist > 0.05f) {
            // Keyboard (WASD / Arrows)
            moveVx = keyboardDeltaX / keyDist
            moveVy = keyboardDeltaY / keyDist
            moveMagnitude = 1f
            targetMoveX = null
            targetMoveY = null
        } else if (joyDist > 0.08f) {
            // Virtual Joystick thumb drag
            moveVx = joystickDeltaX / joyDist
            moveVy = joystickDeltaY / joyDist
            moveMagnitude = joyDist.coerceAtMost(1f)
            targetMoveX = null
            targetMoveY = null
        } else if (targetMoveX != null && targetMoveY != null) {
            // Tap / Click-to-move navigation
            val tdx = targetMoveX!! - playerState.x
            val tdy = targetMoveY!! - playerState.y
            val tdist = sqrt(tdx * tdx + tdy * tdy)
            if (tdist > 8f) {
                moveVx = tdx / tdist
                moveVy = tdy / tdist
                moveMagnitude = (tdist / 30f).coerceIn(0.6f, 1f)
            } else {
                targetMoveX = null
                targetMoveY = null
            }
        }

        val isMoving = moveMagnitude > 0f
        val newDirection = if (isMoving) {
            Direction.fromVector(moveVx, moveVy, playerState.direction)
        } else {
            playerState.direction
        }

        var newX = playerState.x
        var newY = playerState.y
        var newFrame = 0

        if (isMoving) {
            val moveSpeed = playerState.speed * moveMagnitude
            val moveX = moveVx * moveSpeed * dt
            val moveY = moveVy * moveSpeed * dt

            // Build dynamic collision list (static zone obstacles + solid tree trunks)
            val allColliders = buildList {
                addAll(currentZone.getStaticColliders())
                if (currentZone.zoneId == ZoneId.FOREST) {
                    for (treeNode in resourceManager.getAllNodes()) {
                        add(treeNode.colliderRect)
                    }
                }
            }

            // Check collision and slide along obstacles
            val (resolvedX, resolvedY) = CollisionSystem.resolveMovement(
                currentX = playerState.x,
                currentY = playerState.y,
                dx = moveX,
                dy = moveY,
                playerState = playerState,
                colliders = allColliders
            )

            // If player was attempting tap-to-move and hit a solid obstacle with no progress, clear target
            if (targetMoveX != null && targetMoveY != null) {
                val progress = sqrt((resolvedX - playerState.x) * (resolvedX - playerState.x) + (resolvedY - playerState.y) * (resolvedY - playerState.y))
                if (progress < 0.2f && moveSpeed * dt > 0.5f) {
                    targetMoveX = null
                    targetMoveY = null
                }
            }

            newX = resolvedX
            newY = resolvedY

            // Animation frame ticking
            animTimer += dt * (moveSpeed / 140f) * 8f
            newFrame = (animTimer.toInt() % 2) + 1
        } else {
            animTimer = 0f
            newFrame = 0
        }

        playerState = playerState.copy(
            x = newX,
            y = newY,
            direction = newDirection,
            isMoving = isMoving,
            animFrame = newFrame
        )

        // 4. Camera tracking
        camera.centerOn(
            targetX = newX,
            targetY = newY,
            worldWidth = currentZone.worldWidth,
            worldHeight = currentZone.worldHeight,
            smooth = true
        )

        // 5. Contextual Proximity Detection
        if (currentZone.zoneId == ZoneId.VILLAGE) {
            activeFarmingPlot = farming.findNearestPlot(newX, newY)
            activeResourceNode = null
        } else {
            activeFarmingPlot = null
            activeResourceNode = resourceManager.findNearestNode(newX, newY, maxDistance = 62f)
        }

        val nearbyObj = currentZone.getInteractiveObjectNear(newX, newY)
        activeInteraction = nearbyObj

        // Auto-portal trigger if player walks directly into zone portal boundary
        if (nearbyObj != null && nearbyObj.type == com.example.game.world.ObjectType.ZONE_EXIT_PORTAL) {
            if (!isTransitioning) {
                executeInteraction(nearbyObj)
            }
        }
    }

    fun onInteractButtonClicked() {
        if (isAnyDialogOpen || isGatheringWood) return

        // Priority 0: Village Living NPC Dialogue Interaction
        val nearbyNpc = activeInteractableNpc
        if (nearbyNpc != null && currentZone.zoneId == ZoneId.VILLAGE) {
            startNpcDialogue(nearbyNpc)
            return
        }

        // Priority 1: Forest Tree Chopping Interaction
        if (currentZone.zoneId == ZoneId.FOREST) {
            val node = activeResourceNode
            if (node != null && node.canGather()) {
                startChoppingTree(node)
                return
            }
        }

        // Priority 2: Farming Plot interaction in Village
        val plot = activeFarmingPlot
        if (plot != null && currentZone.zoneId == ZoneId.VILLAGE) {
            handleFarmingPlotInteraction(plot)
            return
        }

        // Priority 3: World Object interaction (Portals, Buildings, Signposts)
        activeInteraction?.let { obj ->
            executeInteraction(obj)
        }
    }

    private fun startChoppingTree(node: ResourceNode) {
        // Validate axe availability in inventory
        val hasAxe = inventory.hasItem("bronze_axe")
        if (!hasAxe) {
            showBanner("تحتاج إلى فأس لقطع الأشجار!")
            return
        }

        // Turn player to face the tree
        val dx = node.worldX - playerState.x
        val dy = node.worldY - playerState.y
        val faceDir = Direction.fromVector(dx, dy, playerState.direction)

        playerState = playerState.copy(
            direction = faceDir,
            isMoving = false,
            actionAnimation = PlayerActionAnimation.CHOPPING,
            actionTimer = node.treeVariant.baseChopDurationSec
        )

        node.startGathering()
        gatheringNode = node
        isGatheringWood = true
        gatheringTimer = 0f
        chopAudioTimer = 0f

        audio.playSound(SoundEffect.AXE_SWING)
        audio.playSound(SoundEffect.TREE_IMPACT)
    }

    private fun handleFarmingPlotInteraction(plot: FarmingPlot) {
        when (plot.state) {
            FarmingPlotState.EMPTY -> {
                audio.playSound(SoundEffect.INTERACT)
                triggerPlayerAction(PlayerActionAnimation.PREPARING_SOIL)
                plot.createPlot()
                saveGame()
                showBanner("تم إنشاء قطعة أرض جديدة! قم الآن بتقليب التربة.")
            }
            FarmingPlotState.CREATED -> {
                audio.playSound(SoundEffect.INTERACT)
                triggerPlayerAction(PlayerActionAnimation.PREPARING_SOIL)
                plot.prepareSoil()
                saveGame()
                showBanner("تم تقليب التربة وتجهيزها! التربة الآن جاهزة للغرس.")
            }
            FarmingPlotState.PREPARED -> {
                audio.playSound(SoundEffect.INTERACT)
                selectedPlotForPlanting = plot
                showSeedSelectionDialog = true
            }
            FarmingPlotState.PLANTED, FarmingPlotState.GROWING -> {
                val rem = plot.getRemainingSeconds()
                val stage = plot.getGrowthStage()
                val crop = plot.plantedCrop?.nameArabic ?: "المحصول"
                showBanner("$crop ينمو بشكل جيد (المرحلة $stage من 4) — متبقي: $rem ثانية.")
            }
            FarmingPlotState.MATURE -> {
                audio.playSound(SoundEffect.INTERACT)
                triggerPlayerAction(PlayerActionAnimation.HARVESTING)
                val harvested = plot.harvest()
                if (harvested != null) {
                    val item = ItemCatalog.findById(harvested.harvestItemId)
                    if (item != null) {
                        inventory.addItem(item, 1)
                        questManager.onCropHarvested(harvested)
                        saveGame()
                        showBanner("تم حصاد ${harvested.nameArabic}! أُضيف إلى حقيبتك (+1 ${harvested.nameArabic}).")
                    }
                }
            }
            FarmingPlotState.HARVESTED -> {
                plot.state = FarmingPlotState.EMPTY
                saveGame()
            }
        }
    }

    fun plantSeedOnPlot(crop: CropType) {
        val plot = selectedPlotForPlanting ?: activeFarmingPlot ?: return
        if (inventory.removeItem(crop.seedItemId, 1)) {
            audio.playSound(SoundEffect.INTERACT)
            triggerPlayerAction(PlayerActionAnimation.PLANTING)
            plot.plant(crop, System.currentTimeMillis())
            showSeedSelectionDialog = false
            selectedPlotForPlanting = null
            saveGame()
            showBanner("تم غرس بذور ${crop.nameArabic}! مدة النمو: ${plot.getTotalGrowthDurationSeconds()} ثانية.")
        } else {
            showBanner("لا تملك بذوراً كافية من ${crop.nameArabic}!")
        }
    }

    // --- ECONOMY TRANSACTIONS ---

    fun buySeedFromShop(seedItem: Item, quantity: Int) {
        val result = ShopSystem.buySeed(economy, inventory, seedItem, quantity)
        when (result) {
            is TransactionResult.Success -> {
                audio.playSound(SoundEffect.PURCHASE)
                moneyDisplay = economy.money
                questManager.onItemPurchased(seedItem, quantity, result.amountChanged)
                saveGame()
                showBanner(result.messageArabic)
            }
            is TransactionResult.Failure -> {
                audio.playSound(SoundEffect.ERROR)
                showBanner(result.reasonArabic)
            }
        }
    }

    fun sellItemToMarket(item: Item, quantity: Int) {
        val result = MarketSystem.sellItem(economy, inventory, item, quantity)
        when (result) {
            is TransactionResult.Success -> {
                audio.playSound(SoundEffect.PURCHASE)
                moneyDisplay = economy.money
                questManager.onItemSold(item, quantity, result.amountChanged)
                saveGame()
                showBanner(result.messageArabic)
            }
            is TransactionResult.Failure -> {
                audio.playSound(SoundEffect.ERROR)
                showBanner(result.reasonArabic)
            }
        }
    }

    private fun executeInteraction(obj: WorldObject) {
        when (obj.interactionAction) {
            "ENTER_FOREST" -> {
                audio.playSound(SoundEffect.ZONE_ENTER)
                startZoneTransition(
                    targetZone = ZoneId.FOREST,
                    spawnX = forestZone.defaultSpawnX,
                    spawnY = forestZone.defaultSpawnY
                )
            }
            "ENTER_VILLAGE" -> {
                audio.playSound(SoundEffect.ZONE_ENTER)
                startZoneTransition(
                    targetZone = ZoneId.VILLAGE,
                    spawnX = 384f,
                    spawnY = 100f
                )
            }
            "TALK_SEED_SHOP" -> {
                if (BuildingHours.isSeedShopOpen(worldTime.currentHour)) {
                    audio.playSound(SoundEffect.INTERACT)
                    showSeedShopDialog = true
                } else {
                    audio.playSound(SoundEffect.ERROR)
                    showBanner(BuildingHours.SEED_SHOP_CLOSED_MESSAGE)
                }
            }
            "TALK_MARKET" -> {
                if (BuildingHours.isMarketOpen(worldTime.currentHour)) {
                    audio.playSound(SoundEffect.INTERACT)
                    showMarketDialog = true
                } else {
                    audio.playSound(SoundEffect.ERROR)
                    showBanner(BuildingHours.MARKET_CLOSED_MESSAGE)
                }
            }
            "INSPECT_WELL" -> {
                audio.playSound(SoundEffect.INTERACT)
                showBanner("بئر القرية القديم — مياه عذبة نقية تروي الواحة.")
            }
            "INSPECT_FARM" -> {
                audio.playSound(SoundEffect.INTERACT)
                showBanner("حقل الزراعة — اقترب من قطع الأرض لإنشائها وتقليبها وغرس المحاصيل.")
            }
            "INSPECT_WORKBENCH" -> {
                if (BuildingHours.isWorkshopOpen(worldTime.currentHour)) {
                    audio.playSound(SoundEffect.INTERACT)
                    showBanner("طاولة الأدوات والسندان — ورشة الحرفي أمين مفتوحة لصيانة وصناعة الأدوات.")
                } else {
                    audio.playSound(SoundEffect.INTERACT)
                    showBanner(BuildingHours.WORKSHOP_CLOSED_MESSAGE)
                }
            }
            else -> {
                obj.interactionLabelArabic?.let { label ->
                    audio.playSound(SoundEffect.INTERACT)
                    showBanner(label)
                }
            }
        }
    }

    // --- STAGE 6, 8 & 9: NPC DIALOGUE, TIME & QUESTS ---
    fun startNpcDialogue(npc: NPCState) {
        audio.playSound(SoundEffect.INTERACT)
        activeDialogueNpc = npc

        // 1. Notify quest system of talk event
        questManager.onNpcTalkedTo(npc.definition.id)

        // 2. Grant daily talk relationship affinity (+1 per day)
        val dailyAffinityGranted = relationshipManager.onDailyTalk(npc.definition.id, worldTime.currentDay)
        if (dailyAffinityGranted) {
            audio.playSound(SoundEffect.RELATIONSHIP_UP)
        }

        // 3. Quest Priority: Turn-in Ready > Available Quest > Normal Dialogue
        val turnIn = questManager.getTurnInQuestForNpc(npc.definition.id)
        if (turnIn != null) {
            activeQuestTurnIn = turnIn
            activeQuestPrompt = null
        } else {
            activeQuestTurnIn = null
            val available = questManager.getAvailableQuestsForNpc(npc.definition.id).firstOrNull()
            activeQuestPrompt = available
        }

        showNpcDialogueDialog = true
        npcController.startTalking(npc, playerState.x, playerState.y)
    }

    fun acceptQuest(questId: String) {
        val result = questManager.acceptQuest(questId)
        when (result) {
            is AcceptQuestResult.Success -> {
                audio.playSound(SoundEffect.QUEST_ACCEPT)
                showBanner(result.messageArabic)
                dismissNpcDialogue()
                saveGame()
            }
            is AcceptQuestResult.LimitReached -> {
                audio.playSound(SoundEffect.ERROR)
                showBanner(result.messageArabic)
            }
            is AcceptQuestResult.Error -> {
                audio.playSound(SoundEffect.ERROR)
                showBanner(result.reasonArabic)
            }
        }
    }

    fun claimQuestReward(questId: String) {
        val claimResult = questManager.completeQuestAndClaimReward(
            questId = questId,
            economy = economy,
            inventory = inventory,
            relationshipManager = relationshipManager
        )
        if (claimResult != null) {
            moneyDisplay = economy.money
            audio.playSound(SoundEffect.QUEST_COMPLETE)
            val levelUpNotice = if (claimResult.newRelationshipLevel != null) {
                " • ارتقى مستوى علاقتك إلى: ${claimResult.newRelationshipLevel.titleArabic}!"
            } else ""
            showBanner("${claimResult.messageArabic} (+${claimResult.moneyEarned} مال)$levelUpNotice")
            dismissNpcDialogue()
            saveGame()
        }
    }

    fun advanceNpcDialogue() {
        val npc = activeDialogueNpc ?: return
        audio.playSound(SoundEffect.INTERACT)
        val hasMore = npc.advanceDialogue(worldTime.timeOfDay)
        if (!hasMore) {
            dismissNpcDialogue()
        }
    }

    fun handleNpcAction(actionType: NPCActionType) {
        dismissNpcDialogue()
        when (actionType) {
            NPCActionType.OPEN_SEED_SHOP -> {
                if (BuildingHours.isSeedShopOpen(worldTime.currentHour)) {
                    audio.playSound(SoundEffect.INTERACT)
                    showSeedShopDialog = true
                } else {
                    showBanner(BuildingHours.SEED_SHOP_CLOSED_MESSAGE)
                }
            }
            NPCActionType.OPEN_MARKET -> {
                if (BuildingHours.isMarketOpen(worldTime.currentHour)) {
                    audio.playSound(SoundEffect.INTERACT)
                    showMarketDialog = true
                } else {
                    showBanner(BuildingHours.MARKET_CLOSED_MESSAGE)
                }
            }
            NPCActionType.FARMING_HINT -> {
                showBanner("نصيحة مازن: احرص على تقليب التربة قبل وضع البذور.")
            }
            NPCActionType.TOOL_HINT -> {
                showBanner("نصيحة أمين: فأس برونزي حاد يضاعف سرعة تقطيع الخشب.")
            }
            NPCActionType.NONE -> {}
        }
    }

    fun dismissNpcDialogue() {
        activeDialogueNpc?.let { npc ->
            npcController.stopTalking(npc, worldTime.timeOfDay)
        }
        activeDialogueNpc = null
        activeQuestPrompt = null
        activeQuestTurnIn = null
        showNpcDialogueDialog = false
        saveGame() // Persist that player interacted with this NPC
    }

    private fun startZoneTransition(targetZone: ZoneId, spawnX: Float, spawnY: Float) {
        if (isTransitioning) return
        isTransitioning = true
        transitionTimer = 0f
        pendingTargetZoneId = targetZone
        pendingSpawnX = spawnX
        pendingSpawnY = spawnY
    }
}
