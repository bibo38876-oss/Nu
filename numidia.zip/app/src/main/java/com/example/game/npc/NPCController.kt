package com.example.game.npc

import android.graphics.RectF
import com.example.game.state.Direction
import com.example.game.time.TimeOfDay
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

class NPCController {

    val npcs: List<NPCState> = NPCDefinition.ALL_NPCS.map { def ->
        NPCState(definition = def).apply {
            val initialEntry = def.schedule.getEntryForHour(8)
            currentScheduledEntry = initialEntry
            currentActivity = initialEntry.activity
            x = initialEntry.targetX
            y = initialEntry.targetY
            targetX = initialEntry.targetX
            targetY = initialEntry.targetY
        }
    }

    fun update(
        dt: Float,
        playerX: Float,
        playerY: Float,
        colliders: List<RectF>,
        worldHour: Int = 12
    ) {
        for (npc in npcs) {
            updateSingleNpc(npc, dt, playerX, playerY, colliders, worldHour)
        }
    }

    private fun updateSingleNpc(
        npc: NPCState,
        dt: Float,
        playerX: Float,
        playerY: Float,
        colliders: List<RectF>,
        worldHour: Int
    ) {
        // 1. Sync schedule entry with current world time
        val entry = npc.definition.schedule.getEntryForHour(worldHour)
        if (npc.currentScheduledEntry != entry) {
            npc.currentScheduledEntry = entry
            npc.currentActivity = entry.activity

            // If not actively engaged in dialogue, head toward new scheduled location
            if (npc.behavior != NPCBehavior.TALKING) {
                npc.targetX = entry.targetX
                npc.targetY = entry.targetY
                val dist = npc.distanceTo(entry.targetX, entry.targetY)
                if (dist > 6.0f) {
                    npc.behavior = NPCBehavior.WANDERING
                    npc.isMoving = true
                }
            }
        }

        // 2. Behavior State Machine
        when (npc.behavior) {
            NPCBehavior.TALKING -> {
                // Keep facing the player while conversing
                npc.isMoving = false
                npc.animFrame = 0
                npc.facePlayer(playerX, playerY)
            }

            NPCBehavior.IDLE -> {
                npc.isMoving = false
                npc.animFrame = 0

                // If sleeping at night, stay resting quietly at home
                if (npc.currentActivity == NPCActivity.SLEEPING) {
                    npc.behaviorTimer = 3.0f
                    npc.direction = Direction.DOWN
                    return
                }

                npc.behaviorTimer -= dt
                if (npc.behaviorTimer <= 0f) {
                    val activeSchedule = npc.currentScheduledEntry ?: entry

                    // Decide next action: wander around scheduled anchor or look around
                    if (Random.nextFloat() < 0.60f) {
                        // Pick wander target around scheduled post anchor
                        val angle = Random.nextFloat() * (2f * Math.PI.toFloat())
                        val dist = Random.nextFloat() * activeSchedule.wanderRadius
                        val targetX = activeSchedule.targetX + kotlin.math.cos(angle) * dist
                        val targetY = activeSchedule.targetY + kotlin.math.sin(angle) * dist

                        // Test collision before committing target
                        val footBox = RectF(targetX - 7f, targetY + 2f, targetX + 7f, targetY + 12f)
                        val collides = colliders.any { box -> RectF.intersects(footBox, box) }
                        if (!collides) {
                            npc.targetX = targetX
                            npc.targetY = targetY
                            npc.behavior = NPCBehavior.WANDERING
                            npc.isMoving = true
                        } else {
                            npc.behaviorTimer = Random.nextFloat() * 2f + 1.5f
                        }
                    } else {
                        // Look around in another direction
                        val dirs = Direction.entries
                        npc.direction = dirs[Random.nextInt(dirs.size)]
                        npc.behavior = NPCBehavior.LOOKING_AROUND
                        npc.behaviorTimer = Random.nextFloat() * 2.0f + 1.0f
                    }
                }
            }

            NPCBehavior.LOOKING_AROUND -> {
                npc.isMoving = false
                npc.animFrame = 0
                npc.behaviorTimer -= dt
                if (npc.behaviorTimer <= 0f) {
                    npc.behavior = NPCBehavior.IDLE
                    npc.behaviorTimer = Random.nextFloat() * 3.0f + 2.0f
                }
            }

            NPCBehavior.WANDERING -> {
                val dx = npc.targetX - npc.x
                val dy = npc.targetY - npc.y
                val dist = sqrt(dx * dx + dy * dy)

                if (dist <= 2.5f) {
                    // Reached wander or schedule destination
                    npc.x = npc.targetX
                    npc.y = npc.targetY
                    npc.isMoving = false
                    npc.animFrame = 0
                    npc.behavior = NPCBehavior.IDLE
                    npc.behaviorTimer = Random.nextFloat() * 3.0f + 2.0f
                } else {
                    // Walk toward destination (NO teleporting!)
                    val walkSpeed = npc.definition.schedule.walkSpeed
                    val moveDist = (walkSpeed * dt).coerceAtMost(dist)
                    val stepX = (dx / dist) * moveDist
                    val stepY = (dy / dist) * moveDist

                    val nextX = npc.x + stepX
                    val nextY = npc.y + stepY

                    // Check bounds collision
                    val footBox = RectF(nextX - 7f, nextY + 2f, nextX + 7f, nextY + 12f)
                    val collides = colliders.any { box -> RectF.intersects(footBox, box) }

                    if (!collides) {
                        npc.x = nextX
                        npc.y = nextY
                        npc.isMoving = true

                        // Dominant facing direction
                        npc.direction = when {
                            abs(dx) > abs(dy) -> if (dx > 0) Direction.RIGHT else Direction.LEFT
                            else -> if (dy > 0) Direction.DOWN else Direction.UP
                        }

                        // Walk cycle animation (0 -> 1 -> 0 -> 2)
                        npc.animTimer += dt
                        if (npc.animTimer >= 0.16f) {
                            npc.animTimer = 0f
                            npc.animFrame = (npc.animFrame + 1) % 4
                        }
                    } else {
                        // Collided with obstacle, abort current wander step and pause
                        npc.isMoving = false
                        npc.animFrame = 0
                        npc.behavior = NPCBehavior.IDLE
                        npc.behaviorTimer = Random.nextFloat() * 2f + 1.5f
                    }
                }
            }
        }
    }

    /**
     * Finds the closest NPC currently within interaction range of the player.
     */
    fun getClosestInteractableNPC(playerX: Float, playerY: Float): NPCState? {
        return npcs
            .filter { it.isPlayerInRange(playerX, playerY) }
            .minByOrNull { it.distanceTo(playerX, playerY) }
    }

    fun startTalking(npc: NPCState, playerX: Float, playerY: Float) {
        npc.behavior = NPCBehavior.TALKING
        npc.isMoving = false
        npc.animFrame = 0
        npc.facePlayer(playerX, playerY)
    }

    fun stopTalking(npc: NPCState, timeOfDay: TimeOfDay = TimeOfDay.DAY) {
        npc.behavior = NPCBehavior.IDLE
        npc.behaviorTimer = 2.0f
        npc.resetDialogueForNextEncounter(timeOfDay)
    }

    fun getMetNpcIdStrings(): List<String> {
        return npcs.filter { it.hasMetPlayer }.map { it.definition.id.idString }
    }

    fun loadMetNpcIdStrings(metIds: List<String>) {
        val metSet = metIds.toSet()
        for (npc in npcs) {
            if (npc.definition.id.idString in metSet) {
                npc.hasMetPlayer = true
            }
        }
    }
}
