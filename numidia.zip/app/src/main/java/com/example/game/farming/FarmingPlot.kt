package com.example.game.farming

import kotlin.math.max
import kotlin.math.min

enum class FarmingPlotState {
    EMPTY,       // Raw available ground spot ("إنشاء أرض")
    CREATED,     // Plot created, soil unworked ("تقليب التربة")
    PREPARED,    // Soil hoed & prepared, ready for seeds ("زراعة")
    PLANTED,     // Just planted
    GROWING,     // Crop actively growing ("قيد النمو")
    MATURE,      // Crop fully ripe and ready ("حصاد")
    HARVESTED    // Crop collected
}

data class FarmingPlot(
    val id: String,
    val worldX: Float,
    val worldY: Float,
    var state: FarmingPlotState = FarmingPlotState.EMPTY,
    var plantedCrop: CropType? = null,
    var plantedTimestampMs: Long = 0L,
    var consecutiveHarvests: Int = 0,
    var soilQuality: Float = 1.0f // 1.0 = 100% quality
) {
    fun getFatiguePenaltySeconds(): Int {
        return min(MAX_FATIGUE_PENALTY_SEC, consecutiveHarvests * FATIGUE_PENALTY_PER_HARVEST_SEC)
    }

    fun getTotalGrowthDurationSeconds(): Int {
        val base = plantedCrop?.baseGrowthSeconds ?: 30
        return base + getFatiguePenaltySeconds()
    }

    fun getElapsedSeconds(currentTimeMs: Long = System.currentTimeMillis()): Long {
        if (plantedTimestampMs <= 0L) return 0L
        return max(0L, (currentTimeMs - plantedTimestampMs) / 1000L)
    }

    fun getRemainingSeconds(currentTimeMs: Long = System.currentTimeMillis()): Int {
        val total = getTotalGrowthDurationSeconds()
        val elapsed = getElapsedSeconds(currentTimeMs)
        return max(0, (total - elapsed).toInt())
    }

    fun getGrowthProgress(currentTimeMs: Long = System.currentTimeMillis()): Float {
        val total = getTotalGrowthDurationSeconds().toFloat()
        if (total <= 0f) return 1f
        val elapsed = getElapsedSeconds(currentTimeMs).toFloat()
        return (elapsed / total).coerceIn(0f, 1f)
    }

    /**
     * Growth stages:
     * Stage 1 (0%..25%): Freshly planted soil & seed mound
     * Stage 2 (25%..60%): Small green sprout
     * Stage 3 (60%..99%): Growing leafy plant
     * Stage 4 (100%): Mature harvestable crop
     */
    fun getGrowthStage(currentTimeMs: Long = System.currentTimeMillis()): Int {
        val progress = getGrowthProgress(currentTimeMs)
        return when {
            progress >= 1.0f -> 4
            progress >= 0.60f -> 3
            progress >= 0.25f -> 2
            else -> 1
        }
    }

    fun isMature(currentTimeMs: Long = System.currentTimeMillis()): Boolean {
        if (state == FarmingPlotState.MATURE) return true
        if (state == FarmingPlotState.PLANTED || state == FarmingPlotState.GROWING) {
            return getGrowthProgress(currentTimeMs) >= 1.0f
        }
        return false
    }

    fun updateStateWithTime(currentTimeMs: Long = System.currentTimeMillis()) {
        if (state == FarmingPlotState.PLANTED || state == FarmingPlotState.GROWING) {
            if (isMature(currentTimeMs)) {
                state = FarmingPlotState.MATURE
            } else {
                state = FarmingPlotState.GROWING
            }
        }
    }

    fun createPlot() {
        if (state == FarmingPlotState.EMPTY) {
            state = FarmingPlotState.CREATED
        }
    }

    fun prepareSoil() {
        if (state == FarmingPlotState.CREATED || state == FarmingPlotState.EMPTY) {
            state = FarmingPlotState.PREPARED
        }
    }

    fun plant(crop: CropType, currentTimeMs: Long = System.currentTimeMillis()) {
        plantedCrop = crop
        plantedTimestampMs = currentTimeMs
        state = FarmingPlotState.GROWING
    }

    fun harvest(): CropType? {
        if (state != FarmingPlotState.MATURE) return null
        val harvested = plantedCrop
        state = FarmingPlotState.EMPTY
        plantedCrop = null
        plantedTimestampMs = 0L

        // Apply fatigue & quality degradation
        consecutiveHarvests++
        soilQuality = max(0.50f, soilQuality - 0.05f)

        return harvested
    }

    fun isNear(px: Float, py: Float): Boolean {
        val dx = px - worldX
        val dy = py - worldY
        return (dx * dx + dy * dy) <= (INTERACTION_RADIUS * INTERACTION_RADIUS)
    }

    fun toSerialized(): String {
        val cropId = plantedCrop?.id ?: "none"
        return "$id,$worldX,$worldY,${state.name},$cropId,$plantedTimestampMs,$consecutiveHarvests,$soilQuality"
    }

    companion object {
        const val FATIGUE_PENALTY_PER_HARVEST_SEC = 5
        const val MAX_FATIGUE_PENALTY_SEC = 40
        const val INTERACTION_RADIUS = 46f

        fun fromSerialized(data: String): FarmingPlot? {
            val parts = data.split(",")
            if (parts.size < 8) return null
            val id = parts[0]
            val x = parts[1].toFloatOrNull() ?: return null
            val y = parts[2].toFloatOrNull() ?: return null
            val state = try { FarmingPlotState.valueOf(parts[3]) } catch (e: Exception) { FarmingPlotState.EMPTY }
            val crop = CropType.fromId(parts[4])
            val timestamp = parts[5].toLongOrNull() ?: 0L
            val harvests = parts[6].toIntOrNull() ?: 0
            val quality = parts[7].toFloatOrNull() ?: 1.0f

            return FarmingPlot(
                id = id,
                worldX = x,
                worldY = y,
                state = state,
                plantedCrop = crop,
                plantedTimestampMs = timestamp,
                consecutiveHarvests = harvests,
                soilQuality = quality
            )
        }
    }
}
