package com.example.game.art

import android.graphics.Bitmap
import com.example.game.farming.CropType
import com.example.game.farming.FarmingPlotState
import com.example.game.state.Direction

object PixelFarmingSprites {

    lateinit var plotEmptyBmp: Bitmap
    lateinit var plotCreatedBmp: Bitmap
    lateinit var plotPreparedBmp: Bitmap

    lateinit var cropStage1Bmp: Bitmap
    lateinit var cropStage2Bmp: Bitmap
    lateinit var cropStage3Bmp: Bitmap

    val matureCropBitmaps = mutableMapOf<CropType, Bitmap>()
    val playerActionBitmaps = mutableMapOf<Direction, Bitmap>()

    private var isInitialized = false

    fun initialize() {
        if (isInitialized) return

        generatePlotSprites()
        generateCropStageSprites()
        generateMatureCropSprites()
        generatePlayerActionSprites()

        isInitialized = true
    }

    private fun createPixelBitmap(width: Int, height: Int, drawer: (Bitmap) -> Unit): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        drawer(bitmap)
        return bitmap
    }

    private fun setPixel(bitmap: Bitmap, x: Int, y: Int, color: Int) {
        if (x in 0 until bitmap.width && y in 0 until bitmap.height) {
            bitmap.setPixel(x, y, color)
        }
    }

    private fun fillRect(bitmap: Bitmap, x1: Int, y1: Int, x2: Int, y2: Int, color: Int) {
        for (y in y1..y2) {
            for (x in x1..x2) {
                setPixel(bitmap, x, y, color)
            }
        }
    }

    // --- 1. FARMING PLOT SOIL SPRITES (28x20 pixels) ---
    private fun generatePlotSprites() {
        // EMPTY PLOT: Uncultivated earth patch with wooden peg marker
        plotEmptyBmp = createPixelBitmap(28, 20) { bmp ->
            // Subtle soil patch on grass
            fillRect(bmp, 3, 3, 24, 16, PixelPalette.DIRT_DARK)
            fillRect(bmp, 5, 4, 22, 15, PixelPalette.DIRT_MID)

            // Small grass tufts blending with edges
            setPixel(bmp, 2, 4, PixelPalette.GRASS_MID)
            setPixel(bmp, 3, 2, PixelPalette.GRASS_MID)
            setPixel(bmp, 24, 17, PixelPalette.GRASS_MID)
            setPixel(bmp, 25, 15, PixelPalette.GRASS_LIGHT)

            // Small wooden corner pegs marking available land
            fillRect(bmp, 4, 4, 5, 7, PixelPalette.WOOD_BEAM_MID)
            fillRect(bmp, 22, 4, 23, 7, PixelPalette.WOOD_BEAM_MID)
            fillRect(bmp, 4, 13, 5, 16, PixelPalette.WOOD_BEAM_MID)
            fillRect(bmp, 22, 13, 23, 16, PixelPalette.WOOD_BEAM_MID)
            setPixel(bmp, 4, 4, PixelPalette.WOOD_BEAM_LIGHT)
            setPixel(bmp, 22, 4, PixelPalette.WOOD_BEAM_LIGHT)
        }

        // CREATED PLOT: Cultivated soil with clumpy earth
        plotCreatedBmp = createPixelBitmap(28, 20) { bmp ->
            fillRect(bmp, 2, 2, 25, 17, PixelPalette.FARM_SOIL_DARK)
            fillRect(bmp, 3, 3, 24, 16, PixelPalette.FARM_SOIL_MID)

            // Soil clumps & variations
            val clumps = listOf(
                Pair(6, 6), Pair(12, 5), Pair(18, 7),
                Pair(8, 12), Pair(15, 13), Pair(20, 11)
            )
            for ((cx, cy) in clumps) {
                fillRect(bmp, cx, cy, cx + 2, cy + 1, PixelPalette.FARM_SOIL_LIGHT)
                setPixel(bmp, cx + 1, cy + 2, PixelPalette.FARM_SOIL_DARK)
            }
        }

        // PREPARED PLOT: Finely tilled, raked furrows ready for seed planting
        plotPreparedBmp = createPixelBitmap(28, 20) { bmp ->
            fillRect(bmp, 2, 2, 25, 17, PixelPalette.FARM_SOIL_DARK)
            fillRect(bmp, 3, 3, 24, 16, PixelPalette.FARM_SOIL_MID)

            // Neat agricultural planting furrows across the bed
            for (fy in listOf(5, 9, 13)) {
                for (fx in 4..23) {
                    setPixel(bmp, fx, fy, PixelPalette.FARM_SOIL_DARK)
                    setPixel(bmp, fx, fy - 1, PixelPalette.FARM_SOIL_LIGHT)
                }
            }

            // Moisten soil speckles (hydrated oasis soil)
            setPixel(bmp, 7, 7, PixelPalette.WATER_DEEP)
            setPixel(bmp, 14, 11, PixelPalette.WATER_DEEP)
            setPixel(bmp, 20, 7, PixelPalette.WATER_DEEP)
        }
    }

    // --- 2. EARLY GROWTH STAGE SPRITES ---
    private fun generateCropStageSprites() {
        // Stage 1: Seed Holes & Fresh Sprouts (16x12 pixels)
        cropStage1Bmp = createPixelBitmap(16, 12) { bmp ->
            // Seed mound
            fillRect(bmp, 5, 6, 10, 8, PixelPalette.FARM_SOIL_LIGHT)
            setPixel(bmp, 7, 5, PixelPalette.SPROUT_GREEN)
            setPixel(bmp, 8, 5, PixelPalette.SPROUT_GREEN)
            setPixel(bmp, 6, 7, PixelPalette.FARM_SOIL_DARK)
            setPixel(bmp, 9, 7, PixelPalette.FARM_SOIL_DARK)
        }

        // Stage 2: Small Twin-Leaf Sprout (16x16 pixels)
        cropStage2Bmp = createPixelBitmap(16, 16) { bmp ->
            // Stem
            fillRect(bmp, 7, 9, 8, 13, PixelPalette.CEDAR_LEAF_DARK)
            // Left leaf
            setPixel(bmp, 5, 8, PixelPalette.SPROUT_GREEN)
            fillRect(bmp, 6, 7, 7, 8, PixelPalette.OASIS_GREEN_LIGHT)
            // Right leaf
            setPixel(bmp, 10, 8, PixelPalette.SPROUT_GREEN)
            fillRect(bmp, 8, 7, 9, 8, PixelPalette.OASIS_GREEN_LIGHT)
            // Center shoot
            setPixel(bmp, 7, 6, PixelPalette.GRASS_LIGHT)
            setPixel(bmp, 8, 6, PixelPalette.GRASS_LIGHT)
        }

        // Stage 3: Growing Leafy Bush (20x20 pixels)
        cropStage3Bmp = createPixelBitmap(20, 20) { bmp ->
            // Stem base
            fillRect(bmp, 9, 14, 10, 17, PixelPalette.CEDAR_LEAF_DARK)
            // Main foliage cluster
            fillRect(bmp, 6, 7, 13, 13, PixelPalette.OASIS_GREEN)
            fillRect(bmp, 7, 5, 12, 10, PixelPalette.OASIS_GREEN_LIGHT)
            fillRect(bmp, 5, 9, 14, 12, PixelPalette.CEDAR_LEAF_MID)

            // Leaf tips
            setPixel(bmp, 5, 7, PixelPalette.SPROUT_GREEN)
            setPixel(bmp, 14, 7, PixelPalette.SPROUT_GREEN)
            setPixel(bmp, 9, 4, PixelPalette.SPROUT_GREEN)
            setPixel(bmp, 10, 4, PixelPalette.SPROUT_GREEN)
            setPixel(bmp, 8, 14, PixelPalette.CEDAR_LEAF_DARK)
            setPixel(bmp, 11, 14, PixelPalette.CEDAR_LEAF_DARK)
        }
    }

    // --- 3. MATURE HARVESTABLE CROPS (24x24 pixels) ---
    private fun generateMatureCropSprites() {
        // CARROT (الجزر): Feathery green foliage with ripe orange carrot crown poking out
        matureCropBitmaps[CropType.CARROT] = createPixelBitmap(24, 24) { bmp ->
            // Carrot crowns in soil
            fillRect(bmp, 8, 16, 11, 20, PixelPalette.CARROT_ORANGE)
            fillRect(bmp, 9, 16, 10, 19, PixelPalette.CARROT_LIGHT)
            fillRect(bmp, 13, 17, 16, 21, PixelPalette.CARROT_ORANGE)
            fillRect(bmp, 14, 17, 15, 20, PixelPalette.CARROT_LIGHT)

            // Lush feathery carrot tops (foliage)
            fillRect(bmp, 7, 8, 17, 15, PixelPalette.OASIS_GREEN)
            fillRect(bmp, 8, 5, 16, 12, PixelPalette.SPROUT_GREEN)
            setPixel(bmp, 6, 6, PixelPalette.SPROUT_GREEN)
            setPixel(bmp, 17, 6, PixelPalette.SPROUT_GREEN)
            setPixel(bmp, 11, 3, PixelPalette.OASIS_GREEN_LIGHT)
            setPixel(bmp, 12, 3, PixelPalette.OASIS_GREEN_LIGHT)

            // Golden mature shimmer
            drawMatureShimmer(bmp)
        }

        // TOMATO (الطماطم): Tall tomato vine with plump bright red tomatoes
        matureCropBitmaps[CropType.TOMATO] = createPixelBitmap(24, 24) { bmp ->
            // Supporting timber stake
            fillRect(bmp, 11, 4, 12, 21, PixelPalette.WOOD_BEAM_MID)

            // Vine foliage
            fillRect(bmp, 6, 7, 17, 16, PixelPalette.OASIS_GREEN)
            fillRect(bmp, 8, 5, 15, 12, PixelPalette.OASIS_GREEN_LIGHT)

            // Plump red tomatoes
            drawTomato(bmp, 6, 12)
            drawTomato(bmp, 14, 11)
            drawTomato(bmp, 10, 15)

            // Golden mature shimmer
            drawMatureShimmer(bmp)
        }

        // POTATO (البطاطا): Hearty mound with white flower blossoms and golden-brown potato tubers
        matureCropBitmaps[CropType.POTATO] = createPixelBitmap(24, 24) { bmp ->
            // Hearty broad foliage
            fillRect(bmp, 5, 8, 18, 16, PixelPalette.CEDAR_LEAF_MID)
            fillRect(bmp, 7, 6, 16, 13, PixelPalette.OASIS_GREEN)
            fillRect(bmp, 9, 4, 14, 9, PixelPalette.OASIS_GREEN_LIGHT)

            // White blossoms
            setPixel(bmp, 9, 4, 0xFFFFFFFF.toInt())
            setPixel(bmp, 14, 5, 0xFFFFFFFF.toInt())
            setPixel(bmp, 11, 6, PixelPalette.GOLD_BRIGHT)

            // Potatoes peering from base of mound
            fillRect(bmp, 6, 17, 10, 20, PixelPalette.POTATO_BEIGE)
            fillRect(bmp, 13, 17, 17, 20, PixelPalette.POTATO_BEIGE)
            setPixel(bmp, 7, 18, PixelPalette.POTATO_DARK)
            setPixel(bmp, 14, 18, PixelPalette.POTATO_DARK)

            // Golden mature shimmer
            drawMatureShimmer(bmp)
        }

        // ONION (البصل): Slender upright stalks with golden-copper onion bulbs sitting in soil
        matureCropBitmaps[CropType.ONION] = createPixelBitmap(24, 24) { bmp ->
            // Green scallion stalks
            for (y in 4..15) {
                setPixel(bmp, 10, y, PixelPalette.OASIS_GREEN)
                setPixel(bmp, 12, y, PixelPalette.SPROUT_GREEN)
                setPixel(bmp, 14, y, PixelPalette.OASIS_GREEN)
            }
            setPixel(bmp, 9, 4, PixelPalette.SPROUT_GREEN)
            setPixel(bmp, 12, 2, PixelPalette.SPROUT_GREEN)
            setPixel(bmp, 15, 4, PixelPalette.SPROUT_GREEN)

            // Plump golden onion bulbs in soil
            fillRect(bmp, 7, 16, 11, 20, PixelPalette.ONION_GOLD)
            fillRect(bmp, 12, 15, 16, 20, PixelPalette.ONION_GOLD)
            fillRect(bmp, 8, 16, 10, 19, PixelPalette.ONION_SKIN)
            fillRect(bmp, 13, 16, 15, 19, PixelPalette.ONION_SKIN)

            // Golden mature shimmer
            drawMatureShimmer(bmp)
        }

        // PEPPER (الفلفل): Bushy plant with vibrant red hanging bell peppers
        matureCropBitmaps[CropType.PEPPER] = createPixelBitmap(24, 24) { bmp ->
            // Foliage
            fillRect(bmp, 6, 6, 17, 15, PixelPalette.OASIS_GREEN)
            fillRect(bmp, 8, 4, 15, 11, PixelPalette.OASIS_GREEN_LIGHT)

            // Hanging red peppers
            drawPepper(bmp, 7, 12)
            drawPepper(bmp, 14, 13)
            drawPepper(bmp, 11, 16)

            // Golden mature shimmer
            drawMatureShimmer(bmp)
        }

        // CUCUMBER (الخيار): Vining plant with yellow blossoms and crisp green cucumbers
        matureCropBitmaps[CropType.CUCUMBER] = createPixelBitmap(24, 24) { bmp ->
            // Leafy trellis foliage
            fillRect(bmp, 5, 5, 18, 14, PixelPalette.OASIS_GREEN)
            fillRect(bmp, 7, 3, 16, 10, PixelPalette.OASIS_GREEN_LIGHT)
            fillRect(bmp, 4, 12, 19, 16, PixelPalette.CEDAR_LEAF_DARK)

            // Yellow star blossoms
            setPixel(bmp, 8, 7, PixelPalette.GOLD_BRIGHT)
            setPixel(bmp, 15, 6, PixelPalette.GOLD_BRIGHT)

            // Crisp green hanging cucumbers
            fillRect(bmp, 7, 13, 9, 20, 0xFF2A5E2E.toInt())
            setPixel(bmp, 8, 14, 0xFF4A8E4E.toInt())
            fillRect(bmp, 14, 12, 16, 19, 0xFF2A5E2E.toInt())
            setPixel(bmp, 15, 13, 0xFF4A8E4E.toInt())

            // Golden mature shimmer
            drawMatureShimmer(bmp)
        }
    }

    private fun drawTomato(bmp: Bitmap, x: Int, y: Int) {
        fillRect(bmp, x, y, x + 3, y + 3, PixelPalette.TOMATO_RED)
        setPixel(bmp, x + 1, y + 1, PixelPalette.TOMATO_LIGHT)
        setPixel(bmp, x + 1, y, PixelPalette.OASIS_GREEN_DARK) // stem cap
    }

    private fun drawPepper(bmp: Bitmap, x: Int, y: Int) {
        fillRect(bmp, x, y, x + 2, y + 4, PixelPalette.PEPPER_RED)
        setPixel(bmp, x + 1, y + 1, PixelPalette.PEPPER_BRIGHT)
        setPixel(bmp, x + 1, y, PixelPalette.OASIS_GREEN_DARK)
    }

    private fun drawMatureShimmer(bmp: Bitmap) {
        // Subtle golden sparkle at the top corners indicating readiness for harvest
        setPixel(bmp, 3, 3, PixelPalette.GOLD_BRIGHT)
        setPixel(bmp, 4, 4, PixelPalette.GOLD_SHADOW)
        setPixel(bmp, 20, 3, PixelPalette.GOLD_BRIGHT)
        setPixel(bmp, 19, 4, PixelPalette.GOLD_SHADOW)
    }

    // --- 4. PLAYER FARMING ACTION SPRITES (16x24 pixels) ---
    private fun generatePlayerActionSprites() {
        for (dir in Direction.entries) {
            playerActionBitmaps[dir] = createPlayerActionBitmap(dir)
        }
    }

    private fun createPlayerActionBitmap(dir: Direction): Bitmap {
        val w = 16
        val h = 24
        return createPixelBitmap(w, h) { bmp ->
            // Player bent slightly forward, arms extended down towards soil with farming hoe/hand
            when (dir) {
                Direction.DOWN, Direction.LEFT, Direction.RIGHT -> {
                    // Head & hair lowered 2 pixels
                    fillRect(bmp, 5, 4, 10, 6, PixelPalette.HAIR_DARK)
                    fillRect(bmp, 4, 6, 11, 9, PixelPalette.SKIN_LIGHT)
                    fillRect(bmp, 4, 6, 11, 6, PixelPalette.VEST_TERRACOTTA) // headband

                    // Torso bending forward
                    fillRect(bmp, 4, 10, 11, 15, PixelPalette.TUNIC_CREAM)
                    fillRect(bmp, 4, 10, 6, 14, PixelPalette.VEST_TERRACOTTA)
                    fillRect(bmp, 9, 10, 11, 14, PixelPalette.VEST_TERRACOTTA)

                    // Arms reaching down to ground with tool/hands
                    fillRect(bmp, 3, 13, 5, 17, PixelPalette.TUNIC_CREAM)
                    fillRect(bmp, 10, 13, 12, 17, PixelPalette.TUNIC_CREAM)
                    setPixel(bmp, 4, 18, PixelPalette.SKIN_MID)
                    setPixel(bmp, 11, 18, PixelPalette.SKIN_MID)

                    // Wooden hoe / trowel shaft
                    fillRect(bmp, 7, 14, 8, 20, PixelPalette.WOOD_BEAM_MID)
                    fillRect(bmp, 6, 20, 9, 21, PixelPalette.STONE_MID)

                    // Legs planted in work stance
                    fillRect(bmp, 4, 16, 6, 22, PixelPalette.BOOTS_LEATHER)
                    fillRect(bmp, 9, 16, 11, 22, PixelPalette.BOOTS_LEATHER)
                }
                Direction.UP -> {
                    // Back facing, bent over
                    fillRect(bmp, 4, 4, 11, 9, PixelPalette.HAIR_DARK)
                    fillRect(bmp, 4, 10, 11, 15, PixelPalette.VEST_TERRACOTTA)
                    fillRect(bmp, 3, 13, 5, 17, PixelPalette.TUNIC_CREAM)
                    fillRect(bmp, 10, 13, 12, 17, PixelPalette.TUNIC_CREAM)
                    fillRect(bmp, 5, 16, 6, 22, PixelPalette.BOOTS_LEATHER)
                    fillRect(bmp, 9, 16, 10, 22, PixelPalette.BOOTS_LEATHER)
                }
            }
        }
    }
}
