package com.example.game.quest

data class QuestReward(
    val money: Int = 0,
    val items: List<Pair<String, Int>> = emptyList(), // Item ID to count
    val affinityBonus: Int = 5,
    val descriptionArabic: String = ""
)
