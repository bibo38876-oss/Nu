package com.example.game.world

class VillageZone : WorldZone(
    zoneId = ZoneId.VILLAGE,
    cols = 24,
    rows = 26,
    defaultSpawnX = 384f,
    defaultSpawnY = 460f
) {
    override val tiles: Array<Array<TileType>> = Array(rows) { r ->
        Array(cols) { c ->
            when {
                // North exit path (leading to Forest)
                c in 11..12 && r <= 6 -> TileType.DIRT_PATH

                // Village Central Plaza (Cobblestones around fountain)
                c in 9..14 && r in 11..16 -> TileType.COBBLESTONE

                // Main horizontal street connecting shops and plaza
                c in 5..18 && r in 9..10 -> TileType.DIRT_PATH

                // Vertical path from plaza down towards farming plot and village gate
                c in 11..12 && r in 17..22 -> TileType.DIRT_PATH

                // Path leading to Farm Plot (south-west)
                c in 4..10 && r in 16..17 -> TileType.DIRT_PATH

                // Farming Plot tilled soil field
                c in 3..7 && r in 18..21 -> TileType.FARM_SOIL

                // Paths to shop entrances
                c in 6..7 && r in 8..9 -> TileType.COBBLESTONE
                c in 16..17 && r in 8..9 -> TileType.COBBLESTONE

                // Default village ground
                else -> TileType.GRASS
            }
        }
    }

    override val objects: List<WorldObject> = buildList {
        // --- 1. BUILDINGS ---
        // Seed Shop (متجر البذور) in Northwest
        add(
            WorldObject(
                id = "building_seed_shop",
                type = ObjectType.SEED_SHOP,
                x = 216f,
                y = 230f,
                visualWidth = 112f,
                visualHeight = 100f,
                solid = true,
                collisionWidth = 104f,
                collisionHeight = 44f,
                collisionOffsetY = -10f,
                interactionLabelArabic = "متجر البذور",
                interactionAction = "TALK_SEED_SHOP",
                interactionRadius = 64f
            )
        )

        // Market / Selling Building (سوق التجارة) in Northeast
        add(
            WorldObject(
                id = "building_market",
                type = ObjectType.MARKET_STALL,
                x = 552f,
                y = 230f,
                visualWidth = 112f,
                visualHeight = 100f,
                solid = true,
                collisionWidth = 104f,
                collisionHeight = 44f,
                collisionOffsetY = -10f,
                interactionLabelArabic = "سوق التجارة",
                interactionAction = "TALK_MARKET",
                interactionRadius = 64f
            )
        )

        // --- 2. VILLAGE CENTER (Ancient Stone Well) ---
        add(
            WorldObject(
                id = "village_stone_well",
                type = ObjectType.STONE_WELL,
                x = 384f,
                y = 420f,
                visualWidth = 56f,
                visualHeight = 60f,
                solid = true,
                collisionWidth = 44f,
                collisionHeight = 32f,
                collisionOffsetY = -6f,
                interactionLabelArabic = "بئر القرية العذب",
                interactionAction = "INSPECT_WELL",
                interactionRadius = 50f
            )
        )

        // Clay amphoras near well and market
        add(WorldObject("amphora_1", ObjectType.CLAY_POT, 350f, 430f, 20f, 26f, solid = true, collisionWidth = 16f, collisionHeight = 14f))
        add(WorldObject("amphora_2", ObjectType.CLAY_POT, 418f, 432f, 20f, 26f, solid = true, collisionWidth = 16f, collisionHeight = 14f))
        add(WorldObject("amphora_shop", ObjectType.CLAY_POT, 280f, 240f, 20f, 26f, solid = true, collisionWidth = 16f, collisionHeight = 14f))
        add(WorldObject("amphora_market", ObjectType.CLAY_POT, 488f, 240f, 20f, 26f, solid = true, collisionWidth = 16f, collisionHeight = 14f))

        // Village Craftsman Workbench (طاولة الحرفي وسندان الأدوات) near Amin
        add(
            WorldObject(
                id = "workshop_workbench",
                type = ObjectType.WORKSHOP_TABLE,
                x = 445f,
                y = 350f,
                visualWidth = 64f,
                visualHeight = 44f,
                solid = true,
                collisionWidth = 52f,
                collisionHeight = 22f,
                collisionOffsetY = -6f,
                interactionLabelArabic = "طاولة الأدوات والسندان",
                interactionAction = "INSPECT_WORKBENCH",
                interactionRadius = 50f
            )
        )

        // --- 3. FARMING AREA PERIMETER & SIGN ---
        // Wooden fences framing the farm
        // Top fence of farm
        for (i in 0..4) {
            val fx = 100f + i * 32f
            if (i != 3) { // leave opening for entrance
                add(WorldObject("fence_top_$i", ObjectType.WOOD_FENCE_H, fx, 560f, 32f, 24f, solid = true, collisionWidth = 32f, collisionHeight = 12f))
            }
        }
        // Right fence of farm
        for (j in 0..3) {
            val fy = 580f + j * 30f
            add(WorldObject("fence_right_$j", ObjectType.WOOD_FENCE_V, 260f, fy, 20f, 30f, solid = true, collisionWidth = 12f, collisionHeight = 28f))
        }

        // Farm Signpost
        add(
            WorldObject(
                id = "sign_farm",
                type = ObjectType.SIGNPOST,
                x = 210f,
                y = 556f,
                visualWidth = 26f,
                visualHeight = 34f,
                solid = true,
                collisionWidth = 16f,
                collisionHeight = 14f,
                interactionLabelArabic = "حقل الزراعة الخصب",
                interactionAction = "INSPECT_FARM",
                interactionRadius = 46f
            )
        )

        // --- 4. FOREST EXIT PORTAL & SIGNPOST (North) ---
        add(
            WorldObject(
                id = "sign_forest_exit",
                type = ObjectType.SIGNPOST,
                x = 340f,
                y = 70f,
                visualWidth = 26f,
                visualHeight = 34f,
                solid = true,
                collisionWidth = 16f,
                collisionHeight = 14f,
                interactionLabelArabic = "شاخصة: إلى الغابة",
                interactionAction = "ENTER_FOREST",
                interactionRadius = 52f
            )
        )

        // Exit gateway trigger zone (Player walks into northern path)
        add(
            WorldObject(
                id = "portal_to_forest",
                type = ObjectType.ZONE_EXIT_PORTAL,
                x = 384f,
                y = 28f,
                visualWidth = 72f,
                visualHeight = 36f,
                solid = false,
                interactionLabelArabic = "دخول الغابة",
                interactionAction = "ENTER_FOREST",
                interactionRadius = 48f
            )
        )

        // Trees framing the northern forest gateway
        add(WorldObject("gateway_tree_l1", ObjectType.TREE_CYPRESS, 290f, 50f, 36f, 80f, solid = true, collisionWidth = 20f, collisionHeight = 16f))
        add(WorldObject("gateway_tree_l2", ObjectType.TREE_CYPRESS, 250f, 60f, 36f, 80f, solid = true, collisionWidth = 20f, collisionHeight = 16f))
        add(WorldObject("gateway_tree_r1", ObjectType.TREE_CYPRESS, 478f, 50f, 36f, 80f, solid = true, collisionWidth = 20f, collisionHeight = 16f))
        add(WorldObject("gateway_tree_r2", ObjectType.TREE_CYPRESS, 518f, 60f, 36f, 80f, solid = true, collisionWidth = 20f, collisionHeight = 16f))

        // --- 5. VILLAGE TREES & VEGETATION ---
        // Olive trees near the plaza
        add(WorldObject("olive_1", ObjectType.TREE_OLIVE, 260f, 380f, 68f, 74f, solid = true, collisionWidth = 28f, collisionHeight = 18f))
        add(WorldObject("olive_2", ObjectType.TREE_OLIVE, 510f, 380f, 68f, 74f, solid = true, collisionWidth = 28f, collisionHeight = 18f))
        add(WorldObject("olive_south", ObjectType.TREE_OLIVE, 340f, 660f, 68f, 74f, solid = true, collisionWidth = 28f, collisionHeight = 18f))

        // Large Cedars providing shade
        add(WorldObject("cedar_nw", ObjectType.TREE_CEDAR, 80f, 150f, 84f, 96f, solid = true, collisionWidth = 34f, collisionHeight = 22f))
        add(WorldObject("cedar_ne", ObjectType.TREE_CEDAR, 680f, 150f, 84f, 96f, solid = true, collisionWidth = 34f, collisionHeight = 22f))
        add(WorldObject("cedar_se", ObjectType.TREE_CEDAR, 660f, 620f, 84f, 96f, solid = true, collisionWidth = 34f, collisionHeight = 22f))

        // Decorative bushes and boulders
        add(WorldObject("bush_1", ObjectType.BERRY_BUSH, 160f, 320f, 36f, 32f, solid = true, collisionWidth = 28f, collisionHeight = 18f))
        add(WorldObject("bush_2", ObjectType.BERRY_BUSH, 610f, 320f, 36f, 32f, solid = true, collisionWidth = 28f, collisionHeight = 18f))
        add(WorldObject("boulder_1", ObjectType.BOULDER, 450f, 620f, 38f, 30f, solid = true, collisionWidth = 32f, collisionHeight = 18f))
        add(WorldObject("boulder_2", ObjectType.BOULDER, 100f, 440f, 38f, 30f, solid = true, collisionWidth = 32f, collisionHeight = 18f))
    }
}
