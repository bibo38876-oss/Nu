package com.example.game.ui.hud

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.engine.GameEngine

@Composable
fun GameHud(
    engine: GameEngine,
    modifier: Modifier = Modifier
) {
    // Enforce pure Arabic RTL layout direction
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = modifier
                .fillMaxSize()
        ) {
            // --- 1. TOP STATUS BAR (Zone Title, Quests, Wood & Money) ---
            TopHudBar(
                zoneName = engine.currentZone.zoneId.displayNameArabic,
                money = engine.moneyDisplay,
                currencyLabel = engine.economy.currencyNameArabic,
                woodCount = engine.inventory.getTotalQuantity("wood"),
                isForest = engine.currentZone.zoneId == com.example.game.world.ZoneId.FOREST,
                activeQuestsCount = engine.questManager.getActiveQuests().size,
                onOpenQuests = { engine.showQuestMenuDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            )

            // --- 1.5 COMPACT HUD QUEST TRACKER WIDGET ---
            val activeQuests = engine.questManager.getActiveQuests()
            if (activeQuests.isNotEmpty() && !engine.isAnyDialogOpen) {
                QuestTrackerHud(
                    activeQuests = activeQuests,
                    onOpenQuestMenu = { engine.showQuestMenuDialog = true },
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .statusBarsPadding()
                        .padding(top = 64.dp, start = 16.dp)
                )
            }

            // --- 2. BANNER NOTIFICATION (Zone entries, dialogues, inspects) ---
            AnimatedVisibility(
                visible = engine.notificationBannerText != null,
                enter = fadeIn() + slideInVertically { -it },
                exit = fadeOut() + slideOutVertically { -it },
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 70.dp, start = 20.dp, end = 20.dp)
            ) {
                engine.notificationBannerText?.let { text ->
                    NotificationBanner(text = text)
                }
            }

            // --- 3. BOTTOM CONTROLS (Movement on Left, Interaction on Right) ---
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    // Mobile Movement Controls (Joystick + D-Pad toggle, thumb-friendly)
                    MovementControlPad(
                        onValueChange = { dx, dy ->
                            if (!engine.isAnyDialogOpen) {
                                engine.joystickDeltaX = dx
                                engine.joystickDeltaY = dy
                            }
                        }
                    )

                    // Contextual Interaction Button (Action thumb-friendly on right)
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        ContextualActionButton(
                            activeInteractionLabel = if (!engine.isAnyDialogOpen) engine.contextualButtonLabel else null,
                            onClick = { engine.onInteractButtonClicked() }
                        )
                    }
                }
            }

            // --- 4. SEED SELECTION DIALOG (Farming) ---
            if (engine.showSeedSelectionDialog && engine.selectedPlotForPlanting != null) {
                SeedSelectionDialog(
                    plot = engine.selectedPlotForPlanting!!,
                    inventory = engine.inventory,
                    onSelectSeed = { crop ->
                        engine.plantSeedOnPlot(crop)
                    },
                    onDismiss = {
                        engine.showSeedSelectionDialog = false
                        engine.selectedPlotForPlanting = null
                    }
                )
            }

            // --- 5. SEED SHOP DIALOG (Buying) ---
            if (engine.showSeedShopDialog) {
                SeedShopDialog(
                    currentMoney = engine.moneyDisplay,
                    inventory = engine.inventory,
                    onBuySeed = { seedItem, qty ->
                        engine.buySeedFromShop(seedItem, qty)
                    },
                    onDismiss = {
                        engine.showSeedShopDialog = false
                    }
                )
            }

            // --- 6. MARKET DIALOG (Selling) ---
            if (engine.showMarketDialog) {
                MarketDialog(
                    currentMoney = engine.moneyDisplay,
                    inventory = engine.inventory,
                    onSellItem = { item, qty ->
                        engine.sellItemToMarket(item, qty)
                    },
                    onDismiss = {
                        engine.showMarketDialog = false
                    }
                )
            }

            // --- 7. STAGE 6 & 9: LIVING VILLAGE NPC DIALOGUE & QUESTS ---
            if (engine.showNpcDialogueDialog && engine.activeDialogueNpc != null) {
                NpcDialogueDialog(
                    npc = engine.activeDialogueNpc!!,
                    timeOfDay = engine.worldTime.timeOfDay,
                    availableQuest = engine.activeQuestPrompt,
                    turnInQuest = engine.activeQuestTurnIn,
                    onAcceptQuest = { questId -> engine.acceptQuest(questId) },
                    onClaimReward = { questId -> engine.claimQuestReward(questId) },
                    onNextLine = { engine.advanceNpcDialogue() },
                    onActionClicked = { actionType -> engine.handleNpcAction(actionType) },
                    onDismiss = { engine.dismissNpcDialogue() }
                )
            }

            // --- 8. STAGE 9: QUEST & COMMUNITY MENU DIALOG ---
            if (engine.showQuestMenuDialog) {
                QuestMenuDialog(
                    questManager = engine.questManager,
                    relationshipManager = engine.relationshipManager,
                    onAcceptQuest = { questId ->
                        engine.acceptQuest(questId)
                    },
                    onDismiss = {
                        engine.showQuestMenuDialog = false
                    }
                )
            }
        }
    }
}

@Composable
private fun TopHudBar(
    zoneName: String,
    money: Int,
    currencyLabel: String,
    woodCount: Int,
    isForest: Boolean,
    activeQuestsCount: Int,
    onOpenQuests: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left side: Zone Identity Badge and Quests button
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Zone Identity Badge
            Box(
                modifier = Modifier
                    .shadow(elevation = 6.dp, shape = RoundedCornerShape(14.dp))
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0xE62A1B12), Color(0xF018100A))
                        )
                    )
                    .border(
                        width = 1.5.dp,
                        color = Color(0xFFC87D43),
                        shape = RoundedCornerShape(14.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 8.dp)
                    .testTag("zone_badge")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Eco,
                        contentDescription = null,
                        tint = Color(0xFF7BAA5A),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = zoneName,
                        color = Color(0xFFF7EED6),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Quests Button
            Box(
                modifier = Modifier
                    .shadow(elevation = 6.dp, shape = RoundedCornerShape(14.dp))
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0xE62A1B12), Color(0xF018100A))
                        )
                    )
                    .border(
                        width = 1.5.dp,
                        color = Color(0xFFE2B26C),
                        shape = RoundedCornerShape(14.dp)
                    )
                    .clickable { onOpenQuests() }
                    .padding(horizontal = 10.dp, vertical = 8.dp)
                    .testTag("quests_hud_button")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Assignment,
                        contentDescription = "المهام",
                        tint = Color(0xFFFFD466),
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "المهام",
                        color = Color(0xFFF7EED6),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (activeQuestsCount > 0) {
                        Spacer(modifier = Modifier.width(5.dp))
                        Box(
                            modifier = Modifier
                                .size(17.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFC7782A)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$activeQuestsCount",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Right side: Wood counter (when in forest or holding wood) and Money Balance
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (woodCount > 0 || isForest) {
                Box(
                    modifier = Modifier
                        .shadow(elevation = 6.dp, shape = RoundedCornerShape(14.dp))
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0xE62A1B12), Color(0xF018100A))
                            )
                        )
                        .border(
                            width = 1.5.dp,
                            color = Color(0xFFB8783C),
                            shape = RoundedCornerShape(14.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        .testTag("wood_badge")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "🪵",
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$woodCount",
                            color = Color(0xFFF2D3A5),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Real Money Balance Counter
            Box(
                modifier = Modifier
                    .shadow(elevation = 6.dp, shape = RoundedCornerShape(14.dp))
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0xE62A1B12), Color(0xF018100A))
                        )
                    )
                    .border(
                        width = 1.5.dp,
                        color = Color(0xFFE0A838),
                        shape = RoundedCornerShape(14.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .testTag("money_badge")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.MonetizationOn,
                        contentDescription = null,
                        tint = Color(0xFFF5C538),
                        modifier = Modifier.size(19.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "$money $currencyLabel",
                        color = Color(0xFFFFD466),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun NotificationBanner(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(elevation = 10.dp, shape = RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xF5332216), Color(0xFB1F140D))
                )
            )
            .border(
                width = 2.dp,
                color = Color(0xFFD49B55),
                shape = RoundedCornerShape(16.dp)
            )
            .padding(horizontal = 18.dp, vertical = 12.dp)
            .testTag("notification_banner"),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color(0xFFFAF2E3),
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun ContextualActionButton(
    activeInteractionLabel: String?,
    onClick: () -> Unit
) {
    val isEnabled = activeInteractionLabel != null

    val buttonLabel = when {
        activeInteractionLabel == "قطع" -> "قطع"
        activeInteractionLabel == "قيد القطع..." -> "قطع..."
        activeInteractionLabel != null && activeInteractionLabel.length <= 6 -> activeInteractionLabel
        else -> "تفاعل"
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Context hint chip if present
        AnimatedVisibility(
            visible = isEnabled,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xD91F140D))
                    .border(1.dp, Color(0xFFC87D43), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = activeInteractionLabel ?: "",
                    color = Color(0xFFF5EBD7),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Circular Action Button
        Box(
            modifier = Modifier
                .size(76.dp)
                .shadow(
                    elevation = if (isEnabled) 10.dp else 2.dp,
                    shape = CircleShape
                )
                .clip(CircleShape)
                .background(
                    if (isEnabled) {
                        Brush.verticalGradient(
                            colors = listOf(Color(0xFFD97724), Color(0xFF8A3C12))
                        )
                    } else {
                        Brush.verticalGradient(
                            colors = listOf(Color(0x664A3525), Color(0x662C1E14))
                        )
                    }
                )
                .border(
                    width = 2.dp,
                    color = if (isEnabled) Color(0xFFFFD466) else Color(0x446B4E38),
                    shape = CircleShape
                )
                .clickable(
                    enabled = isEnabled,
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(color = Color.White),
                    onClick = onClick
                )
                .testTag("interact_button"),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.TouchApp,
                    contentDescription = activeInteractionLabel ?: "تفاعل",
                    tint = if (isEnabled) Color(0xFFFFF7E6) else Color(0x66A89688),
                    modifier = Modifier.size(28.dp)
                )
                Text(
                    text = buttonLabel,
                    color = if (isEnabled) Color(0xFFFFF7E6) else Color(0x66A89688),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
