package com.example.game.world

import android.graphics.RectF

enum class ObjectType {
    SEED_SHOP,
    MARKET_STALL,
    STONE_WELL,
    TREE_CEDAR,
    TREE_OLIVE,
    TREE_CYPRESS,
    BOULDER,
    BERRY_BUSH,
    CLAY_POT,
    WOOD_FENCE_H,
    WOOD_FENCE_V,
    SIGNPOST,
    ZONE_EXIT_PORTAL,
    WORKSHOP_TABLE
}

data class WorldObject(
    val id: String,
    val type: ObjectType,
    val x: Float, // World X anchor (center-bottom)
    val y: Float, // World Y anchor (ground contact)
    val visualWidth: Float,
    val visualHeight: Float,
    val solid: Boolean = true,
    val collisionWidth: Float = visualWidth * 0.8f,
    val collisionHeight: Float = visualHeight * 0.4f,
    val collisionOffsetY: Float = -collisionHeight / 2f,
    val interactionLabelArabic: String? = null,
    val interactionAction: String? = null, // e.g. "ENTER_FOREST", "ENTER_VILLAGE", "TALK_SEED_SHOP", "TALK_MARKET", "INSPECT_WELL", "INSPECT_FARM"
    val interactionRadius: Float = 54f
) {
    val sortY: Float get() = y

    val collisionBounds: RectF
        get() = RectF(
            x - collisionWidth / 2f,
            y + collisionOffsetY - collisionHeight / 2f,
            x + collisionWidth / 2f,
            y + collisionOffsetY + collisionHeight / 2f
        )

    fun isNear(px: Float, py: Float): Boolean {
        if (interactionAction == null && interactionLabelArabic == null) return false
        val dx = px - x
        val dy = py - y
        return (dx * dx + dy * dy) <= (interactionRadius * interactionRadius)
    }
}
