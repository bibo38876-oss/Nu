package com.example.game.farming

enum class CropType(
    val id: String,
    val nameArabic: String,
    val seedItemId: String,
    val harvestItemId: String,
    val baseGrowthSeconds: Int,
    val iconEmoji: String
) {
    CARROT(
        id = "carrot",
        nameArabic = "الجزر",
        seedItemId = "carrot_seeds",
        harvestItemId = "carrot",
        baseGrowthSeconds = 30,
        iconEmoji = "🥕"
    ),
    TOMATO(
        id = "tomato",
        nameArabic = "الطماطم",
        seedItemId = "tomato_seeds",
        harvestItemId = "tomato",
        baseGrowthSeconds = 60,
        iconEmoji = "🍅"
    ),
    POTATO(
        id = "potato",
        nameArabic = "البطاطا",
        seedItemId = "potato_seeds",
        harvestItemId = "potato",
        baseGrowthSeconds = 90,
        iconEmoji = "🥔"
    ),
    ONION(
        id = "onion",
        nameArabic = "البصل",
        seedItemId = "onion_seeds",
        harvestItemId = "onion",
        baseGrowthSeconds = 120,
        iconEmoji = "🧅"
    ),
    PEPPER(
        id = "pepper",
        nameArabic = "الفلفل",
        seedItemId = "pepper_seeds",
        harvestItemId = "pepper",
        baseGrowthSeconds = 180,
        iconEmoji = "🌶️"
    ),
    CUCUMBER(
        id = "cucumber",
        nameArabic = "الخيار",
        seedItemId = "cucumber_seeds",
        harvestItemId = "cucumber",
        baseGrowthSeconds = 240,
        iconEmoji = "🥒"
    );

    companion object {
        fun fromId(id: String?): CropType? = entries.find { it.id == id }
        fun fromSeedId(seedId: String?): CropType? = entries.find { it.seedItemId == seedId }
    }
}
