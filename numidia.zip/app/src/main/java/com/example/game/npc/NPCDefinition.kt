package com.example.game.npc

import com.example.game.state.Direction

enum class NPCId(val idString: String) {
    YASSIN("yassin"),
    SAMIRA("samira"),
    MAZEN("mazen"),
    AMIN("amin")
}

data class NPCDefinition(
    val id: NPCId,
    val nameArabic: String,
    val roleTitleArabic: String,
    val homeX: Float,
    val homeY: Float,
    val wanderRadius: Float = 24f,
    val defaultDirection: Direction = Direction.DOWN,
    val dialogue: NPCDialogue,
    val schedule: NPCSchedule,
    val interactionRange: Float = 54f
) {
    companion object {
        val ALL_NPCS = listOf(
            // 1. ياسين - تاجر البذور
            NPCDefinition(
                id = NPCId.YASSIN,
                nameArabic = "ياسين",
                roleTitleArabic = "تاجر البذور",
                homeX = 265f,
                homeY = 295f,
                wanderRadius = 26f,
                defaultDirection = Direction.DOWN,
                interactionRange = 54f,
                schedule = ScheduleManager.YASSIN_SCHEDULE,
                dialogue = NPCDialogue(
                    greetingLines = listOf(
                        DialogueLine(
                            id = "yassin_greet_1",
                            textArabic = "مرحباً بك في أرض نوميديا الخصبة! أنا ياسين، أجمع أجود بذور الواحات والجبال."
                        ),
                        DialogueLine(
                            id = "yassin_greet_2",
                            textArabic = "الجزر ينضج بسرعة ومثالي للبدايات، بينما الطماطم والفلفل يدرّان ربحاً وفيراً!",
                            actionType = NPCActionType.OPEN_SEED_SHOP,
                            actionLabelArabic = "فتح متجر البذور"
                        )
                    ),
                    regularLines = listOf(
                        DialogueLine(
                            id = "yassin_reg_1",
                            textArabic = "هل تحتاج إلى بذور جديدة لتربتك اليوم؟ محاصيلي منتقاة بعناية فائقة.",
                            actionType = NPCActionType.OPEN_SEED_SHOP,
                            actionLabelArabic = "فتح متجر البذور"
                        ),
                        DialogueLine(
                            id = "yassin_reg_2",
                            textArabic = "ابدأ بزراعة الجزر إذا كنت تريد محصولاً سريعاً ومضموناً."
                        )
                    ),
                    morningLines = listOf(
                        DialogueLine(
                            id = "yassin_morn_1",
                            textArabic = "صباح الخير والبركة! شمس نوميديا الصباحية مثالية لبداية غرس جديد.",
                            actionType = NPCActionType.OPEN_SEED_SHOP,
                            actionLabelArabic = "فتح متجر البذور"
                        ),
                        DialogueLine(
                            id = "yassin_morn_2",
                            textArabic = "أفرغت شحنة بذور طازجة هذا الصباح، تفقد ما يناسب حوضك."
                        )
                    ),
                    dayLines = listOf(
                        DialogueLine(
                            id = "yassin_day_1",
                            textArabic = "نهارك مبارك! العمل في الحقل في وضح النهار يملأ القلب بالنشاط.",
                            actionType = NPCActionType.OPEN_SEED_SHOP,
                            actionLabelArabic = "فتح متجر البذور"
                        ),
                        DialogueLine(
                            id = "yassin_day_2",
                            textArabic = "البطاطس والبصل محاصيل تتحمل حرارة النهار وتخزن ممتازاً."
                        )
                    ),
                    eveningLines = listOf(
                        DialogueLine(
                            id = "yassin_eve_1",
                            textArabic = "مساء الخير! اقترب وقت إغلاق متجر البذور لليوم.",
                            actionType = NPCActionType.OPEN_SEED_SHOP,
                            actionLabelArabic = "فتح متجر البذور"
                        ),
                        DialogueLine(
                            id = "yassin_eve_2",
                            textArabic = "احرص على غرس بذورك قبل حلول العتمة لتنمو طوال الليل."
                        )
                    ),
                    nightLines = listOf(
                        DialogueLine(
                            id = "yassin_night_1",
                            textArabic = "الوقت متأخر الآن والمتجر مغلق. غداً يوم جديد وموسم خير بإذن الله."
                        ),
                        DialogueLine(
                            id = "yassin_night_2",
                            textArabic = "أستريح الآن في داري، طابت ليلتك يا صديقي."
                        )
                    )
                )
            ),

            // 2. سميرة - تاجرة السوق
            NPCDefinition(
                id = NPCId.SAMIRA,
                nameArabic = "سميرة",
                roleTitleArabic = "تاجرة السوق",
                homeX = 515f,
                homeY = 295f,
                wanderRadius = 24f,
                defaultDirection = Direction.DOWN,
                interactionRange = 54f,
                schedule = ScheduleManager.SAMIRA_SCHEDULE,
                dialogue = NPCDialogue(
                    greetingLines = listOf(
                        DialogueLine(
                            id = "samira_greet_1",
                            textArabic = "أهلاً بك في سوق نوميديا العامر! أنا سميرة، وأسواقي تشتري كل ما تجنيه يداك."
                        ),
                        DialogueLine(
                            id = "samira_greet_2",
                            textArabic = "أشتري المحاصيل الطازجة وخشب الغابة بأسعار مجزية. حول حصادك إلى مالٍ وفير!",
                            actionType = NPCActionType.OPEN_MARKET,
                            actionLabelArabic = "فتح سوق التجارة"
                        )
                    ),
                    regularLines = listOf(
                        DialogueLine(
                            id = "samira_reg_1",
                            textArabic = "أهلاً بالمزارع النشيط! هل جلبت خضاراً طازجة أو خشباً لبيعه اليوم؟",
                            actionType = NPCActionType.OPEN_MARKET,
                            actionLabelArabic = "فتح سوق التجارة"
                        ),
                        DialogueLine(
                            id = "samira_reg_2",
                            textArabic = "خشب الأرز والسرو مطلوب دائماً للبناء والتدفئة في القرية."
                        )
                    ),
                    morningLines = listOf(
                        DialogueLine(
                            id = "samira_morn_1",
                            textArabic = "صباح الأرباح والتجارة الرابحة! السوق مفتوح لاستقبال كل ما جنيته.",
                            actionType = NPCActionType.OPEN_MARKET,
                            actionLabelArabic = "فتح سوق التجارة"
                        ),
                        DialogueLine(
                            id = "samira_morn_2",
                            textArabic = "التجار يتوافدون مبكراً ويبحثون عن الخضار الطازجة وقطع الخشب."
                        )
                    ),
                    dayLines = listOf(
                        DialogueLine(
                            id = "samira_day_1",
                            textArabic = "أهلاً بك! السوق يعج بالنشاط، بع محاصيلك وتزود بالمال الوفير.",
                            actionType = NPCActionType.OPEN_MARKET,
                            actionLabelArabic = "فتح سوق التجارة"
                        ),
                        DialogueLine(
                            id = "samira_day_2",
                            textArabic = "كلما بعت محاصيل أكثر، تمكنت من تطوير فأسك وتوسيع حقولك."
                        )
                    ),
                    eveningLines = listOf(
                        DialogueLine(
                            id = "samira_eve_1",
                            textArabic = "مساء الأنوار! أحسب أرباح اليوم قبل إغلاق السوق.",
                            actionType = NPCActionType.OPEN_MARKET,
                            actionLabelArabic = "فتح سوق التجارة"
                        ),
                        DialogueLine(
                            id = "samira_eve_2",
                            textArabic = "فرصة أخيرة الليلة لتصريف ما في جعبتك من خشب ومحاصيل."
                        )
                    ),
                    nightLines = listOf(
                        DialogueLine(
                            id = "samira_night_1",
                            textArabic = "السوق مغلق في هذا الوقت من الليل. نلتقي مع شروق شمس الغد!"
                        ),
                        DialogueLine(
                            id = "samira_night_2",
                            textArabic = "هدوء الليل يعيد النشاط لتاجر الصباح، ليلة هانئة."
                        )
                    )
                )
            ),

            // 3. مازن - مزارع القرية
            NPCDefinition(
                id = NPCId.MAZEN,
                nameArabic = "مازن",
                roleTitleArabic = "مزارع القرية",
                homeX = 240f,
                homeY = 515f,
                wanderRadius = 28f,
                defaultDirection = Direction.RIGHT,
                interactionRange = 54f,
                schedule = ScheduleManager.MAZEN_SCHEDULE,
                dialogue = NPCDialogue(
                    greetingLines = listOf(
                        DialogueLine(
                            id = "mazen_greet_1",
                            textArabic = "سلامٌ عليك يا صاحبي! أنا مازن، تراب هذا الحقل رفيقي منذ الصبا."
                        ),
                        DialogueLine(
                            id = "mazen_greet_2",
                            textArabic = "الأرض الطيبة كالصديق الوفي، كلما اعتنيت بها وبتقليب تربتها أهدتك أطيب الثمار."
                        )
                    ),
                    regularLines = listOf(
                        DialogueLine(
                            id = "mazen_reg_1",
                            textArabic = "تذكر دائماً: هيئ الأرض أولاً، ثم بذر بذارك، وانتظر نضجها بصبر وأمل."
                        ),
                        DialogueLine(
                            id = "mazen_reg_2",
                            textArabic = "عند اكتمال نضج المحصول، احصده سريعاً حتى تحرر الحوض لزراعة جديدة."
                        )
                    ),
                    morningLines = listOf(
                        DialogueLine(
                            id = "mazen_morn_1",
                            textArabic = "صباح الندى والبركة! تفقد شتلاتك مبكراً فالنبات يحب نسيم الصباح."
                        ),
                        DialogueLine(
                            id = "mazen_morn_2",
                            textArabic = "إذا قلبت التربة الآن، ستكون جاهزة لامتصاص دفء الشمس طوال اليوم."
                        )
                    ),
                    dayLines = listOf(
                        DialogueLine(
                            id = "mazen_day_1",
                            textArabic = "الشمس في كبد السماء، المحاصيل تنمو على مهل تحت هذا النور الطيب."
                        ),
                        DialogueLine(
                            id = "mazen_day_2",
                            textArabic = "أتابع نمو الجزر والفلفل، الأرض سخية لمن لا يملّ العمل."
                        )
                    ),
                    eveningLines = listOf(
                        DialogueLine(
                            id = "mazen_eve_1",
                            textArabic = "مساء الخير! خفت حرارة الشمس وبردت التربة، وقت ممتاز للتأمل في الحصاد."
                        ),
                        DialogueLine(
                            id = "mazen_eve_2",
                            textArabic = "ينتهي يوم العمل في الحقل مع انحدار قرص الشمس نحو الغروب."
                        )
                    ),
                    nightLines = listOf(
                        DialogueLine(
                            id = "mazen_night_1",
                            textArabic = "نامت الحقول يا صديقي. النبات يواصل نموه بهدوء تحت ضوء القمر."
                        ),
                        DialogueLine(
                            id = "mazen_night_2",
                            textArabic = "ارتح قليلاً، فغداً ينتظرنا عمل كثير في الأرض."
                        )
                    )
                )
            ),

            // 4. أمين - حرفي الأدوات
            NPCDefinition(
                id = NPCId.AMIN,
                nameArabic = "أمين",
                roleTitleArabic = "حرفي الأدوات",
                homeX = 445f,
                homeY = 370f,
                wanderRadius = 22f,
                defaultDirection = Direction.LEFT,
                interactionRange = 54f,
                schedule = ScheduleManager.AMIN_SCHEDULE,
                dialogue = NPCDialogue(
                    greetingLines = listOf(
                        DialogueLine(
                            id = "amin_greet_1",
                            textArabic = "حياك الله بالخير! أنا أمين، حرفي القرية. أصنع الأزاميل والفؤوس وأصلح العتاد."
                        ),
                        DialogueLine(
                            id = "amin_greet_2",
                            textArabic = "فأس برونزي حاد في يد نشيطة يقطع أشجار الغابة كأنها قش!"
                        )
                    ),
                    regularLines = listOf(
                        DialogueLine(
                            id = "amin_reg_1",
                            textArabic = "إذا أردت حطباً كثيراً، احرص على ضرب الأشجار بإيقاع متوازن."
                        ),
                        DialogueLine(
                            id = "amin_reg_2",
                            textArabic = "أشجار السرو الصغيرة سريعة القطع، بينما أشجار الأرز تمنحك خشبًا أمتن."
                        )
                    ),
                    morningLines = listOf(
                        DialogueLine(
                            id = "amin_morn_1",
                            textArabic = "صباح النشاط! السندان ساخن والمطرقة جاهزة لتجهيز الفؤوس."
                        ),
                        DialogueLine(
                            id = "amin_morn_2",
                            textArabic = "الفأس الجيد يبدأ به يوم الحطاب الماهر في غابة الأرز."
                        )
                    ),
                    dayLines = listOf(
                        DialogueLine(
                            id = "amin_day_1",
                            textArabic = "العمل قائم في الورشة! طرْق البرونز وتشكيل المقابض الخشبية."
                        ),
                        DialogueLine(
                            id = "amin_day_2",
                            textArabic = "احرص على جمع الخشب لتعين على ترقية وتطوير معداتك."
                        )
                    ),
                    eveningLines = listOf(
                        DialogueLine(
                            id = "amin_eve_1",
                            textArabic = "مساء الخير. أوشكت على إخماد نار الحدادة وتنظيف السندان."
                        ),
                        DialogueLine(
                            id = "amin_eve_2",
                            textArabic = "الأدوات تحتاج راحة وتنظيفاً بالزيت بعد يوم شاق من القطع."
                        )
                    ),
                    nightLines = listOf(
                        DialogueLine(
                            id = "amin_night_1",
                            textArabic = "الورشة مغلقة الآن يا صاحبي ونار الكير قد انطفأت. عد في الصباح."
                        ),
                        DialogueLine(
                            id = "amin_night_2",
                            textArabic = "ليلة هادئة، غداً أكون هنا بجانب السندان من جديد."
                        )
                    )
                )
            )
        )

        fun findById(id: NPCId): NPCDefinition? = ALL_NPCS.find { it.id == id }
    }
}
