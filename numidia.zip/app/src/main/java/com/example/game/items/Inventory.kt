package com.example.game.items

class Inventory(val maxSlots: Int = 16) {
    private val slots: MutableList<ItemStack?> = MutableList(maxSlots) { null }

    fun getSlots(): List<ItemStack?> = slots.toList()

    fun addItem(item: Item, count: Int = 1): Int {
        var remaining = count

        // 1. First attempt to stack with existing slots of the same item
        for (i in 0 until maxSlots) {
            val slot = slots[i]
            if (slot != null && slot.item.id == item.id && slot.quantity < item.maxStack) {
                val availableSpace = item.maxStack - slot.quantity
                val toAdd = kotlin.math.min(availableSpace, remaining)
                slot.quantity += toAdd
                remaining -= toAdd
                if (remaining <= 0) return 0
            }
        }

        // 2. Put into empty slots
        for (i in 0 until maxSlots) {
            if (slots[i] == null) {
                val toAdd = kotlin.math.min(item.maxStack, remaining)
                slots[i] = ItemStack(item, toAdd)
                remaining -= toAdd
                if (remaining <= 0) return 0
            }
        }

        return remaining // Amount that could not fit
    }

    fun removeItem(itemId: String, count: Int = 1): Boolean {
        var remaining = count
        // Check if we have enough
        val totalOwned = getTotalQuantity(itemId)
        if (totalOwned < count) return false

        for (i in (maxSlots - 1) downTo 0) {
            val slot = slots[i]
            if (slot != null && slot.item.id == itemId) {
                if (slot.quantity <= remaining) {
                    remaining -= slot.quantity
                    slots[i] = null
                } else {
                    slot.quantity -= remaining
                    remaining = 0
                }
                if (remaining == 0) break
            }
        }
        return true
    }

    fun getTotalQuantity(itemId: String): Int {
        return slots.filterNotNull().filter { it.item.id == itemId }.sumOf { it.quantity }
    }

    fun hasItem(itemId: String): Boolean {
        return getTotalQuantity(itemId) > 0
    }

    fun clear() {
        for (i in 0 until maxSlots) {
            slots[i] = null
        }
    }

    fun loadFromList(items: List<Pair<String, Int>>) {
        clear()
        for ((id, qty) in items) {
            val item = ItemCatalog.findById(id)
            if (item != null) {
                addItem(item, qty)
            }
        }
    }

    fun toSerializedList(): List<Pair<String, Int>> {
        return slots.filterNotNull().map { it.item.id to it.quantity }
    }
}
