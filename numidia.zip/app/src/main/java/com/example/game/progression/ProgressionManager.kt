package com.example.game.progression

import com.example.game.economy.EconomyManager
import com.example.game.economy.TransactionResult
import com.example.game.tools.ToolType

class ProgressionManager(
    initialAxeLevel: Int = 1,
    initialFarmLevel: Int = 1,
    initialUnlockedSeeds: Set<String> = DEFAULT_SEEDS
) {

    companion object {
        val DEFAULT_SEEDS = setOf(
            "carrot_seeds",
            "tomato_seeds",
            "potato_seeds",
            "onion_seeds",
            "pepper_seeds"
        )
    }

    var axeLevel: Int = initialAxeLevel.coerceIn(1, ToolUpgradeCatalog.getMaxLevel(ToolType.AXE))
        private set

    var farmExpansionLevel: Int = initialFarmLevel.coerceIn(1, FarmExpansionCatalog.getMaxLevel())
        private set

    private val unlockedSeeds = initialUnlockedSeeds.toMutableSet()

    fun isSeedUnlocked(seedItemId: String): Boolean {
        return unlockedSeeds.contains(seedItemId)
    }

    fun getAllUnlockedSeeds(): Set<String> = unlockedSeeds.toSet()

    fun getAxeGatherDurationMultiplier(): Float {
        return ToolUpgradeCatalog.getTier(ToolType.AXE, axeLevel)?.gatherDurationMultiplier ?: 1.0f
    }

    fun canUpgradeAxe(money: Int): Boolean {
        val nextTier = ToolUpgradeCatalog.getNextTier(ToolType.AXE, axeLevel) ?: return false
        return money >= nextTier.cost
    }

    fun upgradeAxe(economy: EconomyManager): TransactionResult {
        val nextTier = ToolUpgradeCatalog.getNextTier(ToolType.AXE, axeLevel)
            ?: return TransactionResult.Failure("وصل الفأس إلى أقصى مستوى تطوير حالياً!")

        if (!economy.canAfford(nextTier.cost)) {
            return TransactionResult.Failure("لا يوجد مال كافٍ! تحتاج إلى ${nextTier.cost} مال.")
        }

        // Atomic transaction: Deduct money first, then apply level
        val deducted = economy.spendMoney(nextTier.cost)
        if (!deducted) {
            return TransactionResult.Failure("تعذر إتمام عملية الدفع!")
        }

        axeLevel = nextTier.level
        return TransactionResult.Success(
            messageArabic = "تمت ترقية الفأس بنجاح إلى: ${nextTier.nameArabic}!",
            amountChanged = nextTier.cost,
            itemQuantity = 1
        )
    }

    fun canExpandFarm(money: Int): Boolean {
        val nextTier = FarmExpansionCatalog.getNextTier(farmExpansionLevel) ?: return false
        return money >= nextTier.cost
    }

    fun expandFarm(economy: EconomyManager): TransactionResult {
        val nextTier = FarmExpansionCatalog.getNextTier(farmExpansionLevel)
            ?: return TransactionResult.Failure("وصلت المزرعة إلى الحد الأقصى للتوسعة!")

        if (!economy.canAfford(nextTier.cost)) {
            return TransactionResult.Failure("لا يوجد مال كافٍ! تكلفة التوسعة ${nextTier.cost} مال.")
        }

        val deducted = economy.spendMoney(nextTier.cost)
        if (!deducted) {
            return TransactionResult.Failure("تعذر إتمام عملية التوسعة!")
        }

        farmExpansionLevel = nextTier.level
        return TransactionResult.Success(
            messageArabic = "تمت توسعة المزرعة بنجاح! المساحة الحالية: ${nextTier.totalPlots} قطع.",
            amountChanged = nextTier.cost,
            itemQuantity = nextTier.addedPlots
        )
    }

    fun unlockSeed(seedItemId: String, cost: Int, seedNameArabic: String, economy: EconomyManager): TransactionResult {
        if (unlockedSeeds.contains(seedItemId)) {
            return TransactionResult.Failure("هذا المحصول مفتوح بالفعل!")
        }

        if (!economy.canAfford(cost)) {
            return TransactionResult.Failure("لا يوجد مال كافٍ لفتح بذور $seedNameArabic!")
        }

        val deducted = economy.spendMoney(cost)
        if (!deducted) {
            return TransactionResult.Failure("تعذر إتمام عملية الفتح!")
        }

        unlockedSeeds.add(seedItemId)
        return TransactionResult.Success(
            messageArabic = "تم فتح بذور $seedNameArabic في المتجر بنجاح!",
            amountChanged = cost,
            itemQuantity = 1
        )
    }

    fun setAxeLevelRaw(level: Int) {
        axeLevel = level.coerceIn(1, ToolUpgradeCatalog.getMaxLevel(ToolType.AXE))
    }

    fun setFarmLevelRaw(level: Int) {
        farmExpansionLevel = level.coerceIn(1, FarmExpansionCatalog.getMaxLevel())
    }

    fun loadUnlockedSeeds(seeds: Collection<String>) {
        unlockedSeeds.clear()
        unlockedSeeds.addAll(DEFAULT_SEEDS)
        unlockedSeeds.addAll(seeds)
    }
}
