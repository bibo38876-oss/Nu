package com.example.game.items

enum class ItemCategory(val labelArabic: String) {
    SEEDS("بذور"),
    CROPS("محاصيل"),
    RESOURCES("موارد"),
    TOOLS("أدوات")
}

data class Item(
    val id: String,
    val nameArabic: String,
    val category: ItemCategory,
    val descriptionArabic: String,
    val maxStack: Int = 99,
    val baseBuyPrice: Int = 10,
    val baseSellPrice: Int = 6,
    val iconEmoji: String = ""
)

object ItemCatalog {
    // Stage 1 Items
    val WHEAT_SEEDS = Item(
        id = "wheat_seeds",
        nameArabic = "بذور القمح",
        category = ItemCategory.SEEDS,
        descriptionArabic = "بذور قمح ناصعة تنبت في التربة الخصبة.",
        maxStack = 99,
        baseBuyPrice = 10,
        baseSellPrice = 5,
        iconEmoji = "🌾"
    )

    val GOLDEN_WHEAT = Item(
        id = "golden_wheat",
        nameArabic = "قمح ذهبي",
        category = ItemCategory.CROPS,
        descriptionArabic = "سنابل قمح ناضجة تم حصادها من حقول نوميديا.",
        maxStack = 99,
        baseBuyPrice = 25,
        baseSellPrice = 18,
        iconEmoji = "🌾"
    )

    val WOOD = Item(
        id = "wood",
        nameArabic = "خشب",
        category = ItemCategory.RESOURCES,
        descriptionArabic = "قطع خشب صلبة تم جمعها من أشجار غابة نوميديا.",
        maxStack = 99,
        baseBuyPrice = 4,
        baseSellPrice = 2,
        iconEmoji = "🪵"
    )

    val AXE = Item(
        id = "bronze_axe",
        nameArabic = "الفأس",
        category = ItemCategory.TOOLS,
        descriptionArabic = "فأس متين وحاد لقطع أشجار الغابة واستخراج الأخشاب.",
        maxStack = 1,
        baseBuyPrice = 20,
        baseSellPrice = 10,
        iconEmoji = "🪓"
    )

    val WILD_WOOD = Item(
        id = "wild_wood",
        nameArabic = "خشب بري",
        category = ItemCategory.RESOURCES,
        descriptionArabic = "أخشاب صلبة تم جمعها من أشجار الغابة.",
        maxStack = 99,
        baseBuyPrice = 15,
        baseSellPrice = 8,
        iconEmoji = "🪵"
    )

    val ANCIENT_STONE = Item(
        id = "ancient_stone",
        nameArabic = "حجر قديم",
        category = ItemCategory.RESOURCES,
        descriptionArabic = "أحجار قوية من تلال وأودية نوميديا.",
        maxStack = 99,
        baseBuyPrice = 20,
        baseSellPrice = 10,
        iconEmoji = "🪨"
    )

    val WATER_JUG = Item(
        id = "water_jug",
        nameArabic = "جرة ماء",
        category = ItemCategory.TOOLS,
        descriptionArabic = "جرة فخارية ممتلئة بمياه الواحة العذبة.",
        maxStack = 1,
        baseBuyPrice = 30,
        baseSellPrice = 15,
        iconEmoji = "🏺"
    )

    // Stage 2 Farming Seeds
    val CARROT_SEEDS = Item(
        id = "carrot_seeds",
        nameArabic = "بذور الجزر",
        category = ItemCategory.SEEDS,
        descriptionArabic = "بذور جزر سريعة النمو تنضج في 30 ثانية.",
        maxStack = 99,
        baseBuyPrice = 1,
        baseSellPrice = 1,
        iconEmoji = "🥕"
    )

    val TOMATO_SEEDS = Item(
        id = "tomato_seeds",
        nameArabic = "بذور الطماطم",
        category = ItemCategory.SEEDS,
        descriptionArabic = "بذور طماطم حمراء نضرة تنضج في 60 ثانية.",
        maxStack = 99,
        baseBuyPrice = 2,
        baseSellPrice = 1,
        iconEmoji = "🍅"
    )

    val POTATO_SEEDS = Item(
        id = "potato_seeds",
        nameArabic = "بذور البطاطا",
        category = ItemCategory.SEEDS,
        descriptionArabic = "درنات بطاطا غنية تنضج في 90 ثانية.",
        maxStack = 99,
        baseBuyPrice = 3,
        baseSellPrice = 2,
        iconEmoji = "🥔"
    )

    val ONION_SEEDS = Item(
        id = "onion_seeds",
        nameArabic = "بذور البصل",
        category = ItemCategory.SEEDS,
        descriptionArabic = "بذور بصل أصيل من أرض نوميديا تنضج في 120 ثانية.",
        maxStack = 99,
        baseBuyPrice = 4,
        baseSellPrice = 2,
        iconEmoji = "🧅"
    )

    val PEPPER_SEEDS = Item(
        id = "pepper_seeds",
        nameArabic = "بذور الفلفل",
        category = ItemCategory.SEEDS,
        descriptionArabic = "بذور فلفل حار وفاخر تنضج في 180 ثانية.",
        maxStack = 99,
        baseBuyPrice = 6,
        baseSellPrice = 3,
        iconEmoji = "🌶️"
    )

    val CUCUMBER_SEEDS = Item(
        id = "cucumber_seeds",
        nameArabic = "بذور الخيار",
        category = ItemCategory.SEEDS,
        descriptionArabic = "بذور خيار الواحات المتقدمة، تنضج في 240 ثانية.",
        maxStack = 99,
        baseBuyPrice = 8,
        baseSellPrice = 4,
        iconEmoji = "🥒"
    )

    // Stage 2 & 6 Harvested Crops
    val CARROT = Item(
        id = "carrot",
        nameArabic = "الجزر",
        category = ItemCategory.CROPS,
        descriptionArabic = "جزر برتقالي نضر وحلو المذاق.",
        maxStack = 99,
        baseBuyPrice = 5,
        baseSellPrice = 3,
        iconEmoji = "🥕"
    )

    val TOMATO = Item(
        id = "tomato",
        nameArabic = "الطماطم",
        category = ItemCategory.CROPS,
        descriptionArabic = "طماطم حمراء طازجة غنية بالعصارة.",
        maxStack = 99,
        baseBuyPrice = 10,
        baseSellPrice = 6,
        iconEmoji = "🍅"
    )

    val POTATO = Item(
        id = "potato",
        nameArabic = "البطاطا",
        category = ItemCategory.CROPS,
        descriptionArabic = "حبات بطاطا صلبة ومشبعة.",
        maxStack = 99,
        baseBuyPrice = 16,
        baseSellPrice = 10,
        iconEmoji = "🥔"
    )

    val ONION = Item(
        id = "onion",
        nameArabic = "البصل",
        category = ItemCategory.CROPS,
        descriptionArabic = "بصل ذهبي عطري ممتاز للتجارة والطبخ.",
        maxStack = 99,
        baseBuyPrice = 24,
        baseSellPrice = 15,
        iconEmoji = "🧅"
    )

    val PEPPER = Item(
        id = "pepper",
        nameArabic = "الفلفل",
        category = ItemCategory.CROPS,
        descriptionArabic = "فلفل حار عالي القيمة الزراعية.",
        maxStack = 99,
        baseBuyPrice = 40,
        baseSellPrice = 25,
        iconEmoji = "🌶️"
    )

    val CUCUMBER = Item(
        id = "cucumber",
        nameArabic = "الخيار",
        category = ItemCategory.CROPS,
        descriptionArabic = "خيار طازج ومقرمش عالي الربح والمذاق.",
        maxStack = 99,
        baseBuyPrice = 45,
        baseSellPrice = 28,
        iconEmoji = "🥒"
    )

    private val allItems = listOf(
        WHEAT_SEEDS, GOLDEN_WHEAT, WOOD, AXE, WILD_WOOD, ANCIENT_STONE, WATER_JUG,
        CARROT_SEEDS, TOMATO_SEEDS, POTATO_SEEDS, ONION_SEEDS, PEPPER_SEEDS, CUCUMBER_SEEDS,
        CARROT, TOMATO, POTATO, ONION, PEPPER, CUCUMBER
    )

    fun findById(id: String): Item? = allItems.find { it.id == id }
}

data class ItemStack(
    val item: Item,
    var quantity: Int
)
