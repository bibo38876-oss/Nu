package com.example.game.relationship

import com.example.game.npc.NPCId

class RelationshipManager {

    val relationships: MutableMap<NPCId, RelationshipData> = mutableMapOf()

    init {
        for (id in NPCId.entries) {
            relationships[id] = RelationshipData(npcId = id, affinity = 0)
        }
    }

    fun getData(npcId: NPCId): RelationshipData {
        return relationships.getOrPut(npcId) {
            RelationshipData(npcId = npcId, affinity = 0)
        }
    }

    /**
     * Adds affinity to an NPC up to maximum of 100.
     * Returns true if affinity was modified, and an optional new level if level up occurred.
     */
    fun addAffinity(npcId: NPCId, amount: Int): Pair<Boolean, RelationshipLevel?> {
        val data = getData(npcId)
        val oldLevel = data.level
        val oldAffinity = data.affinity
        val newAffinity = (oldAffinity + amount).coerceIn(0, 100)

        if (newAffinity == oldAffinity) {
            return Pair(false, null)
        }

        data.affinity = newAffinity
        val newLevel = data.level
        val levelUp = if (newLevel.ordinal > oldLevel.ordinal) newLevel else null

        return Pair(true, levelUp)
    }

    /**
     * Grants +1 affinity for talking to an NPC during a new world day (rate-limited to avoid spam).
     */
    fun onDailyTalk(npcId: NPCId, currentDay: Int): Boolean {
        val data = getData(npcId)
        if (data.lastTalkDay != currentDay) {
            data.lastTalkDay = currentDay
            val (changed, _) = addAffinity(npcId, 1)
            return changed
        }
        return false
    }

    /**
     * Called when player turns in a completed quest for this NPC.
     */
    fun onQuestCompleted(npcId: NPCId, affinityBonus: Int): Pair<Boolean, RelationshipLevel?> {
        val data = getData(npcId)
        data.completedQuestsCount++
        return addAffinity(npcId, affinityBonus)
    }

    fun toSerialized(): String {
        return relationships.values.joinToString(";") { data ->
            "${data.npcId.idString},${data.affinity},${data.lastTalkDay},${data.completedQuestsCount}"
        }
    }

    fun loadFromSerialized(raw: String) {
        if (raw.isBlank()) return
        val parts = raw.split(";")
        for (part in parts) {
            val tokens = part.split(",")
            if (tokens.size >= 2) {
                val idStr = tokens[0]
                val aff = tokens[1].toIntOrNull() ?: 0
                val talkDay = tokens.getOrNull(2)?.toIntOrNull() ?: -1
                val quests = tokens.getOrNull(3)?.toIntOrNull() ?: 0

                val npcId = NPCId.entries.find { it.idString == idStr }
                if (npcId != null) {
                    val data = getData(npcId)
                    data.affinity = aff.coerceIn(0, 100)
                    data.lastTalkDay = talkDay
                    data.completedQuestsCount = quests
                }
            }
        }
    }
}
