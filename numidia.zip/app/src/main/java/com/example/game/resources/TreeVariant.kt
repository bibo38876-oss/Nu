package com.example.game.resources

import com.example.game.world.ObjectType

enum class ResourceCategory(val nameArabic: String) {
    TREE("شجر"),
    STONE("حجر"),   // Architecture placeholder for future mining
    IRON("حديد"),    // Architecture placeholder for future mining
    HERB("أعشاب")   // Architecture placeholder for future foraging
}

enum class ResourceNodeState {
    AVAILABLE,
    GATHERING,
    DEPLETED,
    RESPAWNING
}

enum class TreeVariant(
    val nameArabic: String,
    val woodYield: Int,
    val baseChopDurationSec: Float,
    val respawnDurationSec: Int,
    val objectType: ObjectType,
    val visualWidth: Float,
    val visualHeight: Float,
    val collisionWidth: Float,
    val collisionHeight: Float
) {
    SMALL(
        nameArabic = "شجرة سرو برية",
        woodYield = 2,
        baseChopDurationSec = 1.2f,
        respawnDurationSec = 60,
        objectType = ObjectType.TREE_CYPRESS,
        visualWidth = 36f,
        visualHeight = 80f,
        collisionWidth = 20f,
        collisionHeight = 16f
    ),
    MEDIUM(
        nameArabic = "شجرة زيتون غابية",
        woodYield = 4,
        baseChopDurationSec = 1.9f,
        respawnDurationSec = 90,
        objectType = ObjectType.TREE_OLIVE,
        visualWidth = 72f,
        visualHeight = 78f,
        collisionWidth = 30f,
        collisionHeight = 20f
    ),
    LARGE(
        nameArabic = "شجرة أرز نوميدية معمرة",
        woodYield = 7,
        baseChopDurationSec = 2.7f,
        respawnDurationSec = 120,
        objectType = ObjectType.TREE_CEDAR,
        visualWidth = 88f,
        visualHeight = 100f,
        collisionWidth = 36f,
        collisionHeight = 22f
    )
}
