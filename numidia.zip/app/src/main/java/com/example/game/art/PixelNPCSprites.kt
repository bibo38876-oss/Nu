package com.example.game.art

import android.graphics.Bitmap
import com.example.game.npc.NPCId
import com.example.game.state.Direction

object PixelNPCSprites {

    // NPC Sprites Cache: (NPCId to (Direction to animFrame)) -> Bitmap
    val npcSprites = mutableMapOf<Pair<NPCId, Pair<Direction, Int>>, Bitmap>()

    // NPC 28x28 Portraits Cache for Dialogue Box
    val npcPortraits = mutableMapOf<NPCId, Bitmap>()

    // Talk prompt icon (floating over NPC when player is near)
    lateinit var talkPromptIcon: Bitmap
    lateinit var questAvailableIcon: Bitmap
    lateinit var questTurnInIcon: Bitmap

    private var isInitialized = false

    fun initialize() {
        if (isInitialized) return

        generateTalkPromptIcon()
        generateQuestMarkerIcons()

        for (id in NPCId.entries) {
            generateNpcSprites(id)
            npcPortraits[id] = generateNpcPortrait(id)
        }

        isInitialized = true
    }

    private fun createPixelBitmap(width: Int, height: Int, drawer: (Bitmap) -> Unit): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        drawer(bitmap)
        return bitmap
    }

    private fun setPixel(bitmap: Bitmap, x: Int, y: Int, color: Int) {
        if (x in 0 until bitmap.width && y in 0 until bitmap.height) {
            bitmap.setPixel(x, y, color)
        }
    }

    private fun fillRect(bitmap: Bitmap, x1: Int, y1: Int, x2: Int, y2: Int, color: Int) {
        for (y in y1..y2) {
            for (x in x1..x2) {
                setPixel(bitmap, x, y, color)
            }
        }
    }

    // --- 1. FLOATING TALK PROMPT ICON (14x12 speech balloon) ---
    private fun generateTalkPromptIcon() {
        talkPromptIcon = createPixelBitmap(14, 12) { bmp ->
            // Cloud speech balloon
            fillRect(bmp, 2, 1, 11, 7, PixelPalette.WALL_STUCCO_LIGHT)
            fillRect(bmp, 1, 2, 12, 6, PixelPalette.WALL_STUCCO_LIGHT)

            // Outline
            fillRect(bmp, 2, 0, 11, 0, PixelPalette.OUTLINE_DARK)
            fillRect(bmp, 2, 8, 8, 8, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 1, 1, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 12, 1, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 0, 2, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 0, 6, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 13, 2, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 13, 6, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 1, 7, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 12, 7, PixelPalette.OUTLINE_DARK)

            // Tail of balloon
            setPixel(bmp, 4, 9, PixelPalette.WALL_STUCCO_LIGHT)
            setPixel(bmp, 3, 10, PixelPalette.WALL_STUCCO_LIGHT)
            setPixel(bmp, 5, 9, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 4, 10, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 3, 11, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 2, 10, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 3, 9, PixelPalette.OUTLINE_DARK)

            // Three speech dots inside (Gold / Terracotta)
            fillRect(bmp, 3, 3, 4, 4, PixelPalette.VEST_TERRACOTTA)
            fillRect(bmp, 6, 3, 7, 4, PixelPalette.VEST_TERRACOTTA)
            fillRect(bmp, 9, 3, 10, 4, PixelPalette.VEST_TERRACOTTA)
        }
    }

    // --- 1.5 QUEST MARKER ICONS (! and ?) ---
    private fun generateQuestMarkerIcons() {
        // Available Quest Icon: Golden exclamation "!"
        questAvailableIcon = createPixelBitmap(14, 14) { bmp ->
            // Bubble background (Warm Gold / Amber)
            fillRect(bmp, 2, 1, 11, 8, PixelPalette.GOLD_BRIGHT)
            fillRect(bmp, 1, 2, 12, 7, PixelPalette.GOLD_BRIGHT)

            // Outline
            fillRect(bmp, 2, 0, 11, 0, PixelPalette.OUTLINE_DARK)
            fillRect(bmp, 2, 9, 8, 9, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 1, 1, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 12, 1, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 0, 2, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 0, 7, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 13, 2, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 13, 7, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 1, 8, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 12, 8, PixelPalette.OUTLINE_DARK)

            // Tail
            setPixel(bmp, 4, 10, PixelPalette.GOLD_BRIGHT)
            setPixel(bmp, 3, 11, PixelPalette.GOLD_BRIGHT)
            setPixel(bmp, 5, 10, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 4, 11, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 3, 12, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 2, 11, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 3, 10, PixelPalette.OUTLINE_DARK)

            // Exclamation mark "!" (Bold dark brown / terracotta)
            fillRect(bmp, 6, 2, 7, 5, PixelPalette.OUTLINE_DARK)
            fillRect(bmp, 6, 7, 7, 7, PixelPalette.OUTLINE_DARK)
        }

        // Turn-in Ready Quest Icon: Radiant Green/Gold question mark "?"
        questTurnInIcon = createPixelBitmap(14, 14) { bmp ->
            // Bubble background (Bright Mint / Oasis green for completion readiness)
            fillRect(bmp, 2, 1, 11, 8, PixelPalette.OASIS_GREEN_LIGHT)
            fillRect(bmp, 1, 2, 12, 7, PixelPalette.OASIS_GREEN_LIGHT)

            // Outline
            fillRect(bmp, 2, 0, 11, 0, PixelPalette.OUTLINE_DARK)
            fillRect(bmp, 2, 9, 8, 9, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 1, 1, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 12, 1, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 0, 2, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 0, 7, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 13, 2, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 13, 7, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 1, 8, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 12, 8, PixelPalette.OUTLINE_DARK)

            // Tail
            setPixel(bmp, 4, 10, PixelPalette.OASIS_GREEN_LIGHT)
            setPixel(bmp, 3, 11, PixelPalette.OASIS_GREEN_LIGHT)
            setPixel(bmp, 5, 10, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 4, 11, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 3, 12, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 2, 11, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 3, 10, PixelPalette.OUTLINE_DARK)

            // Question mark "?" (Bold dark brown)
            fillRect(bmp, 5, 2, 8, 2, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 8, 3, PixelPalette.OUTLINE_DARK)
            fillRect(bmp, 6, 4, 7, 4, PixelPalette.OUTLINE_DARK)
            setPixel(bmp, 6, 5, PixelPalette.OUTLINE_DARK)
            fillRect(bmp, 6, 7, 7, 7, PixelPalette.OUTLINE_DARK) // Dot
        }
    }

    // --- 2. NPC WORLD SPRITES (16x24 pixels, 4 directions, 3 frames) ---
    private fun generateNpcSprites(npcId: NPCId) {
        for (dir in Direction.entries) {
            for (frame in 0..2) {
                npcSprites[Pair(npcId, Pair(dir, frame))] = createNpcBitmap(npcId, dir, frame)
            }
        }
    }

    private fun createNpcBitmap(npcId: NPCId, dir: Direction, frame: Int): Bitmap {
        val w = 16
        val h = 24
        return createPixelBitmap(w, h) { bmp ->
            val bobY = if (frame != 0) -1 else 0

            when (npcId) {
                NPCId.YASSIN -> drawYassinSprite(bmp, dir, frame, bobY)
                NPCId.SAMIRA -> drawSamiraSprite(bmp, dir, frame, bobY)
                NPCId.MAZEN -> drawMazenSprite(bmp, dir, frame, bobY)
                NPCId.AMIN -> drawAminSprite(bmp, dir, frame, bobY)
            }
        }
    }

    // YASSIN: Seed Merchant (White & Gold Turban, Oasis Green Robe, Cream Tunic, Beard)
    private fun drawYassinSprite(bmp: Bitmap, dir: Direction, frame: Int, bobY: Int) {
        when (dir) {
            Direction.DOWN -> {
                // Turban
                fillRect(bmp, 4, 1 + bobY, 11, 4 + bobY, PixelPalette.TUNIC_CREAM)
                fillRect(bmp, 3, 2 + bobY, 12, 3 + bobY, PixelPalette.TUNIC_CREAM)
                fillRect(bmp, 6, 1 + bobY, 9, 2 + bobY, PixelPalette.GOLD_BRIGHT) // Golden turban brooch
                // Face & Beard
                fillRect(bmp, 4, 5 + bobY, 11, 8 + bobY, PixelPalette.SKIN_LIGHT)
                setPixel(bmp, 5, 6 + bobY, PixelPalette.HAIR_DARK) // Left eye
                setPixel(bmp, 10, 6 + bobY, PixelPalette.HAIR_DARK) // Right eye
                fillRect(bmp, 5, 8 + bobY, 10, 9 + bobY, PixelPalette.HAIR_DARK) // Beard

                // Oasis Green Merchant Robe
                fillRect(bmp, 4, 10 + bobY, 11, 16 + bobY, PixelPalette.OASIS_GREEN)
                fillRect(bmp, 6, 10 + bobY, 9, 15 + bobY, PixelPalette.TUNIC_CREAM) // Inner tunic
                fillRect(bmp, 5, 14 + bobY, 10, 14 + bobY, PixelPalette.GOLD_BRIGHT) // Gold belt

                // Arms (Sleeves)
                fillRect(bmp, 2, 10 + bobY, 3, 13 + bobY, PixelPalette.OASIS_GREEN)
                fillRect(bmp, 12, 10 + bobY, 13, 13 + bobY, PixelPalette.OASIS_GREEN)
                setPixel(bmp, 3, 14 + bobY, PixelPalette.SKIN_MID)
                setPixel(bmp, 12, 14 + bobY, PixelPalette.SKIN_MID)

                // Legs / Leather Shoes
                drawLegs(bmp, frame, PixelPalette.OASIS_GREEN_DARK, PixelPalette.BOOTS_LEATHER)
            }

            Direction.UP -> {
                // Turban back
                fillRect(bmp, 4, 1 + bobY, 11, 5 + bobY, PixelPalette.TUNIC_CREAM)
                fillRect(bmp, 5, 5 + bobY, 10, 7 + bobY, PixelPalette.HAIR_DARK) // Dark hair nape

                // Robe back
                fillRect(bmp, 4, 8 + bobY, 11, 16 + bobY, PixelPalette.OASIS_GREEN)
                fillRect(bmp, 2, 9 + bobY, 3, 13 + bobY, PixelPalette.OASIS_GREEN)
                fillRect(bmp, 12, 9 + bobY, 13, 13 + bobY, PixelPalette.OASIS_GREEN)

                drawLegs(bmp, frame, PixelPalette.OASIS_GREEN_DARK, PixelPalette.BOOTS_LEATHER)
            }

            Direction.LEFT -> {
                // Turban side
                fillRect(bmp, 4, 1 + bobY, 10, 4 + bobY, PixelPalette.TUNIC_CREAM)
                setPixel(bmp, 4, 2 + bobY, PixelPalette.GOLD_BRIGHT)
                fillRect(bmp, 4, 5 + bobY, 9, 7 + bobY, PixelPalette.SKIN_LIGHT)
                setPixel(bmp, 5, 6 + bobY, PixelPalette.HAIR_DARK) // Eye
                fillRect(bmp, 4, 8 + bobY, 7, 9 + bobY, PixelPalette.HAIR_DARK) // Beard profile

                // Robe side
                fillRect(bmp, 5, 10 + bobY, 10, 16 + bobY, PixelPalette.OASIS_GREEN)
                fillRect(bmp, 6, 10 + bobY, 8, 14 + bobY, PixelPalette.OASIS_GREEN_LIGHT)
                setPixel(bmp, 5, 14 + bobY, PixelPalette.GOLD_BRIGHT)

                // Side arm
                fillRect(bmp, 6, 11 + bobY, 7, 14 + bobY, PixelPalette.OASIS_GREEN)
                setPixel(bmp, 6, 15 + bobY, PixelPalette.SKIN_MID)

                drawSideLegs(bmp, frame, PixelPalette.OASIS_GREEN_DARK, PixelPalette.BOOTS_LEATHER)
            }

            Direction.RIGHT -> {
                // Turban side
                fillRect(bmp, 5, 1 + bobY, 11, 4 + bobY, PixelPalette.TUNIC_CREAM)
                setPixel(bmp, 11, 2 + bobY, PixelPalette.GOLD_BRIGHT)
                fillRect(bmp, 6, 5 + bobY, 11, 7 + bobY, PixelPalette.SKIN_LIGHT)
                setPixel(bmp, 10, 6 + bobY, PixelPalette.HAIR_DARK) // Eye
                fillRect(bmp, 8, 8 + bobY, 11, 9 + bobY, PixelPalette.HAIR_DARK) // Beard profile

                // Robe side
                fillRect(bmp, 5, 10 + bobY, 10, 16 + bobY, PixelPalette.OASIS_GREEN)
                fillRect(bmp, 7, 10 + bobY, 9, 14 + bobY, PixelPalette.OASIS_GREEN_LIGHT)
                setPixel(bmp, 10, 14 + bobY, PixelPalette.GOLD_BRIGHT)

                // Side arm
                fillRect(bmp, 8, 11 + bobY, 9, 14 + bobY, PixelPalette.OASIS_GREEN)
                setPixel(bmp, 9, 15 + bobY, PixelPalette.SKIN_MID)

                drawSideLegs(bmp, frame, PixelPalette.OASIS_GREEN_DARK, PixelPalette.BOOTS_LEATHER)
            }
        }
    }

    // SAMIRA: Market Trader (Indigo / Terracotta Dress, Gold Headband & Earrings, Long Dark Braid)
    private fun drawSamiraSprite(bmp: Bitmap, dir: Direction, frame: Int, bobY: Int) {
        when (dir) {
            Direction.DOWN -> {
                // Hair and Gold Headband
                fillRect(bmp, 4, 2 + bobY, 11, 4 + bobY, PixelPalette.HAIR_DARK)
                fillRect(bmp, 4, 3 + bobY, 11, 3 + bobY, PixelPalette.GOLD_BRIGHT) // Gold band
                fillRect(bmp, 4, 5 + bobY, 11, 8 + bobY, PixelPalette.SKIN_LIGHT)
                // Eyes & Lips
                setPixel(bmp, 5, 6 + bobY, PixelPalette.HAIR_DARK)
                setPixel(bmp, 10, 6 + bobY, PixelPalette.HAIR_DARK)
                setPixel(bmp, 7, 8 + bobY, PixelPalette.CANOPY_RED) // Lips
                // Gold Earrings
                setPixel(bmp, 3, 6 + bobY, PixelPalette.GOLD_BRIGHT)
                setPixel(bmp, 12, 6 + bobY, PixelPalette.GOLD_BRIGHT)
                // Hair flowing down shoulders
                fillRect(bmp, 3, 4 + bobY, 4, 9 + bobY, PixelPalette.HAIR_DARK)
                fillRect(bmp, 11, 4 + bobY, 12, 9 + bobY, PixelPalette.HAIR_DARK)

                // Indigo dress with Terracotta bodice
                fillRect(bmp, 4, 9 + bobY, 11, 16 + bobY, PixelPalette.SASH_BLUE)
                fillRect(bmp, 5, 9 + bobY, 10, 12 + bobY, PixelPalette.VEST_TERRACOTTA)
                fillRect(bmp, 4, 13 + bobY, 11, 13 + bobY, PixelPalette.GOLD_BRIGHT) // Gold sash

                // Arms
                fillRect(bmp, 2, 9 + bobY, 3, 13 + bobY, PixelPalette.SKIN_LIGHT)
                fillRect(bmp, 12, 9 + bobY, 13, 13 + bobY, PixelPalette.SKIN_LIGHT)
                setPixel(bmp, 2, 11 + bobY, PixelPalette.GOLD_BRIGHT) // Gold bracelet

                drawSkirtLegs(bmp, frame, PixelPalette.SASH_BLUE, PixelPalette.BOOTS_LEATHER)
            }

            Direction.UP -> {
                // Hair & Braided ponytail down back
                fillRect(bmp, 4, 2 + bobY, 11, 5 + bobY, PixelPalette.HAIR_DARK)
                fillRect(bmp, 7, 6 + bobY, 8, 12 + bobY, PixelPalette.HAIR_DARK) // Long braid
                setPixel(bmp, 7, 10 + bobY, PixelPalette.CANOPY_RED) // Red ribbon in braid

                // Dress back
                fillRect(bmp, 4, 8 + bobY, 11, 16 + bobY, PixelPalette.SASH_BLUE)
                fillRect(bmp, 4, 13 + bobY, 11, 13 + bobY, PixelPalette.GOLD_BRIGHT)

                drawSkirtLegs(bmp, frame, PixelPalette.SASH_BLUE, PixelPalette.BOOTS_LEATHER)
            }

            Direction.LEFT -> {
                // Side hair & profile
                fillRect(bmp, 5, 2 + bobY, 10, 4 + bobY, PixelPalette.HAIR_DARK)
                setPixel(bmp, 6, 3 + bobY, PixelPalette.GOLD_BRIGHT)
                fillRect(bmp, 4, 5 + bobY, 9, 8 + bobY, PixelPalette.SKIN_LIGHT)
                setPixel(bmp, 5, 6 + bobY, PixelPalette.HAIR_DARK)
                setPixel(bmp, 8, 6 + bobY, PixelPalette.GOLD_BRIGHT) // Earring
                fillRect(bmp, 8, 5 + bobY, 10, 11 + bobY, PixelPalette.HAIR_DARK) // Hair flowing back

                // Dress side
                fillRect(bmp, 5, 9 + bobY, 10, 16 + bobY, PixelPalette.SASH_BLUE)
                fillRect(bmp, 5, 9 + bobY, 7, 12 + bobY, PixelPalette.VEST_TERRACOTTA)
                setPixel(bmp, 5, 13 + bobY, PixelPalette.GOLD_BRIGHT)

                // Arm
                fillRect(bmp, 6, 10 + bobY, 7, 14 + bobY, PixelPalette.SKIN_LIGHT)

                drawSideLegs(bmp, frame, PixelPalette.SASH_BLUE, PixelPalette.BOOTS_LEATHER)
            }

            Direction.RIGHT -> {
                // Side hair & profile
                fillRect(bmp, 5, 2 + bobY, 10, 4 + bobY, PixelPalette.HAIR_DARK)
                setPixel(bmp, 9, 3 + bobY, PixelPalette.GOLD_BRIGHT)
                fillRect(bmp, 6, 5 + bobY, 11, 8 + bobY, PixelPalette.SKIN_LIGHT)
                setPixel(bmp, 10, 6 + bobY, PixelPalette.HAIR_DARK)
                setPixel(bmp, 7, 6 + bobY, PixelPalette.GOLD_BRIGHT) // Earring
                fillRect(bmp, 5, 5 + bobY, 7, 11 + bobY, PixelPalette.HAIR_DARK) // Hair flowing back

                // Dress side
                fillRect(bmp, 5, 9 + bobY, 10, 16 + bobY, PixelPalette.SASH_BLUE)
                fillRect(bmp, 8, 9 + bobY, 10, 12 + bobY, PixelPalette.VEST_TERRACOTTA)
                setPixel(bmp, 10, 13 + bobY, PixelPalette.GOLD_BRIGHT)

                // Arm
                fillRect(bmp, 8, 10 + bobY, 9, 14 + bobY, PixelPalette.SKIN_LIGHT)

                drawSideLegs(bmp, frame, PixelPalette.SASH_BLUE, PixelPalette.BOOTS_LEATHER)
            }
        }
    }

    // MAZEN: Village Farmer (Wide Straw Hat, Beige Linen Vest, Rolled Sleeves, Earthy Pants)
    private fun drawMazenSprite(bmp: Bitmap, dir: Direction, frame: Int, bobY: Int) {
        val strawLight = PixelPalette.DIRT_LIGHT
        val strawDark = PixelPalette.DIRT_DARK

        when (dir) {
            Direction.DOWN -> {
                // Wide Straw Hat Brim
                fillRect(bmp, 3, 2 + bobY, 12, 3 + bobY, strawLight)
                fillRect(bmp, 2, 4 + bobY, 13, 4 + bobY, strawDark)
                fillRect(bmp, 5, 0 + bobY, 10, 2 + bobY, strawLight) // Hat crown

                // Sun-kissed Face
                fillRect(bmp, 4, 5 + bobY, 11, 8 + bobY, PixelPalette.SKIN_LIGHT)
                setPixel(bmp, 5, 6 + bobY, PixelPalette.HAIR_DARK)
                setPixel(bmp, 10, 6 + bobY, PixelPalette.HAIR_DARK)
                fillRect(bmp, 7, 8 + bobY, 8, 8 + bobY, PixelPalette.SKIN_MID) // Cheerful mouth

                // Beige Farmer Tunic & Brown Vest
                fillRect(bmp, 4, 9 + bobY, 11, 15 + bobY, PixelPalette.WALL_STUCCO_MID)
                fillRect(bmp, 4, 9 + bobY, 5, 14 + bobY, PixelPalette.FARM_SOIL_LIGHT)
                fillRect(bmp, 10, 9 + bobY, 11, 14 + bobY, PixelPalette.FARM_SOIL_LIGHT)
                fillRect(bmp, 4, 15 + bobY, 11, 15 + bobY, PixelPalette.WOOD_BEAM_DARK) // Rope belt

                // Rolled-up Sleeves (Skin showing on lower arms)
                fillRect(bmp, 2, 9 + bobY, 3, 11 + bobY, PixelPalette.WALL_STUCCO_MID)
                fillRect(bmp, 2, 12 + bobY, 3, 14 + bobY, PixelPalette.SKIN_LIGHT)
                fillRect(bmp, 12, 9 + bobY, 13, 11 + bobY, PixelPalette.WALL_STUCCO_MID)
                fillRect(bmp, 12, 12 + bobY, 13, 14 + bobY, PixelPalette.SKIN_LIGHT)

                drawLegs(bmp, frame, PixelPalette.DIRT_MID, PixelPalette.BOOTS_LEATHER)
            }

            Direction.UP -> {
                // Wide Straw Hat Crown & Brim back
                fillRect(bmp, 5, 0 + bobY, 10, 2 + bobY, strawLight)
                fillRect(bmp, 2, 3 + bobY, 13, 4 + bobY, strawLight)
                fillRect(bmp, 5, 5 + bobY, 10, 7 + bobY, PixelPalette.HAIR_DARK)

                // Vest back
                fillRect(bmp, 4, 8 + bobY, 11, 15 + bobY, PixelPalette.FARM_SOIL_LIGHT)
                fillRect(bmp, 2, 9 + bobY, 3, 11 + bobY, PixelPalette.WALL_STUCCO_MID)
                fillRect(bmp, 12, 9 + bobY, 13, 11 + bobY, PixelPalette.WALL_STUCCO_MID)

                drawLegs(bmp, frame, PixelPalette.DIRT_MID, PixelPalette.BOOTS_LEATHER)
            }

            Direction.LEFT -> {
                // Straw Hat side profile
                fillRect(bmp, 4, 0 + bobY, 9, 2 + bobY, strawLight)
                fillRect(bmp, 2, 3 + bobY, 12, 4 + bobY, strawLight)
                fillRect(bmp, 4, 5 + bobY, 9, 8 + bobY, PixelPalette.SKIN_LIGHT)
                setPixel(bmp, 5, 6 + bobY, PixelPalette.HAIR_DARK)

                // Tunic & Vest side
                fillRect(bmp, 5, 9 + bobY, 10, 15 + bobY, PixelPalette.WALL_STUCCO_MID)
                fillRect(bmp, 7, 9 + bobY, 9, 14 + bobY, PixelPalette.FARM_SOIL_LIGHT)
                fillRect(bmp, 6, 10 + bobY, 7, 12 + bobY, PixelPalette.WALL_STUCCO_MID)
                fillRect(bmp, 6, 13 + bobY, 7, 14 + bobY, PixelPalette.SKIN_LIGHT)

                drawSideLegs(bmp, frame, PixelPalette.DIRT_MID, PixelPalette.BOOTS_LEATHER)
            }

            Direction.RIGHT -> {
                // Straw Hat side profile
                fillRect(bmp, 6, 0 + bobY, 11, 2 + bobY, strawLight)
                fillRect(bmp, 3, 3 + bobY, 13, 4 + bobY, strawLight)
                fillRect(bmp, 6, 5 + bobY, 11, 8 + bobY, PixelPalette.SKIN_LIGHT)
                setPixel(bmp, 10, 6 + bobY, PixelPalette.HAIR_DARK)

                // Tunic & Vest side
                fillRect(bmp, 5, 9 + bobY, 10, 15 + bobY, PixelPalette.WALL_STUCCO_MID)
                fillRect(bmp, 6, 9 + bobY, 8, 14 + bobY, PixelPalette.FARM_SOIL_LIGHT)
                fillRect(bmp, 8, 10 + bobY, 9, 12 + bobY, PixelPalette.WALL_STUCCO_MID)
                fillRect(bmp, 8, 13 + bobY, 9, 14 + bobY, PixelPalette.SKIN_LIGHT)

                drawSideLegs(bmp, frame, PixelPalette.DIRT_MID, PixelPalette.BOOTS_LEATHER)
            }
        }
    }

    // AMIN: Workshop Artisan (Dark Headband, Leather Apron, Strong Build, Bronze Bracelet)
    private fun drawAminSprite(bmp: Bitmap, dir: Direction, frame: Int, bobY: Int) {
        val leatherApron = PixelPalette.TRUNK_DARK
        val apronLight = PixelPalette.WOOD_BEAM_MID

        when (dir) {
            Direction.DOWN -> {
                // Hair & Artisan Headband
                fillRect(bmp, 4, 2 + bobY, 11, 4 + bobY, PixelPalette.HAIR_DARK)
                fillRect(bmp, 4, 3 + bobY, 11, 3 + bobY, PixelPalette.ROOF_TILE_LIGHT) // Terracotta worker headband
                fillRect(bmp, 4, 5 + bobY, 11, 8 + bobY, PixelPalette.SKIN_LIGHT)
                setPixel(bmp, 5, 6 + bobY, PixelPalette.HAIR_DARK)
                setPixel(bmp, 10, 6 + bobY, PixelPalette.HAIR_DARK)
                fillRect(bmp, 6, 8 + bobY, 9, 8 + bobY, PixelPalette.SKIN_MID) // Firm jawline

                // Leather Smith Apron over linen shirt
                fillRect(bmp, 4, 9 + bobY, 11, 15 + bobY, apronLight)
                fillRect(bmp, 5, 9 + bobY, 10, 16 + bobY, leatherApron) // Full apron center
                fillRect(bmp, 6, 9 + bobY, 6, 12 + bobY, PixelPalette.GOLD_SHADOW) // Brass apron strap
                fillRect(bmp, 9, 9 + bobY, 9, 12 + bobY, PixelPalette.GOLD_SHADOW)
                fillRect(bmp, 4, 13 + bobY, 11, 13 + bobY, PixelPalette.OUTLINE_DARK) // Tool belt

                // Muscular Arms with bronze wrist guard
                fillRect(bmp, 2, 9 + bobY, 3, 13 + bobY, PixelPalette.SKIN_MID)
                setPixel(bmp, 2, 12 + bobY, PixelPalette.GOLD_SHADOW) // Bronze wrist cuff
                fillRect(bmp, 12, 9 + bobY, 13, 13 + bobY, PixelPalette.SKIN_MID)
                setPixel(bmp, 13, 12 + bobY, PixelPalette.GOLD_SHADOW)

                drawLegs(bmp, frame, PixelPalette.TUNIC_SHADOW, PixelPalette.BOOTS_LEATHER)
            }

            Direction.UP -> {
                fillRect(bmp, 4, 2 + bobY, 11, 6 + bobY, PixelPalette.HAIR_DARK)
                setPixel(bmp, 7, 6 + bobY, PixelPalette.ROOF_TILE_LIGHT) // Headband knot

                fillRect(bmp, 4, 8 + bobY, 11, 15 + bobY, apronLight)
                fillRect(bmp, 5, 9 + bobY, 10, 11 + bobY, leatherApron) // Apron straps crossing

                drawLegs(bmp, frame, PixelPalette.TUNIC_SHADOW, PixelPalette.BOOTS_LEATHER)
            }

            Direction.LEFT -> {
                fillRect(bmp, 4, 2 + bobY, 10, 4 + bobY, PixelPalette.HAIR_DARK)
                setPixel(bmp, 5, 3 + bobY, PixelPalette.ROOF_TILE_LIGHT)
                fillRect(bmp, 4, 5 + bobY, 9, 8 + bobY, PixelPalette.SKIN_LIGHT)
                setPixel(bmp, 5, 6 + bobY, PixelPalette.HAIR_DARK)

                fillRect(bmp, 5, 9 + bobY, 10, 15 + bobY, apronLight)
                fillRect(bmp, 5, 10 + bobY, 8, 15 + bobY, leatherApron)
                setPixel(bmp, 5, 13 + bobY, PixelPalette.OUTLINE_DARK)

                fillRect(bmp, 6, 10 + bobY, 7, 13 + bobY, PixelPalette.SKIN_MID)
                setPixel(bmp, 6, 12 + bobY, PixelPalette.GOLD_SHADOW)

                drawSideLegs(bmp, frame, PixelPalette.TUNIC_SHADOW, PixelPalette.BOOTS_LEATHER)
            }

            Direction.RIGHT -> {
                fillRect(bmp, 5, 2 + bobY, 11, 4 + bobY, PixelPalette.HAIR_DARK)
                setPixel(bmp, 10, 3 + bobY, PixelPalette.ROOF_TILE_LIGHT)
                fillRect(bmp, 6, 5 + bobY, 11, 8 + bobY, PixelPalette.SKIN_LIGHT)
                setPixel(bmp, 10, 6 + bobY, PixelPalette.HAIR_DARK)

                fillRect(bmp, 5, 9 + bobY, 10, 15 + bobY, apronLight)
                fillRect(bmp, 7, 10 + bobY, 10, 15 + bobY, leatherApron)
                setPixel(bmp, 10, 13 + bobY, PixelPalette.OUTLINE_DARK)

                fillRect(bmp, 8, 10 + bobY, 9, 13 + bobY, PixelPalette.SKIN_MID)
                setPixel(bmp, 9, 12 + bobY, PixelPalette.GOLD_SHADOW)

                drawSideLegs(bmp, frame, PixelPalette.TUNIC_SHADOW, PixelPalette.BOOTS_LEATHER)
            }
        }
    }

    // Helper: Standard pants & boots walk cycle
    private fun drawLegs(bmp: Bitmap, frame: Int, pantsColor: Int, bootsColor: Int) {
        when (frame) {
            0 -> { // Idle
                fillRect(bmp, 5, 16, 6, 21, pantsColor)
                fillRect(bmp, 9, 16, 10, 21, pantsColor)
                fillRect(bmp, 5, 20, 6, 22, bootsColor)
                fillRect(bmp, 9, 20, 10, 22, bootsColor)
            }
            1 -> { // Left step forward
                fillRect(bmp, 4, 16, 6, 20, pantsColor)
                fillRect(bmp, 4, 20, 6, 22, bootsColor)
                fillRect(bmp, 9, 16, 10, 19, pantsColor)
                fillRect(bmp, 9, 19, 10, 21, bootsColor)
            }
            2 -> { // Right step forward
                fillRect(bmp, 5, 16, 6, 19, pantsColor)
                fillRect(bmp, 5, 19, 6, 21, bootsColor)
                fillRect(bmp, 9, 16, 11, 20, pantsColor)
                fillRect(bmp, 9, 20, 11, 22, bootsColor)
            }
        }
    }

    private fun drawSideLegs(bmp: Bitmap, frame: Int, pantsColor: Int, bootsColor: Int) {
        when (frame) {
            0 -> {
                fillRect(bmp, 6, 16, 9, 21, pantsColor)
                fillRect(bmp, 6, 20, 9, 22, bootsColor)
            }
            1 -> {
                fillRect(bmp, 5, 16, 8, 20, pantsColor)
                fillRect(bmp, 5, 20, 8, 22, bootsColor)
                fillRect(bmp, 8, 16, 10, 19, pantsColor)
                fillRect(bmp, 8, 19, 10, 21, bootsColor)
            }
            2 -> {
                fillRect(bmp, 7, 16, 10, 20, pantsColor)
                fillRect(bmp, 7, 20, 10, 22, bootsColor)
                fillRect(bmp, 5, 16, 7, 19, pantsColor)
                fillRect(bmp, 5, 19, 7, 21, bootsColor)
            }
        }
    }

    private fun drawSkirtLegs(bmp: Bitmap, frame: Int, skirtColor: Int, bootsColor: Int) {
        fillRect(bmp, 4, 16, 11, 19, skirtColor)
        when (frame) {
            0 -> {
                fillRect(bmp, 5, 20, 6, 22, bootsColor)
                fillRect(bmp, 9, 20, 10, 22, bootsColor)
            }
            1 -> {
                fillRect(bmp, 4, 19, 6, 22, bootsColor)
                fillRect(bmp, 9, 20, 10, 22, bootsColor)
            }
            2 -> {
                fillRect(bmp, 5, 20, 6, 22, bootsColor)
                fillRect(bmp, 9, 19, 11, 22, bootsColor)
            }
        }
    }

    // --- 3. DETAILED 28x28 NPC PORTRAITS FOR DIALOGUE ---
    private fun generateNpcPortrait(npcId: NPCId): Bitmap {
        val size = 28
        return createPixelBitmap(size, size) { bmp ->
            // Antique border fill background
            fillRect(bmp, 0, 0, 27, 27, PixelPalette.OUTLINE_DARK)
            fillRect(bmp, 1, 1, 26, 26, PixelPalette.WALL_STUCCO_DARK)
            fillRect(bmp, 2, 2, 25, 25, 0xFF231710.toInt()) // Deep background

            when (npcId) {
                NPCId.YASSIN -> {
                    // Turban with folds & Golden Brooch
                    fillRect(bmp, 6, 4, 21, 9, PixelPalette.TUNIC_CREAM)
                    fillRect(bmp, 8, 3, 19, 5, PixelPalette.TUNIC_SHADOW)
                    fillRect(bmp, 12, 4, 15, 6, PixelPalette.GOLD_BRIGHT) // Center brooch
                    setPixel(bmp, 13, 5, PixelPalette.BERRY_RED) // Ruby center

                    // Face & Eyes
                    fillRect(bmp, 8, 10, 19, 17, PixelPalette.SKIN_LIGHT)
                    fillRect(bmp, 9, 12, 11, 13, PixelPalette.HAIR_DARK) // Left eye
                    fillRect(bmp, 16, 12, 18, 13, PixelPalette.HAIR_DARK) // Right eye
                    setPixel(bmp, 10, 12, PixelPalette.WINDOW_LIGHT) // Catchlight
                    setPixel(bmp, 17, 12, PixelPalette.WINDOW_LIGHT)

                    // Nose & Friendly Beard
                    setPixel(bmp, 13, 14, PixelPalette.SKIN_MID)
                    fillRect(bmp, 9, 16, 18, 20, PixelPalette.HAIR_DARK) // Full groomed beard
                    fillRect(bmp, 11, 16, 16, 17, PixelPalette.HAIR_DARK) // Mustache

                    // Oasis Green Merchant Robe Collar
                    fillRect(bmp, 5, 21, 22, 25, PixelPalette.OASIS_GREEN)
                    fillRect(bmp, 11, 21, 16, 25, PixelPalette.TUNIC_CREAM)
                    fillRect(bmp, 10, 21, 10, 25, PixelPalette.GOLD_BRIGHT)
                    fillRect(bmp, 17, 21, 17, 25, PixelPalette.GOLD_BRIGHT)
                }

                NPCId.SAMIRA -> {
                    // Dark styled hair with Gold Headband
                    fillRect(bmp, 6, 4, 21, 8, PixelPalette.HAIR_DARK)
                    fillRect(bmp, 6, 7, 21, 8, PixelPalette.GOLD_BRIGHT) // Gold band
                    setPixel(bmp, 13, 7, PixelPalette.ROOF_TILE_LIGHT)

                    // Face & Catchlight Eyes
                    fillRect(bmp, 8, 9, 19, 17, PixelPalette.SKIN_LIGHT)
                    fillRect(bmp, 9, 11, 11, 12, PixelPalette.HAIR_DARK)
                    fillRect(bmp, 16, 11, 18, 12, PixelPalette.HAIR_DARK)
                    setPixel(bmp, 10, 11, PixelPalette.WINDOW_LIGHT)
                    setPixel(bmp, 17, 11, PixelPalette.WINDOW_LIGHT)

                    // Eyelashes & Brows
                    fillRect(bmp, 8, 10, 11, 10, PixelPalette.HAIR_DARK)
                    fillRect(bmp, 16, 10, 19, 10, PixelPalette.HAIR_DARK)

                    // Rosy Lips & Cheek
                    fillRect(bmp, 12, 15, 15, 16, PixelPalette.CANOPY_RED)

                    // Gold Hoop Earrings
                    fillRect(bmp, 5, 11, 6, 14, PixelPalette.GOLD_BRIGHT)
                    fillRect(bmp, 21, 11, 22, 14, PixelPalette.GOLD_BRIGHT)

                    // Braided hair down sides
                    fillRect(bmp, 5, 8, 7, 18, PixelPalette.HAIR_DARK)
                    fillRect(bmp, 20, 8, 22, 18, PixelPalette.HAIR_DARK)

                    // Indigo Dress with Terracotta Embroidered Trim
                    fillRect(bmp, 5, 20, 22, 25, PixelPalette.SASH_BLUE)
                    fillRect(bmp, 9, 20, 18, 25, PixelPalette.VEST_TERRACOTTA)
                    fillRect(bmp, 8, 20, 8, 25, PixelPalette.GOLD_BRIGHT)
                    fillRect(bmp, 19, 20, 19, 25, PixelPalette.GOLD_BRIGHT)
                }

                NPCId.MAZEN -> {
                    // Wide Straw Hat
                    fillRect(bmp, 4, 3, 23, 7, PixelPalette.DIRT_LIGHT)
                    fillRect(bmp, 8, 2, 19, 4, PixelPalette.DIRT_MID) // Crown
                    fillRect(bmp, 3, 7, 24, 8, PixelPalette.DIRT_DARK) // Brim shadow

                    // Tanned Face
                    fillRect(bmp, 8, 9, 19, 17, PixelPalette.SKIN_LIGHT)
                    fillRect(bmp, 9, 11, 11, 12, PixelPalette.HAIR_DARK)
                    fillRect(bmp, 16, 11, 18, 12, PixelPalette.HAIR_DARK)
                    setPixel(bmp, 10, 11, PixelPalette.WINDOW_LIGHT)
                    setPixel(bmp, 17, 11, PixelPalette.WINDOW_LIGHT)

                    // Cheerful Sun Smile
                    fillRect(bmp, 12, 15, 15, 16, PixelPalette.SKIN_MID)
                    setPixel(bmp, 11, 15, PixelPalette.HAIR_DARK)
                    setPixel(bmp, 16, 15, PixelPalette.HAIR_DARK)

                    // Stubble / Light jaw
                    setPixel(bmp, 10, 17, PixelPalette.DIRT_DARK)
                    setPixel(bmp, 17, 17, PixelPalette.DIRT_DARK)

                    // Farmer Linen Collar & Brown Vest
                    fillRect(bmp, 5, 20, 22, 25, PixelPalette.WALL_STUCCO_MID)
                    fillRect(bmp, 5, 20, 8, 25, PixelPalette.FARM_SOIL_LIGHT)
                    fillRect(bmp, 19, 20, 22, 25, PixelPalette.FARM_SOIL_LIGHT)
                }

                NPCId.AMIN -> {
                    // Tied Back Dark Hair & Red Bandana
                    fillRect(bmp, 6, 4, 21, 7, PixelPalette.HAIR_DARK)
                    fillRect(bmp, 6, 7, 21, 8, PixelPalette.ROOF_TILE_LIGHT) // Bandana
                    fillRect(bmp, 5, 9, 7, 14, PixelPalette.HAIR_DARK) // Sideburns
                    fillRect(bmp, 20, 9, 22, 14, PixelPalette.HAIR_DARK)

                    // Strong Jaw & Focused Eyes
                    fillRect(bmp, 8, 9, 19, 18, PixelPalette.SKIN_LIGHT)
                    fillRect(bmp, 9, 11, 11, 12, PixelPalette.HAIR_DARK)
                    fillRect(bmp, 16, 11, 18, 12, PixelPalette.HAIR_DARK)
                    setPixel(bmp, 10, 11, PixelPalette.WINDOW_LIGHT)
                    setPixel(bmp, 17, 11, PixelPalette.WINDOW_LIGHT)

                    // Subtle soot mark from the forge
                    setPixel(bmp, 8, 13, 0x88341F12.toInt())
                    setPixel(bmp, 9, 14, 0x66341F12.toInt())

                    // Firm Mouth
                    fillRect(bmp, 12, 16, 15, 16, PixelPalette.SKIN_MID)

                    // Smith Leather Apron & Brass Rivets
                    fillRect(bmp, 5, 20, 22, 25, PixelPalette.TRUNK_DARK)
                    fillRect(bmp, 9, 20, 10, 25, PixelPalette.GOLD_SHADOW) // Apron strap
                    fillRect(bmp, 17, 20, 18, 25, PixelPalette.GOLD_SHADOW)
                    fillRect(bmp, 11, 20, 16, 25, PixelPalette.WOOD_BEAM_MID)
                }
            }
        }
    }
}
