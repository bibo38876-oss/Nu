package com.example.game.economy

import com.example.game.items.Item
import com.example.game.items.ItemCategory
import com.example.game.items.ItemCatalog

object PriceCatalog {

    // Configurable Seed Purchase Prices (in 'مال')
    private val seedBuyPrices = mutableMapOf(
        ItemCatalog.CARROT_SEEDS.id to 1,
        ItemCatalog.TOMATO_SEEDS.id to 2,
        ItemCatalog.POTATO_SEEDS.id to 3,
        ItemCatalog.ONION_SEEDS.id to 4,
        ItemCatalog.PEPPER_SEEDS.id to 6,
        ItemCatalog.CUCUMBER_SEEDS.id to 8,  // Stage 6 advanced crop (240s)
        ItemCatalog.WHEAT_SEEDS.id to 2
    )

    // Configurable Crop Selling Prices (in 'مال')
    // Progression: short growth -> lower return; longer growth -> higher return
    private val cropSellPrices = mutableMapOf(
        ItemCatalog.CARROT.id to 3,       // 30s growth -> 1 buy -> 3 sell (+2 profit)
        ItemCatalog.TOMATO.id to 6,       // 60s growth -> 2 buy -> 6 sell (+4 profit)
        ItemCatalog.POTATO.id to 9,       // 90s growth -> 3 buy -> 9 sell (+6 profit)
        ItemCatalog.ONION.id to 13,       // 120s growth -> 4 buy -> 13 sell (+9 profit)
        ItemCatalog.PEPPER.id to 20,      // 180s growth -> 6 buy -> 20 sell (+14 profit)
        ItemCatalog.CUCUMBER.id to 28,    // 240s growth -> 8 buy -> 28 sell (+20 profit)
        ItemCatalog.GOLDEN_WHEAT.id to 5
    )

    // Configurable Resource Selling Prices (in 'مال')
    // As per Stage 4 requirements: 1 Wood = 2 مال
    private val resourceSellPrices = mutableMapOf(
        ItemCatalog.WOOD.id to 2,
        ItemCatalog.WILD_WOOD.id to 2,
        ItemCatalog.ANCIENT_STONE.id to 5
    )

    fun getSeedBuyPrice(seedId: String): Int {
        return seedBuyPrices[seedId] ?: 1
    }

    fun getCropSellPrice(cropId: String): Int {
        return cropSellPrices[cropId] ?: 2
    }

    fun getResourceSellPrice(resourceId: String): Int {
        return resourceSellPrices[resourceId] ?: 2
    }

    fun getItemSellPrice(item: Item): Int {
        return when (item.category) {
            ItemCategory.CROPS -> getCropSellPrice(item.id)
            ItemCategory.RESOURCES -> getResourceSellPrice(item.id)
            else -> item.baseSellPrice
        }
    }

    fun setSeedBuyPrice(seedId: String, price: Int) {
        if (price > 0) seedBuyPrices[seedId] = price
    }

    fun setCropSellPrice(cropId: String, price: Int) {
        if (price > 0) cropSellPrices[cropId] = price
    }

    fun setResourceSellPrice(resourceId: String, price: Int) {
        if (price > 0) resourceSellPrices[resourceId] = price
    }
}
