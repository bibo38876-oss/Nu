package com.example.game.npc

import com.example.game.time.TimeOfDay

/**
 * Action triggered through NPC interaction or dialogue options.
 */
enum class NPCActionType {
    NONE,
    OPEN_SEED_SHOP,
    OPEN_MARKET,
    FARMING_HINT,
    TOOL_HINT
}

/**
 * A single dialogue line spoken by an NPC.
 */
data class DialogueLine(
    val id: String,
    val textArabic: String,
    val actionType: NPCActionType = NPCActionType.NONE,
    val actionLabelArabic: String? = null
)

/**
 * Data-driven dialogue scripts for an NPC: initial meeting greeting and time-of-day contextual lines.
 */
data class NPCDialogue(
    val greetingLines: List<DialogueLine>,
    val regularLines: List<DialogueLine>,
    val morningLines: List<DialogueLine> = emptyList(),
    val dayLines: List<DialogueLine> = emptyList(),
    val eveningLines: List<DialogueLine> = emptyList(),
    val nightLines: List<DialogueLine> = emptyList()
) {
    fun getLinesForTimeOfDay(timeOfDay: TimeOfDay): List<DialogueLine> {
        val lines = when (timeOfDay) {
            TimeOfDay.DAWN, TimeOfDay.MORNING -> if (morningLines.isNotEmpty()) morningLines else regularLines
            TimeOfDay.DAY, TimeOfDay.AFTERNOON -> if (dayLines.isNotEmpty()) dayLines else regularLines
            TimeOfDay.EVENING, TimeOfDay.DUSK -> if (eveningLines.isNotEmpty()) eveningLines else regularLines
            TimeOfDay.NIGHT -> if (nightLines.isNotEmpty()) nightLines else regularLines
        }
        return if (lines.isNotEmpty()) lines else regularLines
    }
}
