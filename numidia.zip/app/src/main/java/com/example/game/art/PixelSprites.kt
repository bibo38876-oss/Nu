package com.example.game.art

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import com.example.game.state.Direction
import com.example.game.world.ObjectType
import com.example.game.world.TileType

object PixelSprites {

    // Cache of generated bitmaps
    val playerSprites = mutableMapOf<Pair<Direction, Int>, Bitmap>()
    val tileBitmaps = mutableMapOf<TileType, Bitmap>()
    val objectBitmaps = mutableMapOf<ObjectType, Bitmap>()

    lateinit var playerShadow: Bitmap
    lateinit var mediumShadow: Bitmap
    lateinit var largeShadow: Bitmap

    private var isInitialized = false

    fun initialize() {
        if (isInitialized) return

        generateShadows()
        generatePlayerSprites()
        generateTileSprites()
        generateObjectSprites()
        PixelFarmingSprites.initialize()
        PixelResourceSprites.initialize()
        PixelNPCSprites.initialize()

        isInitialized = true
    }

    private fun createPixelBitmap(width: Int, height: Int, drawer: (Bitmap) -> Unit): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        drawer(bitmap)
        return bitmap
    }

    private fun setPixel(bitmap: Bitmap, x: Int, y: Int, color: Int) {
        if (x in 0 until bitmap.width && y in 0 until bitmap.height) {
            bitmap.setPixel(x, y, color)
        }
    }

    private fun fillRect(bitmap: Bitmap, x1: Int, y1: Int, x2: Int, y2: Int, color: Int) {
        for (y in y1..y2) {
            for (x in x1..x2) {
                setPixel(bitmap, x, y, color)
            }
        }
    }

    // --- 1. SHADOWS ---
    private fun generateShadows() {
        // Player shadow: 16x8 oval
        playerShadow = createPixelBitmap(16, 8) { bmp ->
            for (y in 0 until 8) {
                for (x in 0 until 16) {
                    val dx = (x - 7.5f) / 7.5f
                    val dy = (y - 3.5f) / 3.5f
                    if (dx * dx + dy * dy <= 1.0f) {
                        val alpha = (0x50 * (1f - (dx * dx + dy * dy) * 0.3f)).toInt()
                        setPixel(bmp, x, y, (alpha shl 24))
                    }
                }
            }
        }

        // Medium shadow for trees/rocks: 28x12 oval
        mediumShadow = createPixelBitmap(28, 12) { bmp ->
            for (y in 0 until 12) {
                for (x in 0 until 28) {
                    val dx = (x - 13.5f) / 13.5f
                    val dy = (y - 5.5f) / 5.5f
                    if (dx * dx + dy * dy <= 1.0f) {
                        val alpha = (0x55 * (1f - (dx * dx + dy * dy) * 0.25f)).toInt()
                        setPixel(bmp, x, y, (alpha shl 24))
                    }
                }
            }
        }

        // Large shadow for buildings: 48x16 rounded rect
        largeShadow = createPixelBitmap(48, 16) { bmp ->
            for (y in 0 until 16) {
                for (x in 0 until 48) {
                    val dx = (x - 23.5f) / 23.5f
                    val dy = (y - 7.5f) / 7.5f
                    if (dx * dx + dy * dy <= 1.0f) {
                        val alpha = (0x60 * (1f - (dx * dx + dy * dy) * 0.2f)).toInt()
                        setPixel(bmp, x, y, (alpha shl 24))
                    }
                }
            }
        }
    }

    // --- 2. PLAYER CHARACTER (16x24 pixels, 4 directions x 3 anim frames) ---
    private fun generatePlayerSprites() {
        for (dir in Direction.entries) {
            for (frame in 0..2) {
                playerSprites[dir to frame] = createPlayerBitmap(dir, frame)
            }
        }
    }

    private fun createPlayerBitmap(dir: Direction, frame: Int): Bitmap {
        val w = 16
        val h = 24
        return createPixelBitmap(w, h) { bmp ->
            val bobY = if (frame != 0) -1 else 0

            when (dir) {
                Direction.DOWN -> {
                    // Head & Hair
                    fillRect(bmp, 5, 2 + bobY, 10, 3 + bobY, PixelPalette.HAIR_DARK)
                    fillRect(bmp, 4, 3 + bobY, 11, 4 + bobY, PixelPalette.HAIR_DARK)
                    fillRect(bmp, 4, 5 + bobY, 11, 8 + bobY, PixelPalette.SKIN_LIGHT)
                    // Eyes
                    setPixel(bmp, 5, 6 + bobY, PixelPalette.HAIR_DARK)
                    setPixel(bmp, 10, 6 + bobY, PixelPalette.HAIR_DARK)
                    // Headband
                    fillRect(bmp, 4, 4 + bobY, 11, 4 + bobY, PixelPalette.VEST_TERRACOTTA)

                    // Body: Linen Tunic & Terracotta Vest
                    fillRect(bmp, 4, 9 + bobY, 11, 14 + bobY, PixelPalette.TUNIC_CREAM)
                    // Vest sides
                    fillRect(bmp, 4, 9 + bobY, 5, 13 + bobY, PixelPalette.VEST_TERRACOTTA)
                    fillRect(bmp, 10, 9 + bobY, 11, 13 + bobY, PixelPalette.VEST_TERRACOTTA)
                    // Sash
                    fillRect(bmp, 4, 14 + bobY, 11, 14 + bobY, PixelPalette.SASH_BLUE)

                    // Arms
                    fillRect(bmp, 2, 9 + bobY, 3, 12 + bobY, PixelPalette.TUNIC_CREAM)
                    setPixel(bmp, 3, 13 + bobY, PixelPalette.SKIN_MID)
                    fillRect(bmp, 12, 9 + bobY, 13, 12 + bobY, PixelPalette.TUNIC_CREAM)
                    setPixel(bmp, 12, 13 + bobY, PixelPalette.SKIN_MID)

                    // Legs / Boots
                    when (frame) {
                        0 -> { // Idle
                            fillRect(bmp, 5, 15, 6, 21, PixelPalette.TUNIC_SHADOW)
                            fillRect(bmp, 9, 15, 10, 21, PixelPalette.TUNIC_SHADOW)
                            fillRect(bmp, 5, 20, 6, 22, PixelPalette.BOOTS_LEATHER)
                            fillRect(bmp, 9, 20, 10, 22, PixelPalette.BOOTS_LEATHER)
                        }
                        1 -> { // Left step
                            fillRect(bmp, 4, 15, 6, 20, PixelPalette.TUNIC_SHADOW)
                            fillRect(bmp, 4, 20, 6, 22, PixelPalette.BOOTS_LEATHER)
                            fillRect(bmp, 9, 15, 10, 19, PixelPalette.TUNIC_SHADOW)
                            fillRect(bmp, 9, 19, 10, 21, PixelPalette.BOOTS_LEATHER)
                        }
                        2 -> { // Right step
                            fillRect(bmp, 5, 15, 6, 19, PixelPalette.TUNIC_SHADOW)
                            fillRect(bmp, 5, 19, 6, 21, PixelPalette.BOOTS_LEATHER)
                            fillRect(bmp, 9, 15, 11, 20, PixelPalette.TUNIC_SHADOW)
                            fillRect(bmp, 9, 20, 11, 22, PixelPalette.BOOTS_LEATHER)
                        }
                    }
                }
                Direction.UP -> {
                    // Back Hair
                    fillRect(bmp, 4, 2 + bobY, 11, 8 + bobY, PixelPalette.HAIR_DARK)
                    // Back Headband
                    fillRect(bmp, 4, 5 + bobY, 11, 5 + bobY, PixelPalette.VEST_TERRACOTTA)

                    // Body from behind: Vest covers back
                    fillRect(bmp, 4, 9 + bobY, 11, 14 + bobY, PixelPalette.VEST_TERRACOTTA)
                    fillRect(bmp, 6, 9 + bobY, 9, 13 + bobY, PixelPalette.VEST_DARK)
                    // Sash
                    fillRect(bmp, 4, 14 + bobY, 11, 14 + bobY, PixelPalette.SASH_BLUE)

                    // Arms
                    fillRect(bmp, 2, 9 + bobY, 3, 12 + bobY, PixelPalette.TUNIC_CREAM)
                    fillRect(bmp, 12, 9 + bobY, 13, 12 + bobY, PixelPalette.TUNIC_CREAM)

                    // Legs
                    when (frame) {
                        0 -> {
                            fillRect(bmp, 5, 15, 6, 22, PixelPalette.BOOTS_LEATHER)
                            fillRect(bmp, 9, 15, 10, 22, PixelPalette.BOOTS_LEATHER)
                        }
                        1 -> {
                            fillRect(bmp, 4, 15, 6, 22, PixelPalette.BOOTS_LEATHER)
                            fillRect(bmp, 9, 15, 10, 20, PixelPalette.BOOTS_LEATHER)
                        }
                        2 -> {
                            fillRect(bmp, 5, 15, 6, 20, PixelPalette.BOOTS_LEATHER)
                            fillRect(bmp, 9, 15, 11, 22, PixelPalette.BOOTS_LEATHER)
                        }
                    }
                }
                Direction.LEFT -> {
                    // Profile Head
                    fillRect(bmp, 4, 2 + bobY, 10, 4 + bobY, PixelPalette.HAIR_DARK)
                    fillRect(bmp, 4, 4 + bobY, 9, 8 + bobY, PixelPalette.SKIN_LIGHT)
                    // Left hair curl
                    fillRect(bmp, 8, 4 + bobY, 11, 7 + bobY, PixelPalette.HAIR_DARK)
                    setPixel(bmp, 4, 6 + bobY, PixelPalette.HAIR_DARK) // eye
                    setPixel(bmp, 3, 7 + bobY, PixelPalette.SKIN_MID) // nose tip
                    fillRect(bmp, 4, 4 + bobY, 10, 4 + bobY, PixelPalette.VEST_TERRACOTTA) // headband

                    // Torso
                    fillRect(bmp, 5, 9 + bobY, 10, 14 + bobY, PixelPalette.TUNIC_CREAM)
                    fillRect(bmp, 7, 9 + bobY, 10, 13 + bobY, PixelPalette.VEST_TERRACOTTA)
                    fillRect(bmp, 5, 14 + bobY, 10, 14 + bobY, PixelPalette.SASH_BLUE)

                    // Arm
                    fillRect(bmp, 7, 10 + bobY, 9, 13 + bobY, PixelPalette.TUNIC_CREAM)
                    setPixel(bmp, 7, 14 + bobY, PixelPalette.SKIN_MID)

                    // Legs
                    when (frame) {
                        0 -> {
                            fillRect(bmp, 6, 15, 9, 22, PixelPalette.BOOTS_LEATHER)
                        }
                        1 -> {
                            fillRect(bmp, 3, 15, 6, 22, PixelPalette.BOOTS_LEATHER)
                            fillRect(bmp, 8, 15, 11, 20, PixelPalette.BOOTS_LEATHER)
                        }
                        2 -> {
                            fillRect(bmp, 8, 15, 12, 22, PixelPalette.BOOTS_LEATHER)
                            fillRect(bmp, 5, 15, 8, 20, PixelPalette.BOOTS_LEATHER)
                        }
                    }
                }
                Direction.RIGHT -> {
                    // Profile Head facing Right
                    fillRect(bmp, 5, 2 + bobY, 11, 4 + bobY, PixelPalette.HAIR_DARK)
                    fillRect(bmp, 6, 4 + bobY, 11, 8 + bobY, PixelPalette.SKIN_LIGHT)
                    fillRect(bmp, 4, 4 + bobY, 7, 7 + bobY, PixelPalette.HAIR_DARK)
                    setPixel(bmp, 11, 6 + bobY, PixelPalette.HAIR_DARK) // eye
                    setPixel(bmp, 12, 7 + bobY, PixelPalette.SKIN_MID) // nose
                    fillRect(bmp, 5, 4 + bobY, 11, 4 + bobY, PixelPalette.VEST_TERRACOTTA)

                    // Torso
                    fillRect(bmp, 5, 9 + bobY, 10, 14 + bobY, PixelPalette.TUNIC_CREAM)
                    fillRect(bmp, 5, 9 + bobY, 8, 13 + bobY, PixelPalette.VEST_TERRACOTTA)
                    fillRect(bmp, 5, 14 + bobY, 10, 14 + bobY, PixelPalette.SASH_BLUE)

                    // Arm
                    fillRect(bmp, 6, 10 + bobY, 8, 13 + bobY, PixelPalette.TUNIC_CREAM)
                    setPixel(bmp, 8, 14 + bobY, PixelPalette.SKIN_MID)

                    // Legs
                    when (frame) {
                        0 -> {
                            fillRect(bmp, 6, 15, 9, 22, PixelPalette.BOOTS_LEATHER)
                        }
                        1 -> {
                            fillRect(bmp, 9, 15, 12, 22, PixelPalette.BOOTS_LEATHER)
                            fillRect(bmp, 4, 15, 7, 20, PixelPalette.BOOTS_LEATHER)
                        }
                        2 -> {
                            fillRect(bmp, 3, 15, 7, 22, PixelPalette.BOOTS_LEATHER)
                            fillRect(bmp, 7, 15, 10, 20, PixelPalette.BOOTS_LEATHER)
                        }
                    }
                }
            }
        }
    }

    // --- 3. GROUND TILE SPRITES (16x16 pixels) ---
    private fun generateTileSprites() {
        // Village Grass
        tileBitmaps[TileType.GRASS] = createPixelBitmap(16, 16) { bmp ->
            fillRect(bmp, 0, 0, 15, 15, PixelPalette.GRASS_MID)
            setPixel(bmp, 3, 4, PixelPalette.GRASS_LIGHT)
            setPixel(bmp, 4, 3, PixelPalette.GRASS_LIGHT)
            setPixel(bmp, 11, 10, PixelPalette.GRASS_LIGHT)
            setPixel(bmp, 12, 9, PixelPalette.GRASS_LIGHT)
            setPixel(bmp, 8, 13, PixelPalette.GRASS_DARK)
            setPixel(bmp, 1, 14, PixelPalette.GRASS_DARK)
        }

        // Forest Grass
        tileBitmaps[TileType.FOREST_GRASS] = createPixelBitmap(16, 16) { bmp ->
            fillRect(bmp, 0, 0, 15, 15, PixelPalette.FOREST_GRASS_MID)
            setPixel(bmp, 2, 5, PixelPalette.FOREST_GRASS_LIGHT)
            setPixel(bmp, 3, 4, PixelPalette.FOREST_GRASS_LIGHT)
            setPixel(bmp, 13, 8, PixelPalette.FOREST_GRASS_LIGHT)
            setPixel(bmp, 7, 12, PixelPalette.FOREST_GRASS_DARK)
            setPixel(bmp, 8, 13, PixelPalette.FOREST_GRASS_DARK)
            setPixel(bmp, 10, 3, PixelPalette.FOREST_GRASS_DARK)
        }

        // Dirt Path
        tileBitmaps[TileType.DIRT_PATH] = createPixelBitmap(16, 16) { bmp ->
            fillRect(bmp, 0, 0, 15, 15, PixelPalette.DIRT_MID)
            setPixel(bmp, 2, 3, PixelPalette.DIRT_LIGHT)
            setPixel(bmp, 9, 8, PixelPalette.DIRT_LIGHT)
            setPixel(bmp, 14, 12, PixelPalette.DIRT_LIGHT)
            setPixel(bmp, 5, 13, PixelPalette.DIRT_DARK)
            setPixel(bmp, 11, 4, PixelPalette.DIRT_DARK)
        }

        // Cobblestone Plaza
        tileBitmaps[TileType.COBBLESTONE] = createPixelBitmap(16, 16) { bmp ->
            fillRect(bmp, 0, 0, 15, 15, PixelPalette.COBBLE_MID)
            // Cobblestone stone border lines
            for (i in 0..15) {
                setPixel(bmp, i, 7, PixelPalette.COBBLE_DARK)
                setPixel(bmp, i, 15, PixelPalette.COBBLE_DARK)
            }
            for (i in 0..6) {
                setPixel(bmp, 7, i, PixelPalette.COBBLE_DARK)
            }
            for (i in 8..14) {
                setPixel(bmp, 11, i, PixelPalette.COBBLE_DARK)
                setPixel(bmp, 3, i, PixelPalette.COBBLE_DARK)
            }
            // Stone highlights
            setPixel(bmp, 2, 2, PixelPalette.COBBLE_LIGHT)
            setPixel(bmp, 10, 2, PixelPalette.COBBLE_LIGHT)
            setPixel(bmp, 6, 10, PixelPalette.COBBLE_LIGHT)
        }

        // Farm Soil (Dark humus ridges)
        tileBitmaps[TileType.FARM_SOIL] = createPixelBitmap(16, 16) { bmp ->
            fillRect(bmp, 0, 0, 15, 15, PixelPalette.FARM_SOIL_MID)
            // Soil furrows
            for (y in listOf(2, 6, 10, 14)) {
                for (x in 0..15) {
                    setPixel(bmp, x, y, PixelPalette.FARM_SOIL_DARK)
                    if (y - 1 >= 0) setPixel(bmp, x, y - 1, PixelPalette.FARM_SOIL_LIGHT)
                }
            }
        }

        // Water Well Tile
        tileBitmaps[TileType.WATER_WELL] = createPixelBitmap(16, 16) { bmp ->
            fillRect(bmp, 0, 0, 15, 15, PixelPalette.WATER_DEEP)
            setPixel(bmp, 4, 4, PixelPalette.WATER_LIGHT)
            setPixel(bmp, 5, 4, PixelPalette.WATER_LIGHT)
            setPixel(bmp, 11, 10, PixelPalette.WATER_LIGHT)
        }

        // Stone Border Tile
        tileBitmaps[TileType.STONE_BORDER] = createPixelBitmap(16, 16) { bmp ->
            fillRect(bmp, 0, 0, 15, 15, PixelPalette.STONE_MID)
            for (i in 0..15) {
                setPixel(bmp, i, 0, PixelPalette.STONE_LIGHT)
                setPixel(bmp, 0, i, PixelPalette.STONE_LIGHT)
                setPixel(bmp, i, 15, PixelPalette.STONE_DARK)
                setPixel(bmp, 15, i, PixelPalette.STONE_DARK)
            }
        }
    }

    // --- 4. WORLD OBJECTS & BUILDINGS ---
    private fun generateObjectSprites() {
        objectBitmaps[ObjectType.SEED_SHOP] = createSeedShopBitmap()
        objectBitmaps[ObjectType.MARKET_STALL] = createMarketStallBitmap()
        objectBitmaps[ObjectType.STONE_WELL] = createStoneWellBitmap()
        objectBitmaps[ObjectType.TREE_CEDAR] = createCedarTreeBitmap()
        objectBitmaps[ObjectType.TREE_OLIVE] = createOliveTreeBitmap()
        objectBitmaps[ObjectType.TREE_CYPRESS] = createCypressTreeBitmap()
        objectBitmaps[ObjectType.BOULDER] = createBoulderBitmap()
        objectBitmaps[ObjectType.BERRY_BUSH] = createBerryBushBitmap()
        objectBitmaps[ObjectType.CLAY_POT] = createClayPotBitmap()
        objectBitmaps[ObjectType.WOOD_FENCE_H] = createFenceHBitmap()
        objectBitmaps[ObjectType.WOOD_FENCE_V] = createFenceVBitmap()
        objectBitmaps[ObjectType.SIGNPOST] = createSignpostBitmap()
        objectBitmaps[ObjectType.ZONE_EXIT_PORTAL] = createZonePortalBitmap()
        objectBitmaps[ObjectType.WORKSHOP_TABLE] = createWorkshopTableBitmap()
    }

    // SEED SHOP: 48x42 pixels (Terracotta roof, timber framing, warm stucco, arched door, sprout sign)
    private fun createSeedShopBitmap(): Bitmap {
        val w = 48
        val h = 42
        return createPixelBitmap(w, h) { bmp ->
            // Base Walls (Stucco sandstone)
            fillRect(bmp, 4, 16, 43, 38, PixelPalette.WALL_STUCCO_MID)
            fillRect(bmp, 6, 17, 41, 37, PixelPalette.WALL_STUCCO_LIGHT)

            // Timber corner columns
            fillRect(bmp, 4, 16, 6, 38, PixelPalette.WOOD_BEAM_MID)
            fillRect(bmp, 41, 16, 43, 38, PixelPalette.WOOD_BEAM_MID)
            fillRect(bmp, 4, 38, 43, 39, PixelPalette.WOOD_BEAM_DARK) // foundation beam

            // Roof (Mediterranean Terracotta clay tiles)
            for (row in 0..15) {
                val inset = 15 - row
                val x1 = (inset * 0.9f).toInt()
                val x2 = (w - 1 - inset * 0.9f).toInt()
                val col = if (row % 3 == 0) PixelPalette.ROOF_TILE_LIGHT else if (row % 3 == 1) PixelPalette.ROOF_TILE_MID else PixelPalette.ROOF_TILE_DARK
                fillRect(bmp, x1, row, x2, row, col)
            }
            // Roof overhang shadow
            fillRect(bmp, 4, 16, 43, 17, PixelPalette.SHADOW_DEEP)

            // Arched Wooden Door (Center-Left)
            fillRect(bmp, 12, 23, 20, 38, PixelPalette.WOOD_BEAM_DARK)
            fillRect(bmp, 13, 24, 19, 38, PixelPalette.WOOD_BEAM_MID)
            fillRect(bmp, 14, 22, 18, 23, PixelPalette.WOOD_BEAM_DARK) // arch top
            setPixel(bmp, 18, 30, PixelPalette.GOLD_BRIGHT) // iron ring handle

            // Glass Window with Wooden Frame & Flower Planter (Right)
            fillRect(bmp, 28, 23, 36, 31, PixelPalette.WOOD_BEAM_DARK)
            fillRect(bmp, 29, 24, 35, 30, PixelPalette.WINDOW_GLASS)
            fillRect(bmp, 29, 24, 31, 26, PixelPalette.WINDOW_LIGHT) // glare
            // Cross pane
            for (y in 24..30) setPixel(bmp, 32, y, PixelPalette.WOOD_BEAM_MID)
            for (x in 29..35) setPixel(bmp, x, 27, PixelPalette.WOOD_BEAM_MID)
            // Flower planter under window
            fillRect(bmp, 27, 31, 37, 33, PixelPalette.VEST_TERRACOTTA)
            setPixel(bmp, 29, 31, PixelPalette.CEDAR_LEAF_LIGHT)
            setPixel(bmp, 32, 31, PixelPalette.BERRY_RED)
            setPixel(bmp, 35, 31, PixelPalette.CEDAR_LEAF_LIGHT)

            // Seed Shop Hanging Sign with Sprout (over door)
            fillRect(bmp, 10, 18, 22, 21, PixelPalette.WOOD_BEAM_LIGHT)
            // Green leaf / sprout icon on the sign
            setPixel(bmp, 15, 19, PixelPalette.OASIS_GREEN)
            setPixel(bmp, 16, 18, PixelPalette.OASIS_GREEN_LIGHT)
            setPixel(bmp, 17, 19, PixelPalette.OASIS_GREEN)
            setPixel(bmp, 16, 20, PixelPalette.OASIS_GREEN_DARK)
        }
    }

    // MARKET / SELLING BUILDING: 48x42 pixels (Striped awning, wooden counter, vegetable crates)
    private fun createMarketStallBitmap(): Bitmap {
        val w = 48
        val h = 42
        return createPixelBitmap(w, h) { bmp ->
            // Back Stone Wall
            fillRect(bmp, 4, 14, 43, 38, PixelPalette.WALL_STUCCO_MID)
            fillRect(bmp, 6, 15, 41, 37, PixelPalette.WALL_STUCCO_LIGHT)

            // Striped Canopy (Terracotta red & cream stripes)
            for (y in 4..13) {
                for (x in 2..45) {
                    val stripe = (x / 4) % 2
                    val color = if (stripe == 0) PixelPalette.CANOPY_RED else PixelPalette.CANOPY_CREAM
                    val shadedColor = if (y == 4) PixelPalette.ROOF_TILE_LIGHT else if (y == 13) PixelPalette.OUTLINE_DARK else color
                    setPixel(bmp, x, y, shadedColor)
                }
            }
            // Scalloped awning fringe
            for (x in 2..45 step 4) {
                fillRect(bmp, x, 14, x + 3, 14, PixelPalette.CANOPY_RED)
            }

            // Timber upright support posts
            fillRect(bmp, 4, 14, 6, 38, PixelPalette.WOOD_BEAM_MID)
            fillRect(bmp, 41, 14, 43, 38, PixelPalette.WOOD_BEAM_MID)

            // Merchant Counter Stall (Wood planks across)
            fillRect(bmp, 10, 26, 37, 36, PixelPalette.WOOD_BEAM_MID)
            fillRect(bmp, 9, 25, 38, 26, PixelPalette.WOOD_BEAM_LIGHT) // counter top
            for (y in listOf(29, 33)) {
                for (x in 10..37) setPixel(bmp, x, y, PixelPalette.WOOD_BEAM_DARK)
            }

            // Crates on the counter (Golden wheat & dates)
            fillRect(bmp, 12, 21, 20, 25, PixelPalette.WOOD_BEAM_LIGHT)
            fillRect(bmp, 13, 22, 19, 23, PixelPalette.GOLD_BRIGHT) // wheat grains

            fillRect(bmp, 26, 21, 34, 25, PixelPalette.WOOD_BEAM_LIGHT)
            fillRect(bmp, 27, 22, 33, 23, PixelPalette.OLIVE_FRUIT) // dates / olives

            // Brass Trading Crest / Scales above
            fillRect(bmp, 22, 15, 26, 17, PixelPalette.GOLD_BRIGHT)
            setPixel(bmp, 24, 18, PixelPalette.GOLD_SHADOW)
        }
    }

    // STONE WELL: 24x26 pixels (Carved stone rim, timber canopy, water, bucket)
    private fun createStoneWellBitmap(): Bitmap {
        val w = 24
        val h = 26
        return createPixelBitmap(w, h) { bmp ->
            // Wooden roof canopy
            fillRect(bmp, 4, 2, 19, 5, PixelPalette.ROOF_TILE_MID)
            fillRect(bmp, 5, 1, 18, 2, PixelPalette.ROOF_TILE_LIGHT)
            // Posts
            fillRect(bmp, 4, 5, 5, 16, PixelPalette.WOOD_BEAM_MID)
            fillRect(bmp, 18, 5, 18, 16, PixelPalette.WOOD_BEAM_MID)
            // Cross beam & rope
            fillRect(bmp, 5, 6, 17, 6, PixelPalette.WOOD_BEAM_DARK)
            setPixel(bmp, 11, 7, PixelPalette.DIRT_LIGHT)
            setPixel(bmp, 11, 8, PixelPalette.DIRT_LIGHT)
            // Bucket
            fillRect(bmp, 10, 9, 12, 11, PixelPalette.WOOD_BEAM_LIGHT)

            // Circular Stone Basin
            fillRect(bmp, 3, 14, 20, 23, PixelPalette.STONE_MID)
            // Carved stone blocks
            fillRect(bmp, 2, 15, 21, 22, PixelPalette.STONE_LIGHT)
            fillRect(bmp, 5, 15, 18, 19, PixelPalette.WATER_DEEP) // water pool inside
            setPixel(bmp, 8, 17, PixelPalette.WATER_LIGHT)
            // Bottom rim
            fillRect(bmp, 3, 22, 20, 24, PixelPalette.STONE_DARK)
        }
    }

    // CEDAR TREE: 36x44 pixels (Ancient multi-tiered lush cedar/oak)
    private fun createCedarTreeBitmap(): Bitmap {
        val w = 36
        val h = 44
        return createPixelBitmap(w, h) { bmp ->
            // Thick Gnarled Trunk
            fillRect(bmp, 15, 26, 20, 42, PixelPalette.TRUNK_MID)
            fillRect(bmp, 14, 38, 22, 43, PixelPalette.TRUNK_DARK) // root flare
            fillRect(bmp, 16, 26, 17, 40, PixelPalette.TRUNK_LIGHT) // bark highlight

            // Tier 3 (Bottom canopy cluster)
            drawFoliageBlob(bmp, 18, 25, 16, 9, PixelPalette.CEDAR_LEAF_MID, PixelPalette.CEDAR_LEAF_LIGHT, PixelPalette.CEDAR_LEAF_DARK)
            // Tier 2 (Middle canopy cluster)
            drawFoliageBlob(bmp, 18, 17, 14, 8, PixelPalette.CEDAR_LEAF_MID, PixelPalette.CEDAR_LEAF_LIGHT, PixelPalette.CEDAR_LEAF_DARK)
            // Tier 1 (Top crown cluster)
            drawFoliageBlob(bmp, 18, 9, 11, 7, PixelPalette.CEDAR_LEAF_MID, PixelPalette.CEDAR_LEAF_LIGHT, PixelPalette.CEDAR_LEAF_DARK)
        }
    }

    // OLIVE TREE: 30x34 pixels (Twisted trunk, silvery green leaves, dark fruit)
    private fun createOliveTreeBitmap(): Bitmap {
        val w = 30
        val h = 34
        return createPixelBitmap(w, h) { bmp ->
            // Twisted Trunk
            fillRect(bmp, 13, 18, 16, 32, PixelPalette.TRUNK_MID)
            setPixel(bmp, 12, 22, PixelPalette.TRUNK_DARK)
            setPixel(bmp, 17, 26, PixelPalette.TRUNK_DARK)
            fillRect(bmp, 11, 31, 18, 33, PixelPalette.TRUNK_DARK)

            // Silvery green rounded foliage
            drawFoliageBlob(bmp, 10, 12, 9, 8, PixelPalette.OLIVE_LEAF_MID, PixelPalette.OLIVE_LEAF_LIGHT, PixelPalette.OLIVE_LEAF_DARK)
            drawFoliageBlob(bmp, 20, 13, 9, 8, PixelPalette.OLIVE_LEAF_MID, PixelPalette.OLIVE_LEAF_LIGHT, PixelPalette.OLIVE_LEAF_DARK)
            drawFoliageBlob(bmp, 15, 8, 10, 7, PixelPalette.OLIVE_LEAF_MID, PixelPalette.OLIVE_LEAF_LIGHT, PixelPalette.OLIVE_LEAF_DARK)

            // Olive fruits
            setPixel(bmp, 9, 14, PixelPalette.OLIVE_FRUIT)
            setPixel(bmp, 13, 11, PixelPalette.OLIVE_FRUIT)
            setPixel(bmp, 19, 15, PixelPalette.OLIVE_FRUIT)
            setPixel(bmp, 22, 11, PixelPalette.OLIVE_FRUIT)
        }
    }

    // CYPRESS TREE: 16x38 pixels (Slender flame-like deep green)
    private fun createCypressTreeBitmap(): Bitmap {
        val w = 16
        val h = 38
        return createPixelBitmap(w, h) { bmp ->
            // Trunk base
            fillRect(bmp, 7, 32, 8, 37, PixelPalette.TRUNK_DARK)

            // Flame-like layered silhouette
            for (y in 2..32) {
                val progress = y.toFloat() / 32f
                val halfW = when {
                    y < 6 -> 1 + y / 2
                    y in 6..24 -> 4 + (kotlin.math.sin(y * 0.4) * 1.5).toInt()
                    else -> 3 - (y - 24) / 3
                }.coerceIn(1, 6)

                val x1 = 8 - halfW
                val x2 = 8 + halfW
                for (x in x1..x2) {
                    val col = when {
                        x == x1 || y == 2 -> PixelPalette.CYPRESS_LEAF_LIGHT
                        x > 8 -> PixelPalette.CYPRESS_LEAF_DARK
                        else -> PixelPalette.CYPRESS_LEAF_MID
                    }
                    setPixel(bmp, x, y, col)
                }
            }
        }
    }

    private fun drawFoliageBlob(bmp: Bitmap, cx: Int, cy: Int, rx: Int, ry: Int, midCol: Int, lightCol: Int, darkCol: Int) {
        for (y in (cy - ry)..(cy + ry)) {
            for (x in (cx - rx)..(cx + rx)) {
                val dx = (x - cx).toFloat() / rx
                val dy = (y - cy).toFloat() / ry
                if (dx * dx + dy * dy <= 1.0f) {
                    val col = when {
                        dy < -0.3f && dx < 0.2f -> lightCol
                        dy > 0.3f || dx > 0.4f -> darkCol
                        else -> midCol
                    }
                    setPixel(bmp, x, y, col)
                }
            }
        }
    }

    // BOULDER: 18x14 pixels (Weathered rock with chisel details)
    private fun createBoulderBitmap(): Bitmap {
        val w = 18
        val h = 14
        return createPixelBitmap(w, h) { bmp ->
            fillRect(bmp, 3, 2, 14, 11, PixelPalette.STONE_MID)
            fillRect(bmp, 4, 3, 11, 7, PixelPalette.STONE_LIGHT) // top highlight
            fillRect(bmp, 2, 7, 15, 12, PixelPalette.STONE_DARK) // bottom base
            // Chisel crack
            setPixel(bmp, 7, 5, PixelPalette.STONE_DARK)
            setPixel(bmp, 8, 6, PixelPalette.STONE_DARK)
            setPixel(bmp, 8, 7, PixelPalette.STONE_DARK)
        }
    }

    // BERRY BUSH: 16x14 pixels (Leafy bush with red berries)
    private fun createBerryBushBitmap(): Bitmap {
        val w = 16
        val h = 14
        return createPixelBitmap(w, h) { bmp ->
            drawFoliageBlob(bmp, 8, 7, 6, 5, PixelPalette.CEDAR_LEAF_MID, PixelPalette.CEDAR_LEAF_LIGHT, PixelPalette.CEDAR_LEAF_DARK)
            // Red berries
            val berries = listOf(Pair(5, 5), Pair(10, 6), Pair(7, 9), Pair(11, 9))
            for ((bx, by) in berries) {
                setPixel(bmp, bx, by, PixelPalette.BERRY_RED)
                setPixel(bmp, bx, by - 1, PixelPalette.BERRY_HIGHLIGHT)
            }
        }
    }

    // CLAY POT: 10x14 pixels (Ancient terracotta amphora)
    private fun createClayPotBitmap(): Bitmap {
        val w = 10
        val h = 14
        return createPixelBitmap(w, h) { bmp ->
            // Lip rim
            fillRect(bmp, 3, 1, 6, 2, PixelPalette.ROOF_TILE_LIGHT)
            // Neck
            fillRect(bmp, 4, 3, 5, 4, PixelPalette.ROOF_TILE_MID)
            // Belly
            fillRect(bmp, 2, 5, 7, 10, PixelPalette.ROOF_TILE_MID)
            fillRect(bmp, 3, 6, 5, 9, PixelPalette.ROOF_TILE_LIGHT) // highlight
            fillRect(bmp, 2, 10, 7, 12, PixelPalette.ROOF_TILE_DARK)
            // Base
            fillRect(bmp, 3, 12, 6, 13, PixelPalette.OUTLINE_DARK)
            // Handles
            setPixel(bmp, 1, 6, PixelPalette.ROOF_TILE_DARK)
            setPixel(bmp, 8, 6, PixelPalette.ROOF_TILE_DARK)
        }
    }

    // FENCE HORIZONTAL: 16x12 pixels
    private fun createFenceHBitmap(): Bitmap {
        val w = 16
        val h = 12
        return createPixelBitmap(w, h) { bmp ->
            // Posts
            fillRect(bmp, 1, 2, 3, 11, PixelPalette.WOOD_BEAM_MID)
            fillRect(bmp, 12, 2, 14, 11, PixelPalette.WOOD_BEAM_MID)
            // Rails
            fillRect(bmp, 0, 4, 15, 5, PixelPalette.WOOD_BEAM_LIGHT)
            fillRect(bmp, 0, 8, 15, 9, PixelPalette.WOOD_BEAM_LIGHT)
        }
    }

    // FENCE VERTICAL: 10x16 pixels
    private fun createFenceVBitmap(): Bitmap {
        val w = 10
        val h = 16
        return createPixelBitmap(w, h) { bmp ->
            fillRect(bmp, 3, 0, 6, 15, PixelPalette.WOOD_BEAM_MID)
            fillRect(bmp, 4, 1, 5, 14, PixelPalette.WOOD_BEAM_LIGHT)
        }
    }

    // SIGNPOST: 14x18 pixels
    private fun createSignpostBitmap(): Bitmap {
        val w = 14
        val h = 18
        return createPixelBitmap(w, h) { bmp ->
            // Wooden Stake
            fillRect(bmp, 6, 5, 7, 17, PixelPalette.WOOD_BEAM_DARK)
            // Board
            fillRect(bmp, 1, 2, 12, 8, PixelPalette.WOOD_BEAM_MID)
            fillRect(bmp, 2, 3, 11, 7, PixelPalette.WOOD_BEAM_LIGHT)
            // Arrow indicator
            setPixel(bmp, 10, 5, PixelPalette.WOOD_BEAM_DARK)
            setPixel(bmp, 9, 4, PixelPalette.WOOD_BEAM_DARK)
            setPixel(bmp, 9, 6, PixelPalette.WOOD_BEAM_DARK)
        }
    }

    // ZONE EXIT PORTAL MARKER: 32x16 pixels (Carved stone ground threshold with glowing runic paving)
    private fun createZonePortalBitmap(): Bitmap {
        val w = 32
        val h = 16
        return createPixelBitmap(w, h) { bmp ->
            // Threshold stones
            fillRect(bmp, 2, 4, 29, 13, PixelPalette.COBBLE_MID)
            fillRect(bmp, 4, 5, 27, 11, PixelPalette.STONE_LIGHT)
            // Ancient carved decorative marks
            for (x in 6..26 step 4) {
                setPixel(bmp, x, 7, PixelPalette.GOLD_BRIGHT)
                setPixel(bmp, x + 1, 8, PixelPalette.GOLD_SHADOW)
            }
        }
    }

    // WORKSHOP BENCH & ANVIL: 32x22 pixels (Heavy timber workbench with anvil and tools)
    private fun createWorkshopTableBitmap(): Bitmap {
        val w = 32
        val h = 22
        return createPixelBitmap(w, h) { bmp ->
            // Heavy timber workbench legs & frame
            fillRect(bmp, 2, 12, 5, 21, PixelPalette.WOOD_BEAM_DARK)
            fillRect(bmp, 26, 12, 29, 21, PixelPalette.WOOD_BEAM_DARK)
            fillRect(bmp, 3, 10, 28, 14, PixelPalette.WOOD_BEAM_MID)
            fillRect(bmp, 1, 8, 30, 11, PixelPalette.WOOD_BEAM_LIGHT) // Table top

            // Bronze/Iron Anvil mounted on tree stump on left side
            fillRect(bmp, 5, 11, 11, 15, PixelPalette.TRUNK_DARK) // Stump mount
            fillRect(bmp, 4, 6, 12, 10, PixelPalette.STONE_DARK) // Anvil base
            fillRect(bmp, 2, 4, 14, 7, PixelPalette.STONE_MID) // Anvil horn and face
            fillRect(bmp, 6, 4, 12, 5, PixelPalette.STONE_LIGHT) // Metallic highlight
            setPixel(bmp, 1, 5, PixelPalette.STONE_MID) // Pointed horn

            // Hammer on workbench
            fillRect(bmp, 18, 7, 24, 7, PixelPalette.WOOD_BEAM_MID) // Handle
            fillRect(bmp, 23, 6, 25, 8, PixelPalette.STONE_DARK) // Hammerhead

            // Bronze ingots stacked on right
            fillRect(bmp, 17, 9, 21, 10, PixelPalette.GOLD_SHADOW)
            fillRect(bmp, 18, 9, 20, 9, PixelPalette.GOLD_BRIGHT)
        }
    }
}
