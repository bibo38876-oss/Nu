package com.example.game.world

import android.graphics.RectF

abstract class WorldZone(
    val zoneId: ZoneId,
    val cols: Int,
    val rows: Int,
    val defaultSpawnX: Float,
    val defaultSpawnY: Float
) {
    val worldWidth: Float = cols * TileType.TILE_SIZE
    val worldHeight: Float = rows * TileType.TILE_SIZE

    abstract val tiles: Array<Array<TileType>>
    abstract val objects: List<WorldObject>

    val worldBounds: RectF
        get() = RectF(0f, 0f, worldWidth, worldHeight)

    open fun getStaticColliders(): List<RectF> {
        val colliders = mutableListOf<RectF>()

        // 1. Solid world boundaries
        val margin = 16f
        // Top boundary
        colliders.add(RectF(-100f, -100f, worldWidth + 100f, margin))
        // Bottom boundary
        colliders.add(RectF(-100f, worldHeight - margin, worldWidth + 100f, worldHeight + 100f))
        // Left boundary
        colliders.add(RectF(-100f, -100f, margin, worldHeight + 100f))
        // Right boundary
        colliders.add(RectF(worldWidth - margin, -100f, worldWidth + 100f, worldHeight + 100f))

        // 2. Solid tiles
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (tiles[r][c].isSolid) {
                    val x = c * TileType.TILE_SIZE
                    val y = r * TileType.TILE_SIZE
                    colliders.add(RectF(x, y, x + TileType.TILE_SIZE, y + TileType.TILE_SIZE))
                }
            }
        }

        // 3. Solid objects
        for (obj in objects) {
            if (obj.solid) {
                colliders.add(obj.collisionBounds)
            }
        }

        return colliders
    }

    fun getInteractiveObjectNear(px: Float, py: Float): WorldObject? {
        return objects.firstOrNull { it.isNear(px, py) }
    }
}
