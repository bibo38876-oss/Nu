package com.example.game.audio

enum class SoundEffect {
    STEP,
    ZONE_ENTER,
    INTERACT,
    PURCHASE,
    ERROR,
    AXE_SWING,
    TREE_IMPACT,
    WOOD_COLLECT,
    QUEST_ACCEPT,
    QUEST_PROGRESS,
    QUEST_COMPLETE,
    RELATIONSHIP_UP
}

class AudioFoundation {
    var isMuted: Boolean = false

    fun playSound(effect: SoundEffect) {
        if (isMuted) return
        // Foundation hook: ready for SoundPool / MediaPlayer in future audio stages
    }
}
