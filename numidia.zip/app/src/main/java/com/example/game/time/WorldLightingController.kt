package com.example.game.time

import android.graphics.Color
import android.graphics.PointF
import kotlin.math.sin

data class LightSource(
    val x: Float,
    val y: Float,
    val radius: Float,
    val color: Int = 0xFFFFD15C.toInt(), // Warm golden lantern glow
    val flickerSpeed: Float = 3.5f,
    val flickerIntensity: Float = 0.15f
)

class WorldLightingController {

    /**
     * Calculates the ambient darkness overlay alpha (0.0f = full sunlight, ~0.60f = maximum night darkness).
     * Smoothly interpolates across hours and minutes so there are no abrupt jumps.
     */
    fun getAmbientDarknessAlpha(time: WorldTimeManager): Float {
        val totalMinutes = time.currentHour * 60 + time.currentMinute

        return when {
            // Midnight to 04:30 (Deep night)
            totalMinutes in 0 until 270 -> 0.58f

            // 04:30 to 06:00 (Dawn: darkness gradually decreases from 0.58 to 0.05)
            totalMinutes in 270 until 360 -> {
                val t = (totalMinutes - 270) / 90f
                0.58f - (t * 0.53f)
            }

            // 06:00 to 07:30 (Morning sunrise: 0.05 to 0.0f)
            totalMinutes in 360 until 450 -> {
                val t = (totalMinutes - 360) / 90f
                0.05f * (1f - t)
            }

            // 07:30 to 17:30 (Daytime: full clarity)
            totalMinutes in 450 until 1050 -> 0.0f

            // 17:30 to 19:30 (Evening sunset: 0.0f to 0.18f)
            totalMinutes in 1050 until 1170 -> {
                val t = (totalMinutes - 1050) / 120f
                t * 0.18f
            }

            // 19:30 to 21:00 (Dusk twilight: 0.18f to 0.45f)
            totalMinutes in 1170 until 1260 -> {
                val t = (totalMinutes - 1170) / 90f
                0.18f + (t * 0.27f)
            }

            // 21:00 to 24:00 (Night deepening: 0.45f to 0.58f)
            else -> {
                val t = (totalMinutes - 1260) / 180f
                0.45f + (t * 0.13f)
            }
        }
    }

    /**
     * Atmospheric ambient color tint based on time of day.
     */
    fun getAmbientOverlayColor(time: WorldTimeManager): Int {
        val alpha = (getAmbientDarknessAlpha(time) * 255).toInt().coerceIn(0, 255)
        if (alpha == 0) return Color.TRANSPARENT

        return when (time.timeOfDay) {
            TimeOfDay.DAWN -> Color.argb(alpha, 35, 20, 48) // Soft rosy violet
            TimeOfDay.MORNING -> Color.argb(alpha, 20, 25, 40)
            TimeOfDay.DAY -> Color.TRANSPARENT
            TimeOfDay.AFTERNOON -> Color.argb(alpha, 45, 28, 15) // Subtle amber
            TimeOfDay.EVENING -> Color.argb(alpha, 65, 30, 18) // Rich terracotta sunset
            TimeOfDay.DUSK -> Color.argb(alpha, 30, 22, 55) // Twilight indigo
            TimeOfDay.NIGHT -> Color.argb(alpha, 12, 16, 38) // Deep moonlit midnight blue
        }
    }

    /**
     * Fixed village lantern positions that glow during dusk and night.
     */
    val villageLanterns = listOf(
        // Seed shop entrance lantern
        LightSource(x = 222f, y = 245f, radius = 54f),
        // Market stall hanging lantern
        LightSource(x = 558f, y = 245f, radius = 54f),
        // Central stone well lantern
        LightSource(x = 384f, y = 410f, radius = 62f),
        // Workshop workbench lantern / forge glow
        LightSource(x = 450f, y = 352f, radius = 56f),
        // Farm signpost path lantern
        LightSource(x = 210f, y = 560f, radius = 48f),
        // Forest portal entrance guiding lantern
        LightSource(x = 384f, y = 50f, radius = 52f)
    )

    /**
     * Returns true when lanterns should be actively lit.
     */
    fun areLanternsLit(time: WorldTimeManager): Boolean {
        return time.isNight || time.timeOfDay == TimeOfDay.EVENING || time.timeOfDay == TimeOfDay.DAWN
    }

    /**
     * Computes flicker scale (0.90 to 1.10) for warm living lantern fire.
     */
    fun getFlickerScale(gameTimeSec: Float, seed: Float = 0f): Float {
        return 1.0f + (sin((gameTimeSec * 4.2 + seed).toDouble()).toFloat() * 0.08f)
    }
}
