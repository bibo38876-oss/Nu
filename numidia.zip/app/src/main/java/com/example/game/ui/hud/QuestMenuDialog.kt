package com.example.game.ui.hud

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.People
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.game.art.PixelNPCSprites
import com.example.game.npc.NPCDefinition
import com.example.game.npc.NPCId
import com.example.game.quest.QuestInstance
import com.example.game.quest.QuestManager
import com.example.game.quest.QuestState
import com.example.game.relationship.RelationshipData
import com.example.game.relationship.RelationshipManager

private enum class QuestTab(val titleArabic: String) {
    ACTIVE("النشطة"),
    AVAILABLE("المتاحة"),
    COMPLETED("المكتملة"),
    VILLAGERS("أهل القرية")
}

@Composable
fun QuestMenuDialog(
    questManager: QuestManager,
    relationshipManager: RelationshipManager,
    onAcceptQuest: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = QuestTab.entries

    val activeQuests = remember(questManager.instances.values.toList()) {
        questManager.getActiveQuests()
    }
    val availableQuests = remember(questManager.instances.values.toList()) {
        questManager.getAvailableQuests()
    }
    val completedQuests = remember(questManager.instances.values.toList()) {
        questManager.getCompletedQuests()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = true,
            usePlatformDefaultWidth = false
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp, vertical = 20.dp)
                    .testTag("quest_menu_dialog"),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Transparent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(0.92f)
                        .shadow(elevation = 20.dp, shape = RoundedCornerShape(20.dp))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color(0xF52A1C12), Color(0xFA170F09))
                                )
                            )
                            .border(
                                width = 2.dp,
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        Color(0xFFE2B26C),
                                        Color(0xFF8F5826),
                                        Color(0xFFE2B26C)
                                    )
                                ),
                                shape = RoundedCornerShape(20.dp)
                            )
                            .padding(16.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            // --- TOP BAR: TITLE + CLOSE BUTTON ---
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Assignment,
                                        contentDescription = null,
                                        tint = Color(0xFFFFD466),
                                        modifier = Modifier.size(26.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "مهام وأهل نوميديا",
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFFDE8BA)
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0x33FFFFFF))
                                        .clickable { onDismiss() }
                                        .testTag("quest_menu_close"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "إغلاق",
                                        tint = Color(0xFFF7EED6),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // --- TABS: النشطة / المتاحة / المكتملة / أهل القرية ---
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                tabs.forEachIndexed { index, tab ->
                                    val isSelected = selectedTab == index
                                    val countBadge = when (tab) {
                                        QuestTab.ACTIVE -> " (${activeQuests.size})"
                                        QuestTab.AVAILABLE -> " (${availableQuests.size})"
                                        QuestTab.COMPLETED -> " (${completedQuests.size})"
                                        QuestTab.VILLAGERS -> ""
                                    }

                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(
                                                if (isSelected) Color(0xFFC7782A) else Color(0x33442C1D)
                                            )
                                            .border(
                                                width = 1.dp,
                                                color = if (isSelected) Color(0xFFFFD466) else Color(0x446B4E38),
                                                shape = RoundedCornerShape(10.dp)
                                            )
                                            .clickable { selectedTab = index }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${tab.titleArabic}$countBadge",
                                            fontSize = 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) Color(0xFFFFF7E6) else Color(0xFFC9B89E),
                                            textAlign = TextAlign.Center,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // --- TAB CONTENT ---
                            Box(modifier = Modifier.weight(1f)) {
                                when (tabs[selectedTab]) {
                                    QuestTab.ACTIVE -> {
                                        QuestListContent(
                                            quests = activeQuests,
                                            emptyMessageArabic = "لا توجد مهام نشطة حالياً.\nتحدث مع سكان القرية لتلقي مهام جديدة!",
                                            showAcceptButton = false,
                                            onAcceptQuest = onAcceptQuest
                                        )
                                    }
                                    QuestTab.AVAILABLE -> {
                                        QuestListContent(
                                            quests = availableQuests,
                                            emptyMessageArabic = "لا توجد مهام متاحة جديدة الآن.\nأكمل مهامك الحالية أو استكشف مناطق القرية!",
                                            showAcceptButton = true,
                                            onAcceptQuest = onAcceptQuest
                                        )
                                    }
                                    QuestTab.COMPLETED -> {
                                        QuestListContent(
                                            quests = completedQuests,
                                            emptyMessageArabic = "لم تكتمل أي مهام بعد.\nأكمل المهام للمساهمة في بناء القرية وتوثيق إنجازاتك!",
                                            showAcceptButton = false,
                                            onAcceptQuest = onAcceptQuest
                                        )
                                    }
                                    QuestTab.VILLAGERS -> {
                                        VillagersListContent(
                                            relationshipManager = relationshipManager
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuestListContent(
    quests: List<QuestInstance>,
    emptyMessageArabic: String,
    showAcceptButton: Boolean,
    onAcceptQuest: (String) -> Unit
) {
    if (quests.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = emptyMessageArabic,
                color = Color(0xFFA8957F),
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp,
                fontWeight = FontWeight.Medium
            )
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(quests, key = { it.definition.id }) { quest ->
                QuestItemCard(
                    quest = quest,
                    showAcceptButton = showAcceptButton,
                    onAccept = { onAcceptQuest(quest.definition.id) }
                )
            }
        }
    }
}

@Composable
private fun QuestItemCard(
    quest: QuestInstance,
    showAcceptButton: Boolean,
    onAccept: () -> Unit
) {
    val def = quest.definition
    val giverNpc = NPCDefinition.findById(def.giverNpcId)
    val portrait = remember(def.giverNpcId) {
        PixelNPCSprites.npcPortraits[def.giverNpcId]?.asImageBitmap()
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x801A110A))
            .border(
                width = 1.dp,
                color = when (quest.state) {
                    QuestState.COMPLETED_PENDING_REWARD -> Color(0xFF6ED84F)
                    QuestState.COMPLETED -> Color(0xFF4C7B38)
                    QuestState.ACTIVE -> Color(0xFFC7782A)
                    else -> Color(0xFF6B4E38)
                },
                shape = RoundedCornerShape(14.dp)
            )
            .padding(14.dp)
    ) {
        Column {
            // Header: Giver Portrait + Title & Giver Info + Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Portrait
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF130B07))
                        .border(1.dp, Color(0xFFD49A55), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (portrait != null) {
                        Image(
                            bitmap = portrait,
                            contentDescription = giverNpc?.nameArabic,
                            modifier = Modifier.size(38.dp),
                            filterQuality = FilterQuality.None
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = def.titleArabic,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFF2D1)
                    )
                    Text(
                        text = "المانح: ${giverNpc?.nameArabic ?: ""} (${giverNpc?.roleTitleArabic ?: ""})",
                        fontSize = 11.sp,
                        color = Color(0xFFC9B89E)
                    )
                }

                // Status Badge
                val (badgeText, badgeBg, badgeTextColor) = when (quest.state) {
                    QuestState.COMPLETED_PENDING_REWARD -> Triple("جاهزة للتسليم", Color(0xFF28541C), Color(0xFF7CE45B))
                    QuestState.COMPLETED -> Triple("مكتملة", Color(0xFF233B18), Color(0xFF90DC74))
                    QuestState.ACTIVE -> Triple("نشطة", Color(0xFF5A3114), Color(0xFFFFCC66))
                    QuestState.AVAILABLE -> Triple("متاحة", Color(0xFF293B4E), Color(0xFF86B9E8))
                    else -> Triple("مغلقة", Color(0xFF333333), Color(0xFFAAAAAA))
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(badgeBg)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = badgeText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = badgeTextColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Summary Text
            Text(
                text = def.summaryArabic,
                fontSize = 12.sp,
                color = Color(0xFFE2D6C3),
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Objectives Progress
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                for (i in def.objectives.indices) {
                    val obj = def.objectives[i]
                    val cur = quest.getObjectiveProgress(i)
                    val target = obj.targetCount
                    val isDone = cur >= target

                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (isDone) Icons.Default.CheckCircle else Icons.Default.Assignment,
                                    contentDescription = null,
                                    tint = if (isDone) Color(0xFF6ED84F) else Color(0xFFC9B89E),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = obj.descriptionArabic,
                                    fontSize = 12.sp,
                                    color = if (isDone) Color(0xFF7CE45B) else Color(0xFFE2D6C3)
                                )
                            }
                            Text(
                                text = "$cur / $target",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDone) Color(0xFF7CE45B) else Color(0xFFFFD466)
                            )
                        }

                        if (!isDone) {
                            Spacer(modifier = Modifier.height(4.dp))
                            val progressFloat = (cur.toFloat() / target.toFloat()).coerceIn(0f, 1f)
                            LinearProgressIndicator(
                                progress = { progressFloat },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(5.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = Color(0xFFD97724),
                                trackColor = Color(0x442C1E14)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Bottom Bar: Reward summary + Optional Accept Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.MonetizationOn,
                        contentDescription = null,
                        tint = Color(0xFFFFD466),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "المكافأة: ${def.reward.descriptionArabic}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFFFD466)
                    )
                }

                if (showAcceptButton && quest.state == QuestState.AVAILABLE) {
                    Button(
                        onClick = onAccept,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFC7782A)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("accept_quest_btn_${def.id}")
                    ) {
                        Text(
                            text = "قبول المهمة",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFF6E6)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun VillagersListContent(
    relationshipManager: RelationshipManager
) {
    val npcs = NPCDefinition.ALL_NPCS

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(npcs, key = { it.id.idString }) { def ->
            val relData = relationshipManager.getData(def.id)
            val portrait = remember(def.id) {
                PixelNPCSprites.npcPortraits[def.id]?.asImageBitmap()
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0x801A110A))
                    .border(1.dp, Color(0xFF6B4E38), RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Portrait
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF130B07))
                                .border(1.dp, Color(0xFFD49A55), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (portrait != null) {
                                Image(
                                    bitmap = portrait,
                                    contentDescription = def.nameArabic,
                                    modifier = Modifier.size(42.dp),
                                    filterQuality = FilterQuality.None
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = def.nameArabic,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFFF2D1)
                                )

                                // Relationship Level Badge
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF4C301A))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = relData.level.titleArabic,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFFFD466)
                                    )
                                }
                            }

                            Text(
                                text = def.roleTitleArabic,
                                fontSize = 12.sp,
                                color = Color(0xFFC9B89E),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Bio / Short description
                    val bio = when (def.id) {
                        NPCId.YASSIN -> "يدير متجر البذور في شمال غرب القرية، وخبير بجودة المحاصيل والتجارة الزراعية."
                        NPCId.SAMIRA -> "تاجرة نشيطة في سوق القرية تشتري المحاصيل وثمار الغابة بأسعار عادلة."
                        NPCId.MAZEN -> "مزارع ذو خبرة عريقة يعتني بأراضي الواحة ويوجه المزارعين الجدد."
                        NPCId.AMIN -> "حرفي ماهر يعمل في ورشة النجارة وصيانة الأدوات والسندان شرق القرية."
                    }

                    Text(
                        text = "\"$bio\"",
                        fontSize = 12.sp,
                        color = Color(0xFFDDD2BA),
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Affinity Progress Bar (0..100)
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Favorite,
                                    contentDescription = null,
                                    tint = Color(0xFFE55D5D),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "مستوى الألفة والمودة",
                                    fontSize = 11.sp,
                                    color = Color(0xFFE2D6C3)
                                )
                            }
                            Text(
                                text = "${relData.affinity} / 100",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFFD466)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        val progress = (relData.affinity / 100f).coerceIn(0f, 1f)
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = Color(0xFFE55D5D),
                            trackColor = Color(0x442C1E14)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "المهام المنجزة: ${relData.completedQuestsCount}",
                        fontSize = 11.sp,
                        color = Color(0xFFA8957F)
                    )
                }
            }
        }
    }
}
