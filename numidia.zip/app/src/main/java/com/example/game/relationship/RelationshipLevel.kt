package com.example.game.relationship

enum class RelationshipLevel(
    val titleArabic: String,
    val minAffinity: Int,
    val maxAffinity: Int
) {
    STRANGER("غريب", 0, 19),
    ACQUAINTANCE("معروف", 20, 39),
    FRIEND("صديق", 40, 59),
    CLOSE_FRIEND("صديق مقرّب", 60, 79),
    VILLAGER("من أهل القرية", 80, 100);

    companion object {
        fun fromAffinity(affinity: Int): RelationshipLevel {
            val clamped = affinity.coerceIn(0, 100)
            return entries.firstOrNull { clamped in it.minAffinity..it.maxAffinity } ?: STRANGER
        }
    }
}
