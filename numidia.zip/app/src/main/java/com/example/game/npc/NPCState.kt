package com.example.game.npc

import com.example.game.state.Direction
import com.example.game.time.TimeOfDay
import kotlin.math.abs
import kotlin.math.sqrt

enum class NPCBehavior {
    IDLE,
    WANDERING,
    LOOKING_AROUND,
    TALKING
}

/**
 * Mutable runtime state of an NPC instance in the world.
 */
class NPCState(
    val definition: NPCDefinition,
    var x: Float = definition.homeX,
    var y: Float = definition.homeY,
    var direction: Direction = definition.defaultDirection,
    var behavior: NPCBehavior = NPCBehavior.IDLE,
    var currentActivity: NPCActivity = NPCActivity.WORKING,
    var currentScheduledEntry: ScheduleEntry? = null,
    var targetX: Float = definition.homeX,
    var targetY: Float = definition.homeY,
    var behaviorTimer: Float = 2.5f,
    var animFrame: Int = 0,
    var isMoving: Boolean = false,
    var animTimer: Float = 0f,
    var hasMetPlayer: Boolean = false,
    var dialogueIndex: Int = 0
) {
    val sortY: Float get() = y

    fun distanceTo(px: Float, py: Float): Float {
        val dx = px - x
        val dy = py - y
        return sqrt(dx * dx + dy * dy)
    }

    fun isPlayerInRange(px: Float, py: Float): Boolean {
        val dx = px - x
        val dy = py - y
        return (dx * dx + dy * dy) <= (definition.interactionRange * definition.interactionRange)
    }

    fun facePlayer(px: Float, py: Float) {
        val dx = px - x
        val dy = py - y
        direction = when {
            abs(dx) > abs(dy) -> {
                if (dx > 0) Direction.RIGHT else Direction.LEFT
            }
            else -> {
                if (dy > 0) Direction.DOWN else Direction.UP
            }
        }
    }

    /**
     * Gets active dialogue lines based on whether player has met them and current time of day.
     */
    fun getActiveLines(timeOfDay: TimeOfDay = TimeOfDay.DAY): List<DialogueLine> {
        return if (!hasMetPlayer) {
            definition.dialogue.greetingLines
        } else {
            definition.dialogue.getLinesForTimeOfDay(timeOfDay)
        }
    }

    fun getCurrentDialogueLine(timeOfDay: TimeOfDay = TimeOfDay.DAY): DialogueLine {
        val lines = getActiveLines(timeOfDay)
        if (lines.isEmpty()) {
            return DialogueLine("fallback", "مرحباً بك يا صديقي في نوميديا.")
        }
        val safeIndex = dialogueIndex.coerceIn(0, lines.size - 1)
        return lines[safeIndex]
    }

    fun hasMoreDialogue(timeOfDay: TimeOfDay = TimeOfDay.DAY): Boolean {
        val lines = getActiveLines(timeOfDay)
        return dialogueIndex < lines.size - 1
    }

    fun advanceDialogue(timeOfDay: TimeOfDay = TimeOfDay.DAY): Boolean {
        val lines = getActiveLines(timeOfDay)
        return if (dialogueIndex < lines.size - 1) {
            dialogueIndex++
            true
        } else {
            false
        }
    }

    fun resetDialogueForNextEncounter(timeOfDay: TimeOfDay = TimeOfDay.DAY) {
        if (!hasMetPlayer) {
            hasMetPlayer = true
            dialogueIndex = 0
        } else {
            val linesCount = getActiveLines(timeOfDay).size
            if (linesCount > 0) {
                dialogueIndex = (dialogueIndex + 1) % linesCount
            } else {
                dialogueIndex = 0
            }
        }
    }
}
