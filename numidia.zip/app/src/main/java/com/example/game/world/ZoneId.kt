package com.example.game.world

enum class ZoneId(val displayNameArabic: String, val subtitleArabic: String) {
    VILLAGE("قرية نوميديا", "واحة السكينة وبداية الرحلة"),
    FOREST("غابة نوميديا", "أشجار باسقة وطبيعة بكر");

    companion object {
        fun fromString(name: String?): ZoneId {
            return entries.find { it.name.equals(name, ignoreCase = true) } ?: VILLAGE
        }
    }
}
