package com.example.game.state

enum class PlayerActionAnimation {
    NONE,
    PREPARING_SOIL,
    PLANTING,
    HARVESTING,
    CHOPPING
}

data class PlayerState(
    val x: Float = 360f,
    val y: Float = 420f,
    val direction: Direction = Direction.DOWN,
    val isMoving: Boolean = false,
    val animFrame: Int = 0,
    val speed: Float = 140f, // world units per second
    val width: Float = 24f,  // visual collision width
    val height: Float = 32f, // visual collision height
    val actionAnimation: PlayerActionAnimation = PlayerActionAnimation.NONE,
    val actionTimer: Float = 0f
) {
    // Ground footprint for collision (feet level only, allowing 3/4 perspective overlap)
    val collisionLeft: Float get() = x - 9f
    val collisionRight: Float get() = x + 9f
    val collisionTop: Float get() = y + 2f
    val collisionBottom: Float get() = y + 14f

    fun copyWithPosition(newX: Float, newY: Float): PlayerState {
        return copy(x = newX, y = newY)
    }
}
