package com.example.game.world

class ForestZone : WorldZone(
    zoneId = ZoneId.FOREST,
    cols = 26,
    rows = 30,
    defaultSpawnX = 416f,
    defaultSpawnY = 840f
) {
    override val tiles: Array<Array<TileType>> = Array(rows) { r ->
        Array(cols) { c ->
            when {
                // South exit path returning to village
                c in 12..13 && r >= 24 -> TileType.DIRT_PATH

                // Main winding trail through the forest
                c in 11..14 && r in 19..23 -> TileType.DIRT_PATH
                c in 8..12 && r in 14..18 -> TileType.DIRT_PATH
                c in 12..16 && r in 9..13 -> TileType.DIRT_PATH
                c in 6..11 && r in 5..8 -> TileType.DIRT_PATH

                // Forest clearing in the north-center
                c in 13..18 && r in 4..7 -> TileType.DIRT_PATH

                // Rich forest floor everywhere else
                else -> TileType.FOREST_GRASS
            }
        }
    }

    override val objects: List<WorldObject> = buildList {
        // --- 1. RETURN TO VILLAGE PORTAL & SIGNPOST (South) ---
        add(
            WorldObject(
                id = "sign_village_return",
                type = ObjectType.SIGNPOST,
                x = 370f,
                y = 880f,
                visualWidth = 26f,
                visualHeight = 34f,
                solid = true,
                collisionWidth = 16f,
                collisionHeight = 14f,
                interactionLabelArabic = "شاخصة: العودة إلى القرية",
                interactionAction = "ENTER_VILLAGE",
                interactionRadius = 54f
            )
        )

        // Portal trigger zone at south edge
        add(
            WorldObject(
                id = "portal_to_village",
                type = ObjectType.ZONE_EXIT_PORTAL,
                x = 416f,
                y = 920f,
                visualWidth = 80f,
                visualHeight = 40f,
                solid = false,
                interactionLabelArabic = "العودة إلى القرية",
                interactionAction = "ENTER_VILLAGE",
                interactionRadius = 50f
            )
        )

        // Gate trees framing the southern exit (boundary framing)
        add(WorldObject("forest_exit_tree_l", ObjectType.TREE_CYPRESS, 330f, 890f, 36f, 80f, solid = true, collisionWidth = 20f, collisionHeight = 16f))
        add(WorldObject("forest_exit_tree_r", ObjectType.TREE_CYPRESS, 500f, 890f, 36f, 80f, solid = true, collisionWidth = 20f, collisionHeight = 16f))

        // --- 2. NATURAL OBSTACLES: BOULDERS & BUSHES ---
        add(WorldObject("forest_rock_1", ObjectType.BOULDER, 220f, 440f, 42f, 34f, solid = true, collisionWidth = 36f, collisionHeight = 22f))
        add(WorldObject("forest_rock_2", ObjectType.BOULDER, 530f, 370f, 44f, 36f, solid = true, collisionWidth = 38f, collisionHeight = 24f))
        add(WorldObject("forest_rock_3", ObjectType.BOULDER, 400f, 660f, 36f, 28f, solid = true, collisionWidth = 30f, collisionHeight = 18f))
        add(WorldObject("forest_rock_4", ObjectType.BOULDER, 620f, 840f, 42f, 34f, solid = true, collisionWidth = 36f, collisionHeight = 22f))

        // Wild Berry Bushes
        add(WorldObject("forest_bush_1", ObjectType.BERRY_BUSH, 300f, 320f, 38f, 34f, solid = true, collisionWidth = 30f, collisionHeight = 18f))
        add(WorldObject("forest_bush_2", ObjectType.BERRY_BUSH, 490f, 580f, 38f, 34f, solid = true, collisionWidth = 30f, collisionHeight = 18f))
        add(WorldObject("forest_bush_3", ObjectType.BERRY_BUSH, 210f, 580f, 38f, 34f, solid = true, collisionWidth = 30f, collisionHeight = 18f))
        add(WorldObject("forest_bush_4", ObjectType.BERRY_BUSH, 600f, 440f, 38f, 34f, solid = true, collisionWidth = 30f, collisionHeight = 18f))
        add(WorldObject("forest_bush_5", ObjectType.BERRY_BUSH, 340f, 720f, 38f, 34f, solid = true, collisionWidth = 30f, collisionHeight = 18f))
    }
}
