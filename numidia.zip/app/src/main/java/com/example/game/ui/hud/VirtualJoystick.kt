package com.example.game.ui.hud

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

@Composable
fun VirtualJoystick(
    modifier: Modifier = Modifier,
    sizeDp: Int = 144,
    onValueChange: (Float, Float) -> Unit
) {
    val density = LocalDensity.current
    val sizePx = with(density) { sizeDp.dp.toPx() }
    val radiusPx = sizePx / 2f
    val maxDragRadius = radiusPx * 0.70f
    var knobOffset by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier = modifier
            .size(sizeDp.dp)
            .testTag("virtual_joystick")
            .pointerInput(sizeDp, density) {
                // Immediate response on press & drag (no touch slop delay)
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val pointerId = down.id
                    val center = Offset(radiusPx, radiusPx)
                    val initialDrag = down.position - center
                    val initialDist = sqrt(initialDrag.x * initialDrag.x + initialDrag.y * initialDrag.y)

                    // Allow immediate tap or drag anywhere in touch boundary
                    val clamped = if (initialDist <= maxDragRadius) {
                        initialDrag
                    } else if (initialDist > 0f) {
                        initialDrag * (maxDragRadius / initialDist)
                    } else {
                        Offset.Zero
                    }

                    knobOffset = clamped
                    val normX = if (maxDragRadius > 0f) clamped.x / maxDragRadius else 0f
                    val normY = if (maxDragRadius > 0f) clamped.y / maxDragRadius else 0f
                    onValueChange(normX, normY)
                    down.consume()

                    // Continuously track dragging until finger or mouse is lifted
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == pointerId } ?: event.changes.firstOrNull() ?: break
                        if (!change.pressed) {
                            knobOffset = Offset.Zero
                            onValueChange(0f, 0f)
                            break
                        }
                        change.consume()

                        val currentDrag = change.position - center
                        val currentDist = sqrt(currentDrag.x * currentDrag.x + currentDrag.y * currentDrag.y)
                        val clampedCurrent = if (currentDist <= maxDragRadius) {
                            currentDrag
                        } else if (currentDist > 0f) {
                            currentDrag * (maxDragRadius / currentDist)
                        } else {
                            Offset.Zero
                        }

                        knobOffset = clampedCurrent
                        val nx = if (maxDragRadius > 0f) clampedCurrent.x / maxDragRadius else 0f
                        val ny = if (maxDragRadius > 0f) clampedCurrent.y / maxDragRadius else 0f
                        onValueChange(nx, ny)
                    }
                }
            }
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)

            // Outer Base Ring (Ancient Terracotta / Desert Bronze)
            drawCircle(
                color = Color(0x771E140D),
                radius = maxDragRadius + 14f,
                center = center
            )
            drawCircle(
                color = Color(0x99C87D43),
                radius = maxDragRadius + 12f,
                center = center,
                style = Stroke(width = 3.5f)
            )

            // Directional notches & arrows (North, South, East, West)
            val notchRadius = maxDragRadius + 6f
            for (angle in listOf(0.0, Math.PI / 2, Math.PI, 3 * Math.PI / 2)) {
                val nx = center.x + (notchRadius * cos(angle)).toFloat()
                val ny = center.y + (notchRadius * sin(angle)).toFloat()
                drawCircle(
                    color = Color(0xFFFFD466),
                    radius = 4f,
                    center = Offset(nx, ny)
                )
            }

            // Inner Joystick Knob (Movable Thumb Pad)
            val knobCenter = center + knobOffset
            drawCircle(
                color = Color(0x55000000),
                radius = 32f,
                center = knobCenter + Offset(0f, 4f) // soft shadow
            )
            drawCircle(
                color = Color(0xFFC87D43),
                radius = 30f,
                center = knobCenter
            )
            drawCircle(
                color = Color(0xFFE8A870),
                radius = 24f,
                center = knobCenter
            )
            drawCircle(
                color = Color(0xFFFFD466),
                radius = 14f,
                center = knobCenter
            )
            drawCircle(
                color = Color(0xFF5A2A12),
                radius = 30f,
                center = knobCenter,
                style = Stroke(width = 3f)
            )
        }
    }
}
