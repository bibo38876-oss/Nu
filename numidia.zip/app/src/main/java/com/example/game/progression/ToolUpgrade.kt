package com.example.game.progression

import com.example.game.tools.ToolType

data class ToolUpgradeTier(
    val toolType: ToolType,
    val level: Int,
    val nameArabic: String,
    val cost: Int,
    val speedBonusPercent: Int,
    val gatherDurationMultiplier: Float, // Duration multiplier (< 1.0f means faster)
    val descriptionArabic: String
)

object ToolUpgradeCatalog {

    val AXE_TIERS = listOf(
        ToolUpgradeTier(
            toolType = ToolType.AXE,
            level = 1,
            nameArabic = "الفأس الأساسي",
            cost = 0,
            speedBonusPercent = 0,
            gatherDurationMultiplier = 1.0f,
            descriptionArabic = "فأس برونزي تقليدي صالح لقطع أشجار غابة نوميديا."
        ),
        ToolUpgradeTier(
            toolType = ToolType.AXE,
            level = 2,
            nameArabic = "الفأس المحسن",
            cost = 150,
            speedBonusPercent = 25,
            gatherDurationMultiplier = 0.80f, // 20% faster
            descriptionArabic = "فأس معزز بحديدة مقسّاة، يرفع سرعة قطع الأشجار بنسبة 20%."
        ),
        ToolUpgradeTier(
            toolType = ToolType.AXE,
            level = 3,
            nameArabic = "الفأس المتطور",
            cost = 500,
            speedBonusPercent = 55,
            gatherDurationMultiplier = 0.65f, // ~35% faster
            descriptionArabic = "فأس نوميدي فائق الصلابة بحافة مصقولة، يقطع الأشجار بسرعة خيالية."
        )
    )

    fun getTier(toolType: ToolType, level: Int): ToolUpgradeTier? {
        return when (toolType) {
            ToolType.AXE -> AXE_TIERS.find { it.level == level }
            else -> null
        }
    }

    fun getNextTier(toolType: ToolType, currentLevel: Int): ToolUpgradeTier? {
        return when (toolType) {
            ToolType.AXE -> AXE_TIERS.find { it.level == currentLevel + 1 }
            else -> null
        }
    }

    fun getMaxLevel(toolType: ToolType): Int {
        return when (toolType) {
            ToolType.AXE -> AXE_TIERS.maxOf { it.level }
            else -> 1
        }
    }
}
