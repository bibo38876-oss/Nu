package com.example.game.economy

class EconomyManager(initialMoney: Int = 50) {
    var money: Int = initialMoney
        private set

    val currencyNameArabic: String = "مال"

    fun canAfford(amount: Int): Boolean {
        return amount >= 0 && money >= amount
    }

    fun addMoney(amount: Int): Boolean {
        if (amount < 0) return false
        money += amount
        return true
    }

    fun spendMoney(amount: Int): Boolean {
        if (!canAfford(amount)) return false
        money -= amount
        return true
    }

    fun setMoney(amount: Int) {
        money = kotlin.math.max(0, amount)
    }

    fun formatBalance(): String {
        return "$money $currencyNameArabic"
    }
}
