package com.example.game.quest

enum class ObjectiveType {
    COLLECT_ITEM,
    HARVEST_CROP,
    SELL_ITEM,
    SELL_VALUE,
    GATHER_WOOD,
    BUY_ITEM,
    VISIT_LOCATION,
    TALK_TO_NPC
}

data class QuestObjective(
    val id: String,
    val type: ObjectiveType,
    val descriptionArabic: String,
    val targetCount: Int,
    val targetItemId: String? = null,
    val targetCropId: String? = null,
    val targetNpcId: String? = null,
    val targetLocation: String? = null
)
