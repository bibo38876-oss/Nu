package com.example.game.art

object PixelPalette {
    // Transparency
    const val TRANSPARENT = 0x00000000

    // Shadows
    const val SHADOW_SOFT = 0x55000000
    const val SHADOW_DEEP = 0x77000000

    // Outlines
    const val OUTLINE_DARK = 0xFF18100A.toInt()
    const val OUTLINE_WOOD = 0xFF2A1B10.toInt()

    // Skin & Character
    const val SKIN_LIGHT = 0xFFE5B588.toInt()
    const val SKIN_MID = 0xFFCA9365.toInt()
    const val HAIR_DARK = 0xFF2C1E16.toInt()
    const val TUNIC_CREAM = 0xFFF2ECE0.toInt()
    const val TUNIC_SHADOW = 0xFFD3C8B4.toInt()
    const val VEST_TERRACOTTA = 0xFFA64826.toInt()
    const val VEST_DARK = 0xFF7A2E12.toInt()
    const val SASH_BLUE = 0xFF294E6B.toInt()
    const val BOOTS_LEATHER = 0xFF452818.toInt()

    // Building Materials
    const val ROOF_TILE_LIGHT = 0xFFD86B32.toInt()
    const val ROOF_TILE_MID = 0xFFB34C19.toInt()
    const val ROOF_TILE_DARK = 0xFF83310B.toInt()
    const val WALL_STUCCO_LIGHT = 0xFFEFE4CE.toInt()
    const val WALL_STUCCO_MID = 0xFFD8C7A6.toInt()
    const val WALL_STUCCO_DARK = 0xFFB8A27C.toInt()
    const val WOOD_BEAM_LIGHT = 0xFF7B4D2B.toInt()
    const val WOOD_BEAM_MID = 0xFF58341A.toInt()
    const val WOOD_BEAM_DARK = 0xFF3D210F.toInt()
    const val WINDOW_GLASS = 0xFF8AB9C7.toInt()
    const val WINDOW_LIGHT = 0xFFD4EFF7.toInt()
    const val CANOPY_CREAM = 0xFFF4EDE0.toInt()
    const val CANOPY_RED = 0xFFB83A24.toInt()

    // Foliage & Trees
    const val OASIS_GREEN = 0xFF4E8236.toInt()
    const val OASIS_GREEN_LIGHT = 0xFF7BAA5A.toInt()
    const val OASIS_GREEN_DARK = 0xFF2D551E.toInt()

    const val CEDAR_LEAF_LIGHT = 0xFF487332.toInt()
    const val CEDAR_LEAF_MID = 0xFF305520.toInt()
    const val CEDAR_LEAF_DARK = 0xFF1C3A11.toInt()

    const val OLIVE_LEAF_LIGHT = 0xFF869960.toInt()
    const val OLIVE_LEAF_MID = 0xFF657845.toInt()
    const val OLIVE_LEAF_DARK = 0xFF45552B.toInt()
    const val OLIVE_FRUIT = 0xFF2B2836.toInt()

    const val CYPRESS_LEAF_LIGHT = 0xFF366032.toInt()
    const val CYPRESS_LEAF_MID = 0xFF244820.toInt()
    const val CYPRESS_LEAF_DARK = 0xFF143012.toInt()

    const val TRUNK_LIGHT = 0xFF6E4E36.toInt()
    const val TRUNK_MID = 0xFF503522.toInt()
    const val TRUNK_DARK = 0xFF341F12.toInt()

    const val BERRY_RED = 0xFFD93232.toInt()
    const val BERRY_HIGHLIGHT = 0xFFFF7373.toInt()

    // Ground & Terrain
    const val GRASS_LIGHT = 0xFF6F9A3E.toInt()
    const val GRASS_MID = 0xFF58822B.toInt()
    const val GRASS_DARK = 0xFF42681E.toInt()

    const val FOREST_GRASS_LIGHT = 0xFF4C7B38.toInt()
    const val FOREST_GRASS_MID = 0xFF3A6328.toInt()
    const val FOREST_GRASS_DARK = 0xFF274919.toInt()

    const val DIRT_LIGHT = 0xFFD1A66E.toInt()
    const val DIRT_MID = 0xFFB8894E.toInt()
    const val DIRT_DARK = 0xFF986B33.toInt()

    const val COBBLE_LIGHT = 0xFFB2A99B.toInt()
    const val COBBLE_MID = 0xFF8F8474.toInt()
    const val COBBLE_DARK = 0xFF675C4C.toInt()

    const val FARM_SOIL_LIGHT = 0xFF61432B.toInt()
    const val FARM_SOIL_MID = 0xFF472E1B.toInt()
    const val FARM_SOIL_DARK = 0xFF311C0E.toInt()

    // Water & Stone
    const val WATER_LIGHT = 0xFF5AA6C9.toInt()
    const val WATER_DEEP = 0xFF2D698A.toInt()
    const val STONE_LIGHT = 0xFF9EA3A5.toInt()
    const val STONE_MID = 0xFF7A8083.toInt()
    const val STONE_DARK = 0xFF54595C.toInt()

    // Gold & Brass
    const val GOLD_BRIGHT = 0xFFF5C538.toInt()
    const val GOLD_SHADOW = 0xFFB88A1A.toInt()

    // Crop Colors
    const val CARROT_ORANGE = 0xFFE6641A.toInt()
    const val CARROT_LIGHT = 0xFFF78235.toInt()
    const val TOMATO_RED = 0xFFD92626.toInt()
    const val TOMATO_LIGHT = 0xFFF0463A.toInt()
    const val POTATO_BEIGE = 0xFFC4A470.toInt()
    const val POTATO_DARK = 0xFF8E6D3E.toInt()
    const val ONION_GOLD = 0xFFD9943B.toInt()
    const val ONION_SKIN = 0xFFA66922.toInt()
    const val PEPPER_RED = 0xFFC91A1A.toInt()
    const val PEPPER_BRIGHT = 0xFFEB3434.toInt()
    const val SPROUT_GREEN = 0xFF74BD3C.toInt()
}
