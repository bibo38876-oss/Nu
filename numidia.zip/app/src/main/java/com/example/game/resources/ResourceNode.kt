package com.example.game.resources

import android.graphics.RectF
import kotlin.math.max

data class ResourceNode(
    val id: String,
    val category: ResourceCategory = ResourceCategory.TREE,
    val treeVariant: TreeVariant = TreeVariant.MEDIUM,
    val worldX: Float,
    val worldY: Float,
    var state: ResourceNodeState = ResourceNodeState.AVAILABLE,
    var depletedTimestamp: Long = 0L,
    var respawnDurationSeconds: Int = treeVariant.respawnDurationSec,
    var gatherProgress: Float = 0f,
    var shakeTimer: Float = 0f
) {
    val sortY: Float get() = worldY

    // Collision box anchored at tree foot/base
    val colliderRect: RectF
        get() = RectF(
            worldX - treeVariant.collisionWidth / 2f,
            worldY - treeVariant.collisionHeight / 2f,
            worldX + treeVariant.collisionWidth / 2f,
            worldY + treeVariant.collisionHeight / 2f
        )

    fun canGather(): Boolean {
        return state == ResourceNodeState.AVAILABLE
    }

    fun startGathering() {
        if (canGather()) {
            state = ResourceNodeState.GATHERING
            gatherProgress = 0f
            shakeTimer = 0f
        }
    }

    fun cancelGathering() {
        if (state == ResourceNodeState.GATHERING) {
            state = ResourceNodeState.AVAILABLE
            gatherProgress = 0f
            shakeTimer = 0f
        }
    }

    /**
     * Ticks gathering progress. Returns true when gathering is finished.
     */
    fun tickGathering(deltaTimeSec: Float, durationMultiplier: Float = 1.0f): Boolean {
        if (state != ResourceNodeState.GATHERING) return false

        shakeTimer += deltaTimeSec
        val totalDuration = max(0.4f, treeVariant.baseChopDurationSec * durationMultiplier)
        gatherProgress += deltaTimeSec / totalDuration

        return gatherProgress >= 1.0f
    }

    /**
     * Completes gathering, awards wood yield, and marks tree as DEPLETED.
     */
    fun completeGathering(currentTimeMillis: Long): Int {
        state = ResourceNodeState.DEPLETED
        depletedTimestamp = currentTimeMillis
        respawnDurationSeconds = treeVariant.respawnDurationSec
        gatherProgress = 1.0f
        shakeTimer = 0f
        return treeVariant.woodYield
    }

    /**
     * Timestamp-based respawn check. Works even if player was away or game closed.
     */
    fun updateRespawn(currentTimeMillis: Long) {
        if (state == ResourceNodeState.DEPLETED || state == ResourceNodeState.RESPAWNING) {
            val elapsedSec = (currentTimeMillis - depletedTimestamp) / 1000L
            if (elapsedSec >= respawnDurationSeconds) {
                state = ResourceNodeState.AVAILABLE
                gatherProgress = 0f
                depletedTimestamp = 0L
            } else if (elapsedSec >= (respawnDurationSeconds * 0.75f)) {
                state = ResourceNodeState.RESPAWNING
            }
        }
    }

    fun getRemainingRespawnSeconds(currentTimeMillis: Long): Int {
        if (state != ResourceNodeState.DEPLETED && state != ResourceNodeState.RESPAWNING) return 0
        val elapsedSec = (currentTimeMillis - depletedTimestamp) / 1000L
        return max(0, (respawnDurationSeconds - elapsedSec).toInt())
    }

    fun toSerialized(): String {
        return "$id|${category.name}|${treeVariant.name}|$worldX|$worldY|${state.name}|$depletedTimestamp|$respawnDurationSeconds"
    }

    companion object {
        fun fromSerialized(raw: String): ResourceNode? {
            val parts = raw.split("|")
            if (parts.size < 8) return null
            return try {
                val id = parts[0]
                val cat = ResourceCategory.valueOf(parts[1])
                val variant = TreeVariant.valueOf(parts[2])
                val x = parts[3].toFloat()
                val y = parts[4].toFloat()
                val state = ResourceNodeState.valueOf(parts[5])
                val ts = parts[6].toLong()
                val dur = parts[7].toInt()

                ResourceNode(
                    id = id,
                    category = cat,
                    treeVariant = variant,
                    worldX = x,
                    worldY = y,
                    state = state,
                    depletedTimestamp = ts,
                    respawnDurationSeconds = dur
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}
