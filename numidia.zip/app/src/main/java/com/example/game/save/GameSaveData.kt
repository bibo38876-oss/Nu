package com.example.game.save

import com.example.game.state.Direction
import com.example.game.world.ZoneId

data class GameSaveData(
    val currentZone: ZoneId = ZoneId.VILLAGE,
    val playerX: Float = 384f,
    val playerY: Float = 460f,
    val playerDirection: Direction = Direction.DOWN,
    val money: Int = 50,
    val inventoryItems: List<Pair<String, Int>> = listOf(
        "bronze_axe" to 1,
        "carrot_seeds" to 3,
        "tomato_seeds" to 2,
        "potato_seeds" to 2,
        "onion_seeds" to 1,
        "pepper_seeds" to 1,
        "wheat_seeds" to 5,
        "water_jug" to 1
    ),
    val farmingPlotData: String = "",
    val treeResourceData: String = "",
    val metNpcIds: List<String> = emptyList(),
    // Stage 8: World Time System
    val worldDay: Int = 1,
    val worldHour: Int = 8,
    val worldMinute: Int = 0,
    val totalGameMinutes: Long = 480L,
    val timeVersion: Int = 1,
    // Stage 9: Quests & NPC Relationships
    val questData: String = "",
    val relationshipData: String = "",
    val questVersion: Int = 1,
    val timestamp: Long = System.currentTimeMillis()
)
