package com.example.game.economy

sealed class TransactionResult {
    data class Success(
        val messageArabic: String,
        val amountChanged: Int,
        val itemQuantity: Int
    ) : TransactionResult()

    data class Failure(
        val reasonArabic: String
    ) : TransactionResult()
}
