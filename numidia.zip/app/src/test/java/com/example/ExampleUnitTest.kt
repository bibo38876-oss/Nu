package com.example

import com.example.game.economy.EconomyManager
import com.example.game.economy.MarketSystem
import com.example.game.economy.PriceCatalog
import com.example.game.economy.ShopSystem
import com.example.game.economy.TransactionResult
import com.example.game.engine.CollisionSystem
import com.example.game.farming.CropType
import com.example.game.farming.FarmingPlot
import com.example.game.farming.FarmingPlotFoundation
import com.example.game.farming.FarmingPlotState
import com.example.game.items.Inventory
import com.example.game.items.ItemCatalog
import com.example.game.state.Direction
import com.example.game.state.PlayerState
import com.example.game.world.ForestZone
import com.example.game.world.ObjectType
import com.example.game.world.VillageZone
import com.example.game.world.ZoneId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleUnitTest {

    @Test
    fun economy_startsAtFiftyAndValidatesTransactions() {
        val economy = EconomyManager(50)
        assertEquals(50, economy.money)
        assertEquals("مال", economy.currencyNameArabic)

        assertTrue(economy.canAfford(30))
        assertFalse(economy.canAfford(60))

        assertTrue(economy.spendMoney(20))
        assertEquals(30, economy.money)

        assertFalse(economy.spendMoney(40))
        assertEquals(30, economy.money)

        economy.addMoney(25)
        assertEquals(55, economy.money)
    }

    @Test
    fun priceCatalog_matchesConfiguredProgression() {
        // Seed Buy Prices
        assertEquals(1, PriceCatalog.getSeedBuyPrice(ItemCatalog.CARROT_SEEDS.id))
        assertEquals(2, PriceCatalog.getSeedBuyPrice(ItemCatalog.TOMATO_SEEDS.id))
        assertEquals(3, PriceCatalog.getSeedBuyPrice(ItemCatalog.POTATO_SEEDS.id))
        assertEquals(4, PriceCatalog.getSeedBuyPrice(ItemCatalog.ONION_SEEDS.id))
        assertEquals(6, PriceCatalog.getSeedBuyPrice(ItemCatalog.PEPPER_SEEDS.id))

        // Crop Sell Prices
        assertEquals(3, PriceCatalog.getCropSellPrice(ItemCatalog.CARROT.id))
        assertEquals(6, PriceCatalog.getCropSellPrice(ItemCatalog.TOMATO.id))
        assertEquals(9, PriceCatalog.getCropSellPrice(ItemCatalog.POTATO.id))
        assertEquals(13, PriceCatalog.getCropSellPrice(ItemCatalog.ONION.id))
        assertEquals(20, PriceCatalog.getCropSellPrice(ItemCatalog.PEPPER.id))
    }

    @Test
    fun shopSystem_buyingSeedsValidatesFundsAndUpdatesInventory() {
        val economy = EconomyManager(50)
        val inventory = Inventory(16)

        // Buy 5 tomato seeds @ 2 = 10 cost
        val result = ShopSystem.buySeed(economy, inventory, ItemCatalog.TOMATO_SEEDS, 5)
        assertTrue(result is TransactionResult.Success)
        assertEquals(40, economy.money)
        assertEquals(5, inventory.getTotalQuantity(ItemCatalog.TOMATO_SEEDS.id))

        // Attempt buying 100 pepper seeds @ 6 = 600 cost (cannot afford)
        val failResult = ShopSystem.buySeed(economy, inventory, ItemCatalog.PEPPER_SEEDS, 100)
        assertTrue(failResult is TransactionResult.Failure)
        assertEquals(40, economy.money) // Money untouched
        assertEquals(0, inventory.getTotalQuantity(ItemCatalog.PEPPER_SEEDS.id))
    }

    @Test
    fun marketSystem_sellingCropsAddsMoneyAndDeductsInventory() {
        val economy = EconomyManager(20)
        val inventory = Inventory(16)

        // Add 4 harvested carrots to inventory
        inventory.addItem(ItemCatalog.CARROT, 4)

        // Sell 3 carrots @ 3 = 9 earn
        val result = MarketSystem.sellCrop(economy, inventory, ItemCatalog.CARROT, 3)
        assertTrue(result is TransactionResult.Success)
        assertEquals(29, economy.money)
        assertEquals(1, inventory.getTotalQuantity(ItemCatalog.CARROT.id))

        // Cannot sell seeds at the market
        val seedSellResult = MarketSystem.sellCrop(economy, inventory, ItemCatalog.CARROT_SEEDS, 1)
        assertTrue(seedSellResult is TransactionResult.Failure)

        // Cannot sell more than owned
        val overSellResult = MarketSystem.sellCrop(economy, inventory, ItemCatalog.CARROT, 5)
        assertTrue(overSellResult is TransactionResult.Failure)
        assertEquals(29, economy.money)
    }

    @Test
    fun completeEconomyLoop_buyPlantGrowHarvestSellRepeat() {
        val economy = EconomyManager(50)
        val inventory = Inventory(16)
        val plot = FarmingPlot(id = "plot_loop", worldX = 100f, worldY = 100f)

        // 1. Buy 3 Carrot Seeds @ 1 = 3 cost
        val buyRes = ShopSystem.buySeed(economy, inventory, ItemCatalog.CARROT_SEEDS, 3)
        assertTrue(buyRes is TransactionResult.Success)
        assertEquals(47, economy.money)
        assertEquals(3, inventory.getTotalQuantity(ItemCatalog.CARROT_SEEDS.id))

        // 2. Prepare plot & Plant 1 Carrot Seed
        plot.createPlot()
        plot.prepareSoil()
        assertTrue(inventory.removeItem(ItemCatalog.CARROT_SEEDS.id, 1))
        assertEquals(2, inventory.getTotalQuantity(ItemCatalog.CARROT_SEEDS.id))

        val now = 1000000L
        plot.plant(CropType.CARROT, currentTimeMs = now)

        // 3. Fast-forward 30 seconds -> Crop matures
        plot.updateStateWithTime(currentTimeMs = now + 30_000L)
        assertEquals(FarmingPlotState.MATURE, plot.state)

        // 4. Harvest Crop
        val crop = plot.harvest()
        assertEquals(CropType.CARROT, crop)
        val cropItem = ItemCatalog.findById(crop!!.harvestItemId)
        assertNotNull(cropItem)
        inventory.addItem(cropItem!!, 1)
        assertEquals(1, inventory.getTotalQuantity(ItemCatalog.CARROT.id))

        // 5. Sell Harvested Carrot at Market @ 3
        val sellRes = MarketSystem.sellCrop(economy, inventory, ItemCatalog.CARROT, 1)
        assertTrue(sellRes is TransactionResult.Success)
        assertEquals(50, economy.money) // 47 + 3 = 50
        assertEquals(0, inventory.getTotalQuantity(ItemCatalog.CARROT.id))
        assertEquals(2, inventory.getTotalQuantity(ItemCatalog.CARROT_SEEDS.id)) // 2 seeds remaining
    }

    @Test
    fun inventory_handlesStackingAndQuantities() {
        val inv = Inventory(16)
        val carrotSeed = ItemCatalog.CARROT_SEEDS

        val remainder1 = inv.addItem(carrotSeed, 10)
        assertEquals(0, remainder1)
        assertEquals(10, inv.getTotalQuantity(carrotSeed.id))

        val remainder2 = inv.addItem(carrotSeed, 5)
        assertEquals(0, remainder2)
        assertEquals(15, inv.getTotalQuantity(carrotSeed.id))

        assertTrue(inv.removeItem(carrotSeed.id, 8))
        assertEquals(7, inv.getTotalQuantity(carrotSeed.id))
    }

    @Test
    fun farming_soilFatigueIncreasesGrowthTime() {
        val plot = FarmingPlot(id = "fatigue_plot", worldX = 100f, worldY = 100f)
        plot.plantedCrop = CropType.CARROT

        assertEquals(0, plot.getFatiguePenaltySeconds())
        assertEquals(30, plot.getTotalGrowthDurationSeconds())

        plot.consecutiveHarvests = 2
        assertEquals(10, plot.getFatiguePenaltySeconds())
        assertEquals(40, plot.getTotalGrowthDurationSeconds())

        plot.consecutiveHarvests = 15
        assertEquals(40, plot.getFatiguePenaltySeconds())
        assertEquals(70, plot.getTotalGrowthDurationSeconds())
    }

    @Test
    fun direction_mapsVectorsCorrectly() {
        assertEquals(Direction.RIGHT, Direction.fromVector(0.8f, 0.1f))
        assertEquals(Direction.LEFT, Direction.fromVector(-0.8f, 0.1f))
        assertEquals(Direction.DOWN, Direction.fromVector(0.1f, 0.9f))
        assertEquals(Direction.UP, Direction.fromVector(0.1f, -0.9f))
    }

    @Test
    fun collision_preventsMovingIntoSolidColliders() {
        val village = VillageZone()
        val colliders = village.getStaticColliders()
        val player = PlayerState(x = 384f, y = 460f)

        val collidesAtSpawn = CollisionSystem.checkCollision(384f, 460f, player, colliders)
        assertFalse("Player must start in free space", collidesAtSpawn)

        val seedShop = village.objects.first { it.type == ObjectType.SEED_SHOP }
        val collidesInsideShop = CollisionSystem.checkCollision(seedShop.x, seedShop.y, player, colliders)
        assertTrue("Cannot step inside solid shop bounds", collidesInsideShop)
    }

    @Test
    fun resourceNode_treeVariantsYieldsAndRespawnConfig() {
        val small = com.example.game.resources.TreeVariant.SMALL
        val medium = com.example.game.resources.TreeVariant.MEDIUM
        val large = com.example.game.resources.TreeVariant.LARGE

        assertEquals(2, small.woodYield)
        assertEquals(60, small.respawnDurationSec)

        assertEquals(4, medium.woodYield)
        assertEquals(90, medium.respawnDurationSec)

        assertEquals(7, large.woodYield)
        assertEquals(120, large.respawnDurationSec)
    }

    @Test
    fun resourceNode_gatheringAndTimestampRespawn() {
        val tree = com.example.game.resources.ResourceNode(
            id = "test_tree",
            treeVariant = com.example.game.resources.TreeVariant.MEDIUM,
            worldX = 200f,
            worldY = 300f
        )

        assertTrue(tree.canGather())
        assertEquals(com.example.game.resources.ResourceNodeState.AVAILABLE, tree.state)

        tree.startGathering()
        assertEquals(com.example.game.resources.ResourceNodeState.GATHERING, tree.state)

        // Progress gathering
        assertFalse(tree.tickGathering(0.5f))
        assertTrue(tree.tickGathering(2.0f)) // Exceeds 1.9s duration

        val now = 5000000L
        val woodYield = tree.completeGathering(now)
        assertEquals(4, woodYield)
        assertEquals(com.example.game.resources.ResourceNodeState.DEPLETED, tree.state)
        assertFalse(tree.canGather())

        // 30s elapsed -> still depleted
        tree.updateRespawn(now + 30_000L)
        assertEquals(com.example.game.resources.ResourceNodeState.DEPLETED, tree.state)

        // 75s elapsed (>= 75% of 90s) -> respawning state
        tree.updateRespawn(now + 75_000L)
        assertEquals(com.example.game.resources.ResourceNodeState.RESPAWNING, tree.state)

        // 90s elapsed -> respawn complete!
        tree.updateRespawn(now + 90_000L)
        assertEquals(com.example.game.resources.ResourceNodeState.AVAILABLE, tree.state)
        assertTrue(tree.canGather())
    }

    @Test
    fun marketSystem_sellingWoodAddsCorrectMoneyAtTwoPerWood() {
        val economy = EconomyManager(50)
        val inventory = Inventory(16)

        // Initial Price: 1 Wood = 2 مال
        assertEquals(2, PriceCatalog.getResourceSellPrice(ItemCatalog.WOOD.id))

        // Add 10 wood
        inventory.addItem(ItemCatalog.WOOD, 10)
        assertEquals(10, inventory.getTotalQuantity(ItemCatalog.WOOD.id))

        // Sell 10 wood @ 2 = +20 مال
        val res = MarketSystem.sellItem(economy, inventory, ItemCatalog.WOOD, 10)
        assertTrue(res is TransactionResult.Success)
        assertEquals(70, economy.money) // 50 + 20
        assertEquals(0, inventory.getTotalQuantity(ItemCatalog.WOOD.id))

        // Cannot sell more than owned
        val failRes = MarketSystem.sellItem(economy, inventory, ItemCatalog.WOOD, 1)
        assertTrue(failRes is TransactionResult.Failure)
        assertEquals(70, economy.money)
    }

    @Test
    fun completeStageFourLoop_chopTreeSellWoodBuySeedsFarm() {
        val economy = EconomyManager(50)
        val inventory = Inventory(16)
        val tree = com.example.game.resources.ResourceNode(
            id = "cedar_large",
            treeVariant = com.example.game.resources.TreeVariant.LARGE,
            worldX = 400f,
            worldY = 400f
        )
        val plot = FarmingPlot(id = "village_plot_1", worldX = 120f, worldY = 580f)

        // 1. Player has axe
        inventory.addItem(ItemCatalog.AXE, 1)
        assertTrue(inventory.hasItem("bronze_axe"))

        // 2. Chop large cedar -> 7 wood
        tree.startGathering()
        tree.tickGathering(3.0f)
        val woodHarvested = tree.completeGathering(System.currentTimeMillis())
        assertEquals(7, woodHarvested)
        inventory.addItem(ItemCatalog.WOOD, woodHarvested)
        assertEquals(7, inventory.getTotalQuantity(ItemCatalog.WOOD.id))

        // 3. Sell 7 wood at Market @ 2 = 14 money earned
        val sellRes = MarketSystem.sellItem(economy, inventory, ItemCatalog.WOOD, 7)
        assertTrue(sellRes is TransactionResult.Success)
        assertEquals(64, economy.money) // 50 + 14 = 64
        assertEquals(0, inventory.getTotalQuantity(ItemCatalog.WOOD.id))

        // 4. Use earned money to buy 4 Potato seeds @ 3 = 12 cost
        val buyRes = ShopSystem.buySeed(economy, inventory, ItemCatalog.POTATO_SEEDS, 4)
        assertTrue(buyRes is TransactionResult.Success)
        assertEquals(52, economy.money) // 64 - 12 = 52
        assertEquals(4, inventory.getTotalQuantity(ItemCatalog.POTATO_SEEDS.id))

        // 5. Return to farming plot and plant
        plot.createPlot()
        plot.prepareSoil()
        assertTrue(inventory.removeItem(ItemCatalog.POTATO_SEEDS.id, 1))
        plot.plant(CropType.POTATO, System.currentTimeMillis())
        assertEquals(FarmingPlotState.GROWING, plot.state)
        assertEquals(3, inventory.getTotalQuantity(ItemCatalog.POTATO_SEEDS.id))
    }
}
