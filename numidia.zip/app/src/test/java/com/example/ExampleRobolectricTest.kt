package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.game.economy.EconomyManager
import com.example.game.economy.MarketSystem
import com.example.game.economy.ShopSystem
import com.example.game.farming.CropType
import com.example.game.farming.FarmingPlotFoundation
import com.example.game.farming.FarmingPlotState
import com.example.game.items.Inventory
import com.example.game.items.ItemCatalog
import com.example.game.save.GameSaveData
import com.example.game.save.SaveSystem
import com.example.game.world.ZoneId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun read_string_from_context() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("NUMIDIA", appName)
    }

    @Test
    fun saveSystem_persistsAndRestoresGameState() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val saveSystem = SaveSystem(context)
        saveSystem.resetSave()

        val initialSave = saveSystem.loadGame()
        assertEquals(50, initialSave.money)
        assertEquals(ZoneId.VILLAGE, initialSave.currentZone)

        // Save new progress
        val customSave = GameSaveData(
            currentZone = ZoneId.FOREST,
            playerX = 416f,
            playerY = 860f,
            money = 120,
            inventoryItems = listOf("carrot_seeds" to 12, "wild_wood" to 4)
        )
        saveSystem.saveGame(customSave)

        assertTrue(saveSystem.hasSaveData())
        val loaded = saveSystem.loadGame()
        assertEquals(ZoneId.FOREST, loaded.currentZone)
        assertEquals(120, loaded.money)
        assertEquals(416f, loaded.playerX, 0.1f)
        assertEquals(860f, loaded.playerY, 0.1f)
    }

    @Test
    fun saveSystem_persistsFarmingAndMaturesAfterTimeElapsed() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val saveSystem = SaveSystem(context)

        val foundation = FarmingPlotFoundation()
        val plots = foundation.getAllPlots()
        val plot1 = plots[0]
        plot1.prepareSoil()

        val plantTime = 1_000_000L
        plot1.plant(CropType.CARROT, currentTimeMs = plantTime) // 30s carrot

        // Save with farming plot data
        val save = GameSaveData(
            currentZone = ZoneId.VILLAGE,
            farmingPlotData = foundation.toSerialized()
        )
        saveSystem.saveGame(save)

        // Reload game and simulate player returning 40 seconds later
        val loadedSave = saveSystem.loadGame()
        val restoredFoundation = FarmingPlotFoundation()
        restoredFoundation.loadFromSerialized(loadedSave.farmingPlotData)

        val restoredPlot = restoredFoundation.getAllPlots()[0]
        assertEquals(FarmingPlotState.GROWING, restoredPlot.state)

        // When 40s has passed (elapsed 40s >= 30s)
        restoredFoundation.updateAll(currentTimeMs = plantTime + 40_000L)
        assertEquals(FarmingPlotState.MATURE, restoredPlot.state)
        assertTrue(restoredPlot.isMature())
    }

    @Test
    fun saveSystem_persistsEconomyTransactionsAfterBuyingAndSelling() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val saveSystem = SaveSystem(context)
        saveSystem.resetSave()

        val economy = EconomyManager(50)
        val inventory = Inventory(16)

        // 1. Buy 6 Tomato Seeds @ 2 = 12 cost -> 38 money remaining
        ShopSystem.buySeed(economy, inventory, ItemCatalog.TOMATO_SEEDS, 6)
        assertEquals(38, economy.money)

        // 2. Add 2 peppers and sell them at Market @ 20 = 40 earn -> 78 money
        inventory.addItem(ItemCatalog.PEPPER, 2)
        MarketSystem.sellCrop(economy, inventory, ItemCatalog.PEPPER, 2)
        assertEquals(78, economy.money)

        // 3. Save Game
        val save = GameSaveData(
            currentZone = ZoneId.VILLAGE,
            money = economy.money,
            inventoryItems = inventory.toSerializedList()
        )
        saveSystem.saveGame(save)

        // 4. Reload Game in new session
        val loaded = saveSystem.loadGame()
        assertEquals(78, loaded.money)

        val restoredInventory = Inventory(16)
        restoredInventory.loadFromList(loaded.inventoryItems)
        assertEquals(6, restoredInventory.getTotalQuantity(ItemCatalog.TOMATO_SEEDS.id))
        assertEquals(0, restoredInventory.getTotalQuantity(ItemCatalog.PEPPER.id))
    }

    @Test
    fun npcSystem_fourLivingNpcsExistWithDistinctIdentitiesAndDialogues() {
        val controller = com.example.game.npc.NPCController()
        assertEquals(4, controller.npcs.size)

        val yassin = controller.npcs.find { it.definition.id == com.example.game.npc.NPCId.YASSIN }
        val samira = controller.npcs.find { it.definition.id == com.example.game.npc.NPCId.SAMIRA }
        val mazen = controller.npcs.find { it.definition.id == com.example.game.npc.NPCId.MAZEN }
        val amin = controller.npcs.find { it.definition.id == com.example.game.npc.NPCId.AMIN }

        assertTrue(yassin != null && yassin.definition.nameArabic == "ياسين")
        assertTrue(samira != null && samira.definition.nameArabic == "سميرة")
        assertTrue(mazen != null && mazen.definition.nameArabic == "مازن")
        assertTrue(amin != null && amin.definition.nameArabic == "أمين")

        // Dialogue verification
        assertTrue(yassin!!.definition.dialogue.greetingLines.isNotEmpty())
        assertTrue(samira!!.definition.dialogue.greetingLines.isNotEmpty())
        assertTrue(mazen!!.definition.dialogue.greetingLines.isNotEmpty())
        assertTrue(amin!!.definition.dialogue.greetingLines.isNotEmpty())
    }

    @Test
    fun npcSystem_dialogueProgressionAndSavePersistence() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val saveSystem = SaveSystem(context)
        saveSystem.resetSave()

        val controller = com.example.game.npc.NPCController()
        val yassin = controller.npcs.first { it.definition.id == com.example.game.npc.NPCId.YASSIN }

        // Initially not met
        assertTrue(!yassin.hasMetPlayer)
        val initialLine = yassin.getCurrentDialogueLine()
        assertTrue(initialLine.textArabic.contains("ياسين"))

        // Interact and conclude greeting
        controller.startTalking(yassin, playerX = yassin.x, playerY = yassin.y + 20f)
        assertEquals(com.example.game.npc.NPCBehavior.TALKING, yassin.behavior)

        while (yassin.hasMoreDialogue()) {
            yassin.advanceDialogue()
        }
        controller.stopTalking(yassin)
        assertTrue(yassin.hasMetPlayer)

        // Save met NPCs
        val save = GameSaveData(
            currentZone = ZoneId.VILLAGE,
            metNpcIds = controller.getMetNpcIdStrings()
        )
        saveSystem.saveGame(save)

        // Reload in new controller session
        val loaded = saveSystem.loadGame()
        assertTrue(loaded.metNpcIds.contains("yassin"))

        val newController = com.example.game.npc.NPCController()
        newController.loadMetNpcIdStrings(loaded.metNpcIds)
        val reloadedYassin = newController.npcs.first { it.definition.id == com.example.game.npc.NPCId.YASSIN }
        assertTrue(reloadedYassin.hasMetPlayer)
    }

    @Test
    fun questSystem_eightIntroductoryQuestsExistWithPrerequisitesAndRewards() {
        val database = com.example.game.quest.QuestDatabase
        assertEquals(8, database.ALL_QUESTS.size)

        val q1 = database.findById("quest_first_harvest")
        assertNotNull(q1)
        assertEquals("أول حصاد", q1!!.titleArabic)
        assertEquals(com.example.game.npc.NPCId.MAZEN, q1.giverNpcId)
        assertEquals(10, q1.reward.money)

        val q2 = database.findById("quest_market_day")
        assertNotNull(q2)
        assertEquals("أول صفقة", q2!!.titleArabic)
        assertEquals(com.example.game.npc.NPCId.SAMIRA, q2.giverNpcId)

        val q3 = database.findById("quest_into_forest")
        assertNotNull(q3)
        assertEquals("إلى الغابة", q3!!.titleArabic)
        assertEquals(com.example.game.npc.NPCId.AMIN, q3.giverNpcId)

        val q7 = database.findById("quest_village_trader")
        assertNotNull(q7)
        assertEquals(com.example.game.quest.ObjectiveType.SELL_VALUE, q7!!.objectives[0].type)
        assertEquals(50, q7.objectives[0].targetCount)
    }

    @Test
    fun questSystem_activeQuestLimitEnforcedAtThree() {
        val qm = com.example.game.quest.QuestManager()

        val r1 = qm.acceptQuest("quest_first_harvest")
        assertTrue(r1 is com.example.game.quest.AcceptQuestResult.Success)

        val r2 = qm.acceptQuest("quest_market_day")
        assertTrue(r2 is com.example.game.quest.AcceptQuestResult.Success)

        val r3 = qm.acceptQuest("quest_into_forest")
        assertTrue(r3 is com.example.game.quest.AcceptQuestResult.Success)

        assertEquals(3, qm.getActiveQuests().size)

        // Try accepting a 4th quest while 3 are active
        val r4 = qm.acceptQuest("quest_seeds_tomorrow")
        assertTrue(r4 is com.example.game.quest.AcceptQuestResult.LimitReached)
        assertEquals(3, qm.getActiveQuests().size)
    }

    @Test
    fun questSystem_harvestEventProgressesObjectiveAndTransitionsToTurnIn() {
        val qm = com.example.game.quest.QuestManager()
        val rm = com.example.game.relationship.RelationshipManager()
        val eco = com.example.game.economy.EconomyManager(50)
        val inv = com.example.game.items.Inventory(16)

        qm.acceptQuest("quest_first_harvest")
        val instance = qm.instances["quest_first_harvest"]!!
        assertEquals(com.example.game.quest.QuestState.ACTIVE, instance.state)
        assertEquals(0, instance.getObjectiveProgress(0))

        // Harvest a carrot
        qm.onCropHarvested(CropType.CARROT)
        assertEquals(1, instance.getObjectiveProgress(0))
        assertEquals(com.example.game.quest.QuestState.COMPLETED_PENDING_REWARD, instance.state)

        // Marker should now be TURN_IN "?"
        val marker = qm.getNpcQuestMarker(com.example.game.npc.NPCId.MAZEN)
        assertEquals(com.example.game.quest.QuestMarkerType.TURN_IN, marker)

        // Complete and claim reward
        val claimResult = qm.completeQuestAndClaimReward("quest_first_harvest", eco, inv, rm)
        assertNotNull(claimResult)
        assertEquals(60, eco.money) // 50 + 10
        assertEquals(5, rm.getData(com.example.game.npc.NPCId.MAZEN).affinity)
        assertTrue(instance.rewardClaimed)
        assertEquals(com.example.game.quest.QuestState.COMPLETED, instance.state)

        // Duplicate claim attempt MUST fail
        val duplicateClaim = qm.completeQuestAndClaimReward("quest_first_harvest", eco, inv, rm)
        org.junit.Assert.assertNull(duplicateClaim)
        assertEquals(60, eco.money) // No duplicated reward!
    }

    @Test
    fun questSystem_woodGatheringAndTransactionValueTracking() {
        val qm = com.example.game.quest.QuestManager()

        // Test Wood Gathering (Quest 3: 5 wood)
        qm.acceptQuest("quest_into_forest")
        val forestQuest = qm.instances["quest_into_forest"]!!
        assertEquals(0, forestQuest.getObjectiveProgress(0))

        qm.onWoodCollected(3)
        assertEquals(3, forestQuest.getObjectiveProgress(0))
        assertEquals(com.example.game.quest.QuestState.ACTIVE, forestQuest.state)

        qm.onWoodCollected(2)
        assertEquals(5, forestQuest.getObjectiveProgress(0))
        assertEquals(com.example.game.quest.QuestState.COMPLETED_PENDING_REWARD, forestQuest.state)

        // Test Transaction Value Tracking (Quest 7: 50 money worth of crops)
        // Set prerequisite so Quest 7 becomes available
        val q2 = qm.instances["quest_market_day"]!!
        q2.state = com.example.game.quest.QuestState.COMPLETED
        q2.rewardClaimed = true
        qm.refreshAvailableQuests()

        qm.acceptQuest("quest_village_trader")
        val traderQuest = qm.instances["quest_village_trader"]!!

        // Sell 1 pepper for 20 money value
        qm.onItemSold(ItemCatalog.PEPPER, quantity = 1, totalValue = 20)
        assertEquals(20, traderQuest.getObjectiveProgress(0))
        assertEquals(com.example.game.quest.QuestState.ACTIVE, traderQuest.state)

        // Sell 2 peppers for 40 money value -> 20 + 40 = 60 >= 50
        qm.onItemSold(ItemCatalog.PEPPER, quantity = 2, totalValue = 40)
        assertEquals(50, traderQuest.getObjectiveProgress(0))
        assertEquals(com.example.game.quest.QuestState.COMPLETED_PENDING_REWARD, traderQuest.state)
    }

    @Test
    fun relationshipSystem_affinityBracketsAndDailyInteractionBonus() {
        val rm = com.example.game.relationship.RelationshipManager()
        val yassinData = rm.getData(com.example.game.npc.NPCId.YASSIN)

        assertEquals(0, yassinData.affinity)
        assertEquals(com.example.game.relationship.RelationshipLevel.STRANGER, yassinData.level)
        assertEquals("غريب", yassinData.level.titleArabic)

        // Daily talk on day 1
        val talk1 = rm.onDailyTalk(com.example.game.npc.NPCId.YASSIN, currentDay = 1)
        assertTrue(talk1)
        assertEquals(1, yassinData.affinity)

        // Repeated talk on the SAME day should not increase affinity (anti-spam)
        val talkSameDay = rm.onDailyTalk(com.example.game.npc.NPCId.YASSIN, currentDay = 1)
        org.junit.Assert.assertFalse(talkSameDay)
        assertEquals(1, yassinData.affinity)

        // Add affinity to advance brackets: 25 -> معروف
        rm.addAffinity(com.example.game.npc.NPCId.YASSIN, 24)
        assertEquals(25, yassinData.affinity)
        assertEquals(com.example.game.relationship.RelationshipLevel.ACQUAINTANCE, yassinData.level)
        assertEquals("معروف", yassinData.level.titleArabic)

        // Add to 45 -> صديق
        rm.addAffinity(com.example.game.npc.NPCId.YASSIN, 20)
        assertEquals(45, yassinData.affinity)
        assertEquals(com.example.game.relationship.RelationshipLevel.FRIEND, yassinData.level)
        assertEquals("صديق", yassinData.level.titleArabic)

        // Add to 85 -> من أهل القرية
        rm.addAffinity(com.example.game.npc.NPCId.YASSIN, 40)
        assertEquals(85, yassinData.affinity)
        assertEquals(com.example.game.relationship.RelationshipLevel.VILLAGER, yassinData.level)
        assertEquals("من أهل القرية", yassinData.level.titleArabic)
    }

    @Test
    fun saveSystem_persistsQuestsAndSupportsBackwardCompatibility() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val saveSystem = SaveSystem(context)
        saveSystem.resetSave()

        // 1. Setup partial quest progress and relationships
        val qm = com.example.game.quest.QuestManager()
        qm.acceptQuest("quest_into_forest")
        qm.onWoodCollected(3) // 3 / 5

        val rm = com.example.game.relationship.RelationshipManager()
        rm.addAffinity(com.example.game.npc.NPCId.AMIN, 15)

        // Save
        val save = GameSaveData(
            currentZone = ZoneId.VILLAGE,
            money = 75,
            questData = qm.toSerialized(),
            relationshipData = rm.toSerialized(),
            questVersion = 1
        )
        saveSystem.saveGame(save)

        // 2. Reload and verify
        val loaded = saveSystem.loadGame()
        assertEquals(75, loaded.money)

        val restoredQm = com.example.game.quest.QuestManager()
        restoredQm.loadFromSerialized(loaded.questData)

        val restoredForestQuest = restoredQm.instances["quest_into_forest"]!!
        assertEquals(com.example.game.quest.QuestState.ACTIVE, restoredForestQuest.state)
        assertEquals(3, restoredForestQuest.getObjectiveProgress(0))

        val restoredRm = com.example.game.relationship.RelationshipManager()
        restoredRm.loadFromSerialized(loaded.relationshipData)
        assertEquals(15, restoredRm.getData(com.example.game.npc.NPCId.AMIN).affinity)

        // 3. Backward Compatibility Test: Older Stage 8 save with empty questData
        val oldStage8Save = GameSaveData(
            currentZone = ZoneId.VILLAGE,
            money = 150,
            questData = "",
            relationshipData = ""
        )
        saveSystem.saveGame(oldStage8Save)

        val reloadedOld = saveSystem.loadGame()
        val emptyQm = com.example.game.quest.QuestManager()
        emptyQm.loadFromSerialized(reloadedOld.questData)

        // Initial quests should be safely AVAILABLE without crashing
        assertEquals(150, reloadedOld.money)
        assertEquals(0, emptyQm.getActiveQuests().size)
        assertTrue(emptyQm.getAvailableQuests().isNotEmpty())
    }
}
